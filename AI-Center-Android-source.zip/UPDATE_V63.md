# 6.3 — native output safety

- Limited generated response size to 1 MiB before JNI conversion, including oversized-token paths.
- Added regression test for output cap.
- Kept the llama.cpp interface compatible with the existing JNI compile-contract stub.

**Not completed:** actual llama.cpp checkout, Android NDK compilation, real GGUF inference, APK device validation. GitHub DNS access failed in this environment; SDK/NDK are unavailable. No APK is included.
