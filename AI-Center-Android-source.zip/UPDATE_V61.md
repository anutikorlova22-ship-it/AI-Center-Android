# AI Center 6.1 — native offline context integration

Added `OfflinePrompt.java` and wired it into the experimental native chat. When the native engine is actually available, it will receive up to 3 locally approved instruction-only skills and 5 local notes, with strict per-item text limits. This does not execute code and does not use Termux for the prompt composition.

Important limitations: llama.cpp source, verified Android native build, real on-device inference, and migration of the remaining Python services are NOT complete. The Android app has NOT been compiled or installed. This change is not a claim of full ChatGPT feature parity.

Tested: 146 Python unit tests (including source integration checks); no Android build or runtime tests.
