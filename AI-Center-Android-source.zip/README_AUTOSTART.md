# AI Center Android V2.2 — Termux autostart

On opening the Android app, it first checks http://127.0.0.1:8765/. If unavailable, it requests Android permission `com.termux.permission.RUN_COMMAND`, invokes Termux's documented `com.termux.RUN_COMMAND` service, and waits up to 60 seconds for the web server. If server is already running, it does not restart it.

## Phone setup (one-time)
1. Extract `termux/` folder into Downloads and run `bash ~/storage/downloads/termux/install.sh` from Termux. Restart Termux afterward.
2. Install the newly built APK (same app ID, version 2.2) over the previous version.
3. When Android requests `Run commands in Termux` permission, grant it.
4. Disable restrictive battery optimization for Termux if Android kills the server.

This does not embed Qwen in APK. Termux must remain installed, and the Qwen GGUF must be valid. The web server may start even if Qwen is unavailable. Debug log: `~/AI_CENTER/logs/android_autostart.log`.

## GitHub build
Upload this ZIP as `AI-Center-Android-source.zip` to repository root (replace previous ZIP). Existing workflow can extract it and run `gradle assembleDebug`. Existing workflow must omit the obsolete `android-actions/setup-android@v3` step that failed earlier.

Security: only Termux shell path and a fixed local launcher script are invoked; no arbitrary user-supplied commands. The WebView only allows local host:8765; other links open externally.
