# ИИ Центр 5.4 — native build readiness

- Added offline prerequisite checker: `android/ai_center_build/check_native_prerequisites.py`.
- CMake now disables host-native optimizations, OpenMP, llamafile and OpenSSL when building llama.cpp for Android.
- JNI output handles token pieces larger than the initial buffer instead of silently losing them.
- The `llama.cpp` source tree is **not bundled**; no Android NDK build or on-device inference has been performed.
- Do not remove Termux or migrate user data until the replacement is tested on the device.
- To build after independent source review, vendor compatible llama.cpp at `app/src/main/cpp/vendor/llama.cpp`, run the checker with `--require-llama`, then build with `-PaicenterWithLlama=true`.
