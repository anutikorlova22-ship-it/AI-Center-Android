#!/usr/bin/env python3
"""Install only the independent research module. Does not replace live chat server or memory."""
from pathlib import Path
import subprocess, sys, shutil, ast
here=Path(__file__).resolve().parent
source=here/'android/ai_center_build/termux/research/install_research.py'
if not source.is_file():raise SystemExit('Файл research/install_research.py не найден')
compile(source.read_text(encoding='utf-8'),str(source),'exec')
print('Проверка синтаксиса: OK')
print('Текущий server.py, документы, база памяти и настройки не изменяются.')
answer=input('Установить отдельный исследовательский модуль? [да/нет]: ').strip().lower()
if answer not in ('да','д','yes','y'):raise SystemExit('Отменено без изменений')
subprocess.run([sys.executable,str(source)],check=True)
