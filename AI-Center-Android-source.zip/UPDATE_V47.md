# V4.7 — Native JNI bridge (development)

Introduced an Android NDK/CMake shared library and a Java JNI interface. The library reports its capabilities and fails closed if inference is requested. **This is not a working llama.cpp runtime** and the chat still uses the Termux-hosted service. No model is bundled. Native build was not executed here; Android SDK/NDK must be available to validate APK compilation.

Next: pin llama.cpp source version, integrate its CMake targets for Android arm64-v8a, implement bounded inference and cancellation on a worker thread, then switch chat after device testing. Never execute downloaded skill code automatically.
