#!/usr/bin/env python3
"""Static, non-destructive cross-component audit. Does not claim device testing."""
import json, pathlib, re, subprocess, sys, unittest
ROOT=pathlib.Path(__file__).resolve().parent
ANDROID=ROOT/'android/ai_center_build'
JAVA=ANDROID/'app/src/main/java/ru/aicenter/mobile'
SERVER=ROOT/'server/mobile'
checks={
 'android_project':(ANDROID/'app/build.gradle.kts').is_file(),
 'android_manifest':(ANDROID/'app/src/main/AndroidManifest.xml').is_file(),
 'android_native_store':(JAVA/'NativeStore.java').is_file(),
 'android_reminder_receiver':(JAVA/'ReminderReceiver.java').is_file(),
 'android_offline_chat':(JAVA/'NativeInference.java').is_file(),
 'android_skill_library':(JAVA/'SkillLibrary.java').is_file(),
 'android_model_import':(JAVA/'NativeModelManager.java').is_file(),
 'native_cpp_adapter':(ANDROID/'app/src/main/cpp/native_inference.cpp').is_file(),
 'server_chat':(SERVER/'server.py').is_file(),
 'server_search':(SERVER/'v30_tools.py').is_file(),
 'server_reports':(SERVER/'v34_reports.py').is_file(),
 'server_office':(SERVER/'v35_office.py').is_file(),
 'server_skills':(SERVER/'approved_skills.py').is_file(),
 'server_skill_review':(SERVER/'skill_candidates.py').is_file(),
 'server_hybrid_bridge':(SERVER/'hybrid_bridge.py').is_file(),
 'server_android_backup':(SERVER/'native_backup.py').is_file(),
 'android_ci':(ROOT/'.github/workflows/android-native-build.yml').is_file(),
 'llama_vendor':(ANDROID/'app/src/main/cpp/vendor/llama.cpp/include/llama.h').is_file(),
 'gradle_wrapper':(ANDROID/'gradlew').is_file() and (ANDROID/'gradle/wrapper/gradle-wrapper.jar').is_file(),
}
manifest=(ANDROID/'app/src/main/AndroidManifest.xml').read_text()
main=(JAVA/'MainActivity.java').read_text()
checks['notification_permission']='android.permission.POST_NOTIFICATIONS' in manifest
checks['termux_http_bridge']='127.0.0.1:8765' in main
checks['google_drive_bridge']='rclone' in (SERVER/'hybrid_bridge.py').read_text()
checks['google_drive_configured_on_device']=False
checks['android_apk_built']=any(ROOT.rglob('*.apk'))
checks['native_so_built']=any(ROOT.rglob('*.so'))
checks['device_tested']=False
checks['end_to_end_google_drive_tested']=False
result={'static_checks':checks,'present_count':sum(checks.values()),'total_checks':len(checks),'critical_blockers':[k for k in ('llama_vendor','gradle_wrapper','android_apk_built','native_so_built','device_tested','end_to_end_google_drive_tested') if not checks[k]],'caveat':'Static presence is not functional verification. Device/cloud flags intentionally false without external evidence.'}
print(json.dumps(result,ensure_ascii=False,indent=2))
if '--strict' in sys.argv and result['critical_blockers']:sys.exit(1)
