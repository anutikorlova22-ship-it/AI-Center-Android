# AI Center 5.7 — JNI compilation contract checks

Added `tests/test_native_cpp_contract_v57.py`. It compiles `native_inference.cpp` twice using a host C++17 compiler and JDK JNI headers: once with `AICENTER_WITH_LLAMA` disabled, and once enabled against a minimal API-shaped llama.h declaration fixture.

This is a syntax/API-shape smoke test only. It does not link against actual llama.cpp, build for Android ABI, load a GGUF model, or prove runtime inference. The stub declarations are maintained in the test, not extracted from upstream and may drift from upstream APIs.

Current blocker: the verified llama.cpp source tree and Android SDK/NDK are not available in this build environment. To claim Termux-free operation, next obtain and pin upstream sources, compile actual llama.cpp with Android NDK, run instrumentation tests on device, then migrate remaining server-only tools.

Run: `python -m unittest discover -s tests -p 'test_*.py' -q`
