# 5.0 — opt-in llama.cpp inference adapter

Native C++ now contains model loading, tokenization, prompt evaluation and greedy token generation through the llama.cpp API, gated by `AICENTER_WITH_LLAMA`.

**Not a working offline APK yet.** llama.cpp source is not bundled; default flag is OFF. To test, vendor a reviewed, API-compatible llama.cpp snapshot into `app/src/main/cpp/vendor/llama.cpp`, enable `-DAICENTER_WITH_LLAMA=ON` in Android CMake arguments, build with Android SDK/NDK and run on an ARM64 device with a licensed GGUF model. This has NOT been compiled against an actual llama.cpp snapshot in this environment; API compatibility must be verified and adapted. This is a first implementation, not a validated release.

Remaining: connect the native generate call to the chat UI; test real tokens, chat templates, memory use, cancellation and performance; replace other Termux-dependent endpoints. No automatic execution of downloaded skills.
