# AI Center 4.5 — native notes and reminders

- Android UI can add/view local notes and create/complete local tasks through NativeStore.
- ReminderReceiver checks native SQLite reminders without a running Python server, and retains legacy server checks.
- Notifications are best effort (inexact Android alarms, permission and battery policies); after reboot rescheduling is not yet implemented.
- The Qwen chat and most legacy tools still require Termux; this update does not remove Termux.
- Source-level unit tests do not establish APK compilation or device correctness.
