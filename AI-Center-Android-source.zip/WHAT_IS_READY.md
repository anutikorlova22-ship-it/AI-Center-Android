# AI Center 3.0 — integrated development snapshot

- Android search tab now loads **8765/v30.html** (no extra port).
- The server provides live DuckDuckGo HTML search with actual links and honest network errors.
- Document search supports text/Office documents in the opt-in `~/AI_CENTER/imports` folder.
- Reminders have SQLite persistence, time-zone-aware due dates, manual dismissal and are displayed when opening the tab. **No push notifications or autonomous execution.**
- Chat remains on local Qwen 8081, with existing fallback.
- Android speech input/output, generative images, remote access, and full agent automation are **not implemented**. They need further development and Android device tests.
- Server install: copy only the reviewed `server/mobile/v30_extra.py`, `v30_tools.py`, `v30.html`, `server.py` into `~/AI_CENTER/mobile/` after backing up. Do not overwrite the phone installation without testing.
- This is source code, **not a built APK**. Do not claim device compatibility from unit tests.
