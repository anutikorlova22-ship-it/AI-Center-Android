# AI Center 6.8: Android -> Termux local snapshot

- Android screen includes explicit-confirmation backup of up to 100 most recent notes and 100 active reminders.
- POST /api/v68/native/backup stores idempotent copies in ~/AI_CENTER/knowledge/android_backup.db.
- Existing Google Drive rclone sync is unchanged and DOES NOT upload this SQLite backup.
- Localhost API is not cryptographically authenticated. The action header is a confirmation guard, not an authentication mechanism. Do not expose port 8765 to the network.
- Android Java/NDK APK build and device tests were not run. Existing Termux services and source code remain available.
- Next: secure device pairing, migration of completed tasks, optional explicit encrypted Google Drive backup, real Android APK build.
