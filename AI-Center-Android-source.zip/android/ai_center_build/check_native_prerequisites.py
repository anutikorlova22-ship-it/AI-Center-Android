#!/usr/bin/env python3
"""Offline build preflight; does not download or execute third-party code."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CPP = ROOT / "app/src/main/cpp"


def inspect(root=ROOT):
    cpp = root / "app/src/main/cpp"
    vendor = cpp / "vendor/llama.cpp"
    checks = {
        "android_project": (root / "app/build.gradle.kts").is_file(),
        "jni_bridge": (cpp / "native_inference.cpp").is_file(),
        "cmake": (cpp / "CMakeLists.txt").is_file(),
        "llama_sources": (vendor / "CMakeLists.txt").is_file() and (vendor / "include/llama.h").is_file(),
    }
    return {"checks": checks, "ready_for_llama_build": all(checks.values()),
            "note": "Preflight is not compilation or on-device inference."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-llama", action="store_true")
    args = parser.parse_args()
    result = inspect()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if args.require_llama and not result["ready_for_llama_build"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
