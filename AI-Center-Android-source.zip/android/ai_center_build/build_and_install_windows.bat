@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle 8.10.2 is required. Alternatively open this folder in Android Studio.
  exit /b 2
)
if not defined ANDROID_HOME if not defined ANDROID_SDK_ROOT (
  echo Android SDK missing. Install SDK 35 and NDK 27.2.12479018.
  exit /b 2
)
echo Building TEST APK without llama.cpp; main chat may still require Termux.
call gradle --no-daemon assembleDebug
if errorlevel 1 exit /b 3
set APK=app\build\outputs\apk\debug\app-debug.apk
if not exist "%APK%" exit /b 4
echo Built: %CD%\%APK%
if /I not "%~1"=="--install" exit /b 0
where adb >nul 2>nul
if errorlevel 1 exit /b 5
adb devices
set /p CONFIRM=Install TEST APK on connected phone? Type yes: 
if /I not "%CONFIRM%"=="yes" exit /b 0
adb install -r "%APK%"
