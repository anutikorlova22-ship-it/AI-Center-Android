# Embedded model runtime — integration boundary

This project now has an opt-in CMake integration point for **vendored, reviewed** llama.cpp sources.
It does not download or execute third-party code automatically. Default builds retain the
fail-closed JNI stub; they cannot generate Qwen answers without Termux.

Before enabling native inference:
1. Review and pin a compatible llama.cpp commit and its license; place its complete sources at `vendor/llama.cpp`.
2. Set `-DAICENTER_WITH_LLAMA=ON` in the app's `externalNativeBuild.cmake.arguments`.
3. Implement and verify the llama.cpp API adapter in `native_inference.cpp` for the pinned revision.
4. Compile for arm64-v8a with the Android NDK; run generation, cancellation, memory and thermal tests on device.
5. Verify model format and prompt/chat template, token limits, context window and Android lifecycle.

**Do not enable the flag yet**: the JNI generation adapter is intentionally not implemented.
This integration is build infrastructure, not a working embedded Qwen runtime.
