#include <jni.h>
#include <string>
#include <fstream>
#include <cstdint>
#include <vector>
#include <algorithm>
#include <mutex>
#ifdef AICENTER_WITH_LLAMA
#include "llama.h"
#endif

namespace {
std::string from_java(JNIEnv* env, jstring s) {
    if (!s) return {};
    const char* chars = env->GetStringUTFChars(s, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(s, chars);
    return result;
}
void throw_java(JNIEnv* env, const char* name, const char* message) {
    jclass cls = env->FindClass(name);
    if (cls) env->ThrowNew(cls, message);
}
#ifdef AICENTER_WITH_LLAMA
std::mutex inference_mutex;
struct ModelGuard {
    llama_model* model = nullptr;
    ~ModelGuard() { if (model) llama_model_free(model); }
};
struct ContextGuard {
    llama_context* ctx = nullptr;
    ~ContextGuard() { if (ctx) llama_free(ctx); }
};
struct SamplerGuard {
    llama_sampler* sampler = nullptr;
    ~SamplerGuard() { if (sampler) llama_sampler_free(sampler); }
};
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_ru_aicenter_mobile_NativeInference_runtimeStatus(JNIEnv* env, jclass) {
#ifdef AICENTER_WITH_LLAMA
    return env->NewStringUTF("llama.cpp inference linked (CPU)");
#else
    return env->NewStringUTF("JNI available; llama.cpp not bundled");
#endif
}

extern "C" JNIEXPORT jboolean JNICALL
Java_ru_aicenter_mobile_NativeInference_verifyGgufHeader(JNIEnv* env, jclass, jstring path) {
    const std::string file = from_java(env, path);
    if (file.empty()) return JNI_FALSE;
    std::ifstream stream(file, std::ios::binary | std::ios::ate);
    if (!stream || stream.tellg() < 24) return JNI_FALSE;
    stream.seekg(0);
    unsigned char bytes[8] = {};
    stream.read(reinterpret_cast<char*>(bytes), sizeof(bytes));
    if (!stream) return JNI_FALSE;
    const bool magic = bytes[0] == 'G' && bytes[1] == 'G' && bytes[2] == 'U' && bytes[3] == 'F';
    const uint32_t version = uint32_t(bytes[4]) | (uint32_t(bytes[5]) << 8) |
                             (uint32_t(bytes[6]) << 16) | (uint32_t(bytes[7]) << 24);
    return magic && version >= 2 && version <= 3 ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_ru_aicenter_mobile_NativeInference_runModel(JNIEnv* env, jclass,
                                                   jstring model_path, jstring prompt_text, jint max_tokens) {
    if (!model_path || !prompt_text || max_tokens < 1 || max_tokens > 2048) {
        throw_java(env, "java/lang/IllegalArgumentException", "Invalid inference arguments");
        return nullptr;
    }
#ifndef AICENTER_WITH_LLAMA
    throw_java(env, "java/lang/UnsupportedOperationException", "llama.cpp is not linked");
    return nullptr;
#else
    // Serialize requests: llama backend/model lifetime must not race other JNI calls.
    std::lock_guard<std::mutex> lock(inference_mutex);
    const std::string path = from_java(env, model_path);
    const std::string prompt = from_java(env, prompt_text);
    if (path.empty() || prompt.empty() || prompt.size() > 65536) {
        throw_java(env, "java/lang/IllegalArgumentException", "Invalid model path or prompt");
        return nullptr;
    }
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0; // conservative CPU-only Android baseline
    ModelGuard mg;
    mg.model = llama_model_load_from_file(path.c_str(), mp);
    if (!mg.model) {
        throw_java(env, "java/lang/IllegalStateException", "Could not load GGUF model");
        return nullptr;
    }
    const llama_vocab* vocab = llama_model_get_vocab(mg.model);
    const int n_prompt = -llama_tokenize(vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()), nullptr, 0, true, true);
    if (n_prompt <= 0 || n_prompt > 8192) {
        throw_java(env, "java/lang/IllegalArgumentException", "Prompt exceeds token limit");
        return nullptr;
    }
    std::vector<llama_token> tokens(n_prompt);
    if (llama_tokenize(vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()), tokens.data(), n_prompt, true, true) < 0) {
        throw_java(env, "java/lang/IllegalStateException", "Tokenization failed");
        return nullptr;
    }
    llama_context_params cp = llama_context_default_params();
    // Cap memory demand on phones; reject oversized prompts instead of allocating huge KV caches.
    if (n_prompt + max_tokens + 16 > 4096) {
        throw_java(env, "java/lang/IllegalArgumentException", "Prompt and response exceed 4096-token context");
        return nullptr;
    }
    cp.n_ctx = static_cast<uint32_t>(n_prompt + max_tokens + 16);
    cp.n_batch = 512;
    cp.n_threads = 4;
    cp.n_threads_batch = 4;
    ContextGuard cg;
    cg.ctx = llama_init_from_model(mg.model, cp);
    if (!cg.ctx) {
        throw_java(env, "java/lang/IllegalStateException", "Could not initialize inference context");
        return nullptr;
    }
    SamplerGuard sg;
    sg.sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (!sg.sampler) {
        throw_java(env, "java/lang/IllegalStateException", "Could not initialize sampler");
        return nullptr;
    }
    llama_sampler_chain_add(sg.sampler, llama_sampler_init_greedy());
    // Decode prompt in bounded batches, requesting logits only on final token.
    for (int pos = 0; pos < n_prompt; pos += 512) {
        const int count = std::min(512, n_prompt - pos);
        llama_batch batch = llama_batch_init(count, 0, 1);
        batch.n_tokens = count;
        for (int j = 0; j < count; ++j) {
            batch.token[j] = tokens[pos + j];
            batch.pos[j] = pos + j;
            batch.n_seq_id[j] = 1;
            batch.seq_id[j][0] = 0;
            batch.logits[j] = (pos + j == n_prompt - 1) ? 1 : 0;
        }
        const int rc = llama_decode(cg.ctx, batch);
        llama_batch_free(batch);
        if (rc != 0) {
            throw_java(env, "java/lang/IllegalStateException", "Prompt decode failed");
            return nullptr;
        }
    }
    std::string output;
    output.reserve(4096);
    constexpr size_t MAX_OUTPUT_BYTES = 1024 * 1024;
    for (int i = 0; i < max_tokens; ++i) {
        const llama_token token = llama_sampler_sample(sg.sampler, cg.ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;
        llama_sampler_accept(sg.sampler, token);
        // Token pieces may exceed a fixed-size buffer. Retry with the exact
        // required capacity instead of silently truncating generated text.
        char small_piece[256];
        int len = llama_token_to_piece(vocab, token, small_piece, sizeof(small_piece), 0, true);
        if (len > 0) {
            output.append(small_piece, static_cast<size_t>(len));
        } else if (len < 0) {
            const size_t needed = static_cast<size_t>(-len);
            if (needed > 65536) {
                throw_java(env, "java/lang/IllegalStateException", "Generated token piece too large");
                return nullptr;
            }
            std::vector<char> piece(needed);
            len = llama_token_to_piece(vocab, token, piece.data(), static_cast<int32_t>(piece.size()), 0, true);
            if (len < 0) {
                throw_java(env, "java/lang/IllegalStateException", "Could not decode token piece");
                return nullptr;
            }
            output.append(piece.data(), static_cast<size_t>(len));
        }
        if (output.size() > MAX_OUTPUT_BYTES) {
            throw_java(env, "java/lang/IllegalStateException", "Generated response exceeds 1 MiB");
            return nullptr;
        }
        // The final sampled token does not need a further decode.
        if (i + 1 == max_tokens) break;
        // Explicit KV-cache position: do not rely on llama_batch_get_one
        // assigning positions consistently across llama.cpp revisions.
        llama_batch batch = llama_batch_init(1, 0, 1);
        batch.n_tokens = 1;
        batch.token[0] = token;
        batch.pos[0] = n_prompt + i;
        batch.n_seq_id[0] = 1;
        batch.seq_id[0][0] = 0;
        batch.logits[0] = 1;
        const int decode_rc = llama_decode(cg.ctx, batch);
        llama_batch_free(batch);
        if (decode_rc != 0) {
            throw_java(env, "java/lang/IllegalStateException", "Generation decode failed");
            return nullptr;
        }
    }
    // NewStringUTF expects modified UTF-8; use a Java UTF-8 decoder for arbitrary
    // generated bytes (including 4-byte Unicode and partial token pieces).
    jclass stringClass = env->FindClass("java/lang/String");
    if (!stringClass) return nullptr;
    jmethodID ctor = env->GetMethodID(stringClass, "<init>", "([BLjava/lang/String;)V");
    if (!ctor) return nullptr;
    jbyteArray bytes = env->NewByteArray(static_cast<jsize>(output.size()));
    if (!bytes) return nullptr;
    env->SetByteArrayRegion(bytes, 0, static_cast<jsize>(output.size()),
                            reinterpret_cast<const jbyte*>(output.data()));
    jstring encoding = env->NewStringUTF("UTF-8");
    return static_cast<jstring>(env->NewObject(stringClass, ctor, bytes, encoding));
#endif
}
