package ru.aicenter.mobile;

/** JNI entry point for a future embedded GGUF runtime. Never silently falls back to Termux. */
public final class NativeInference {
    private static final boolean LOADED;
    static {
        boolean ok;
        try { System.loadLibrary("aicenter_native"); ok = true; }
        catch (UnsatisfiedLinkError | SecurityException ex) { ok = false; }
        LOADED = ok;
    }
    private NativeInference() {}
    private static native String runtimeStatus();
    private static native boolean verifyGgufHeader(String modelPath);
    private static native String runModel(String modelPath, String prompt, int maxTokens);
    public static boolean libraryLoaded() { return LOADED; }
    public static String status() {
        if (!LOADED) return "Native library unavailable";
        return runtimeStatus();
    }
    public static boolean modelHeaderValid(String modelPath) {
        if (!LOADED || modelPath == null || modelPath.isEmpty()) return false;
        return verifyGgufHeader(modelPath);
    }
    public static String generate(String modelPath, String prompt, int maxTokens) {
        if (!LOADED) throw new IllegalStateException("Native library unavailable");
        if (modelPath == null || modelPath.isEmpty() || prompt == null || prompt.isEmpty()
            || maxTokens < 1 || maxTokens > 2048) throw new IllegalArgumentException("Invalid inference arguments");
        return runModel(modelPath, prompt, maxTokens);
    }
}
