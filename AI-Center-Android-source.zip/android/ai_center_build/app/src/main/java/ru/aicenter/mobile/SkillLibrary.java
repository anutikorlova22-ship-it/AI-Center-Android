package ru.aicenter.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** User-approved, data-only skill cards. No code, shell commands or remote execution. */
public final class SkillLibrary {
    private static final String PREFS="approved_skills_v1";
    private static final int MAX_SKILLS=100, MAX_INPUT=65536;
    private SkillLibrary(){}
    public static JSONObject validate(String json) throws Exception {
        if(json==null || json.length()>MAX_INPUT)throw new IllegalArgumentException("Файл навыка слишком большой");
        JSONObject input=new JSONObject(json);
        String name=input.optString("name", "").trim();
        String instructions=input.optString("instructions", "").trim();
        if(name.length()<2 || name.length()>80 || instructions.length()<10 || instructions.length()>12000)
            throw new IllegalArgumentException("Нужны name (2–80) и instructions (10–12000)");
        if(input.has("script") || input.has("code") || input.has("command") || input.has("exec") || input.has("url"))
            throw new IllegalArgumentException("Исполняемые навыки и внешние URL не поддерживаются");
        JSONObject clean=new JSONObject();
        clean.put("name",name);clean.put("instructions",instructions);clean.put("source","user_import");
        return clean;
    }
    public static int save(Context context,JSONObject skill) throws Exception {
        SharedPreferences p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        JSONArray list=new JSONArray(p.getString("items","[]"));
        JSONArray updated=new JSONArray();
        for(int i=0;i<list.length();i++){
            JSONObject item=list.optJSONObject(i);
            if(item!=null && !skill.getString("name").equalsIgnoreCase(item.optString("name")))updated.put(item);
        }
        if(updated.length()>=MAX_SKILLS)throw new IllegalStateException("Библиотека навыков заполнена");
        updated.put(skill);
        if(!p.edit().putString("items",updated.toString()).commit())throw new IllegalStateException("Ошибка сохранения");
        return updated.length();
    }
    public static JSONArray list(Context context) throws Exception {
        return new JSONArray(context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString("items","[]"));
    }
}
