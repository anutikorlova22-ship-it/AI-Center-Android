package ru.aicenter.mobile;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Best-effort reminders while Termux's local server remains running.
 * Android Doze, battery policy, reboot, or stopped Termux may delay or prevent delivery.
 */
public final class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL="ai_center_reminders";
    private static final long INTERVAL=15*60*1000L;
    public static void schedule(Context context){
        AlarmManager alarm=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(alarm==null)return;
        Intent intent=new Intent(context,ReminderReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(context,201,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        alarm.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
            android.os.SystemClock.elapsedRealtime()+INTERVAL,INTERVAL,pi);
    }
    @Override public void onReceive(Context context,Intent intent){
        final PendingResult result=goAsync();
        final Context app=context.getApplicationContext();
        new Thread(()->{
            try{checkNative(app);check(app);}finally{result.finish();}
        },"reminder-check").start();
    }
    private static void checkNative(Context context){
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(manager==null)return;
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Напоминания ИИ Центра",NotificationManager.IMPORTANCE_DEFAULT));
        NativeStore store=new NativeStore(context);
        try{
            JSONArray due=store.dueTasks(System.currentTimeMillis());
            for(int i=0;i<due.length();i++){
                JSONObject item=due.getJSONObject(i);long id=item.getLong("id");
                String title=item.getString("title");
                Intent open=new Intent(context,MainActivity.class);
                PendingIntent action=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                Notification note=new Notification.Builder(context,CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle("ИИ Центр · Напоминание").setContentText(title)
                    .setStyle(new Notification.BigTextStyle().bigText(title))
                    .setContentIntent(action).setAutoCancel(true).build();
                manager.notify((int)(id%1000000000L)+1000000000,note);
                store.markNotified(id);
            }
        }catch(Exception ignored){}finally{store.close();}
    }
    private static void check(Context context){
        HttpURLConnection connection=null;
        try{
            connection=(HttpURLConnection)new URL("http://127.0.0.1:8765/api/v30/reminders").openConnection();
            connection.setConnectTimeout(1500);connection.setReadTimeout(2500);
            if(connection.getResponseCode()!=200)return;
            ByteArrayOutputStream output=new ByteArrayOutputStream();
            try(InputStream in=connection.getInputStream()){
                byte[] buf=new byte[4096];int n;
                while((n=in.read(buf))!=-1){if(output.size()+n>65536)return;output.write(buf,0,n);}
            }
            JSONArray items=new JSONObject(output.toString("UTF-8")).optJSONArray("items");
            if(items==null)return;
            if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(manager==null)return;
            if(Build.VERSION.SDK_INT>=26){
                NotificationChannel channel=new NotificationChannel(CHANNEL,"Напоминания ИИ Центра",NotificationManager.IMPORTANCE_DEFAULT);
                manager.createNotificationChannel(channel);
            }
            SharedPreferences prefs=context.getSharedPreferences("reminder_notifications",Context.MODE_PRIVATE);
            for(int i=0;i<items.length();i++){
                JSONObject item=items.optJSONObject(i);
                if(item==null||!item.optBoolean("due",false)||!"pending".equals(item.optString("status")))continue;
                int id=item.optInt("id",-1);
                if(id<0||prefs.getBoolean("shown_"+id,false))continue;
                String title=item.optString("title","Напоминание");
                if(title.length()>160)title=title.substring(0,160);
                Intent open=new Intent(context,MainActivity.class);
                open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                PendingIntent action=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                Notification note=new Notification.Builder(context,CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle("ИИ Центр · Напоминание").setContentText(title)
                    .setStyle(new Notification.BigTextStyle().bigText(title))
                    .setContentIntent(action).setAutoCancel(true).build();
                manager.notify(id,note);
                prefs.edit().putBoolean("shown_"+id,true).apply();
            }
        }catch(Exception ignored){}finally{if(connection!=null)connection.disconnect();}
    }
}
