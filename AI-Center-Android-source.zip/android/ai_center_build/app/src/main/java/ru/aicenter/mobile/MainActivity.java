package ru.aicenter.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.EditText;
import android.text.InputType;
import android.app.AlarmManager;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Environment;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String CHAT="http://127.0.0.1:8765/", MONITOR="http://127.0.0.1:8766/status", RESEARCH="http://127.0.0.1:8765/v30.html";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService pool=Executors.newSingleThreadExecutor();
    private final int BG=Color.rgb(8,19,38), ACCENT=Color.rgb(71,191,245);
    private LinearLayout root, nav, home, dashboard, loading;
    private Button[] navButtons=new Button[4];
    private WebView web, researchWeb;
    private TextView headline, report, summary;
    private Orb orb;
    private TextToSpeech speech;
    private boolean speechReady=false;
    private static final int VOICE_REQUEST=510;
    private static final int SKILL_IMPORT_REQUEST=511;
    private static final int MODEL_IMPORT_REQUEST=512;
    private static final String ALERT_CHANNEL="ai_center_reminders";
    private static final String REMINDERS="http://127.0.0.1:8765/api/v30/reminders";
    private final Runnable reminderLoop=new Runnable(){public void run(){if(!alive)return;pollReminders();handler.postDelayed(this,60000);}};
    private LinearLayout voiceControls;
    private NativeStore nativeStore;
    private boolean alive=true, chatLoaded=false, researchLoaded=false;
    private int page=0, polls=0;
    private final Runnable refreshLoop=new Runnable(){ public void run(){ if(!alive)return; refresh(); handler.postDelayed(this,15000); }};
    int dp(int x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable pill(int fill,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(14));d.setStroke(dp(1),stroke);return d;}
    private Button styled(String label,boolean active){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(active?BG:Color.rgb(203,232,250));b.setBackground(pill(active?ACCENT:Color.rgb(17,46,77),active?ACCENT:Color.rgb(38,105,148)));b.setElevation(0);return b;}
    private void styleNav(){for(int i=0;i<navButtons.length;i++){boolean active=i==page;navButtons[i].setBackground(pill(active?ACCENT:Color.rgb(17,46,77),active?ACCENT:Color.rgb(38,105,148)));navButtons[i].setTextColor(active?BG:Color.rgb(203,232,250));}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==MODEL_IMPORT_REQUEST){
            if(resultCode!=RESULT_OK || data==null || data.getData()==null)return;
            Uri modelUri=data.getData();
            new android.app.AlertDialog.Builder(this).setTitle("Импорт GGUF")
                .setMessage("Модель будет скопирована в закрытое хранилище приложения. Для офлайн-ответов необходима сборка с llama.cpp. Импорт модели сам по себе не включает движок.")
                .setNegativeButton("Отмена",(d,w)->{})
                .setPositiveButton("Импортировать",(d,w)->pool.execute(()->{
                    try{long bytes=NativeModelManager.importModel(this,modelUri);
                        runOnUiThread(()->Toast.makeText(this,"GGUF импортирован: "+(bytes/1048576)+" МиБ",Toast.LENGTH_LONG).show());
                    }catch(Exception ex){runOnUiThread(()->Toast.makeText(this,"GGUF: "+ex.getMessage(),Toast.LENGTH_LONG).show());}
                })).show();
            return;
        }
        if(requestCode!=SKILL_IMPORT_REQUEST || resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        Uri selected=data.getData();
        pool.execute(()->{
            try(InputStream in=getContentResolver().openInputStream(selected)){
                if(in==null)throw new IllegalArgumentException("Не удалось открыть файл");
                ByteArrayOutputStream buffer=new ByteArrayOutputStream();byte[] bytes=new byte[4096];int n;
                while((n=in.read(bytes))!=-1){if(buffer.size()+n>65536)throw new IllegalArgumentException("Файл больше 64 КБ");buffer.write(bytes,0,n);}
                JSONObject skill=SkillLibrary.validate(buffer.toString("UTF-8"));
                runOnUiThread(()->new android.app.AlertDialog.Builder(this)
                    .setTitle("Подключить навык: "+skill.optString("name"))
                    .setMessage("Навык содержит инструкции, а не исполняемый код.\n\n"+skill.optString("instructions"))
                    .setNegativeButton("Отмена",(d,w)->{})
                    .setPositiveButton("Сохранить",(d,w)->{
                        try{int count=SkillLibrary.save(this,skill);Toast.makeText(this,"Сохранено навыков: "+count+". Синхронизация с Qwen при доступности сервера.",Toast.LENGTH_LONG).show();pool.execute(()->syncApprovedSkill(skill));}
                        catch(Exception ex){Toast.makeText(this,ex.getMessage(),Toast.LENGTH_LONG).show();}
                    }).show());
            }catch(Exception ex){runOnUiThread(()->Toast.makeText(this,"Импорт: "+ex.getMessage(),Toast.LENGTH_LONG).show());}
        });
    }
    /** Native inference never uses the Termux server. It fails visibly if llama.cpp is absent. */
    private void showOfflineChat(){
        if(!NativeModelManager.isInstalled(this)){
            new AlertDialog.Builder(this).setTitle("Нет локальной модели")
                .setMessage("Сначала импортируйте GGUF-модель. Модель хранится только в приложении.")
                .setPositiveButton("Понятно",(d,w)->{}).show();
            return;
        }
        if(!NativeInference.libraryLoaded() || !NativeInference.status().contains("llama.cpp inference linked")){
            new AlertDialog.Builder(this).setTitle("Нативный движок недоступен")
                .setMessage("Для настоящего офлайн-чата нужно собрать APK с проверенными исходниками llama.cpp. Termux не используется в этом режиме.")
                .setPositiveButton("Понятно",(d,w)->{}).show();
            return;
        }
        final EditText question=new EditText(this);
        question.setHint("Напишите вопрос для локальной Qwen");
        question.setMinLines(3);
        question.setMaxLines(6);
        new AlertDialog.Builder(this).setTitle("Офлайн Qwen")
            .setView(question).setNegativeButton("Отмена",(d,w)->{})
            .setPositiveButton("Спросить",(d,w)->{
                final String prompt=question.getText().toString().trim();
                if(prompt.isEmpty())return;
                final AlertDialog waiting=new AlertDialog.Builder(this).setTitle("Qwen")
                    .setMessage("Генерация ответа на устройстве…").setCancelable(false).create();
                waiting.show();
                pool.execute(()->{
                    String answer;
                    try{
                        String contextualPrompt=OfflinePrompt.compose(this,nativeStore,prompt);
                        answer=NativeInference.generate(NativeModelManager.modelFile(this).getAbsolutePath(),contextualPrompt,256);
                        if(answer==null || answer.trim().isEmpty())answer="Модель не вернула текст.";
                        else nativeStore.saveExchange(prompt,answer);
                    }catch(Exception | LinkageError ex){answer="Офлайн-генерация недоступна: "+ex.getClass().getSimpleName()+": "+ex.getMessage();}
                    final String result=answer;
                    runOnUiThread(()->{
                        if(isFinishing() || isDestroyed()){waiting.dismiss();return;}
                        waiting.dismiss();
                        new AlertDialog.Builder(this).setTitle("Ответ Qwen (офлайн)")
                            .setMessage(result).setPositiveButton("Закрыть",(d,w)->{})
                            .setNeutralButton("Поделиться",(d,w)->{
                                Intent send=new Intent(Intent.ACTION_SEND);
                                send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,result);
                                startActivity(Intent.createChooser(send,"Поделиться ответом"));
                            }).show();
                    });
                });
            }).show();
    }
    private void syncApprovedSkill(JSONObject skill){
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL("http://127.0.0.1:8765/api/v40/skills/approve").openConnection();
            c.setRequestMethod("POST");c.setConnectTimeout(2000);c.setReadTimeout(3000);
            c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");
            byte[] body=skill.toString().getBytes("UTF-8");
            try(java.io.OutputStream out=c.getOutputStream()){out.write(body);}
            if(c.getResponseCode()!=200)throw new Exception("HTTP "+c.getResponseCode());
        }catch(Exception ex){runOnUiThread(()->Toast.makeText(this,"Навык сохранён в Android. Синхронизация с Qwen пока недоступна.",Toast.LENGTH_LONG).show());}
        finally{if(c!=null)c.disconnect();}
    }
    private void reviewSkillCandidates(){
        pool.execute(()->{
            HttpURLConnection connection=null;
            try{
                connection=(HttpURLConnection)new URL("http://127.0.0.1:8765/api/v42/skills/pending").openConnection();
                connection.setConnectTimeout(2000);connection.setReadTimeout(3000);
                if(connection.getResponseCode()!=200)throw new Exception("HTTP "+connection.getResponseCode());
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                try(InputStream in=connection.getInputStream()){
                    byte[] bytes=new byte[2048];int n;
                    while((n=in.read(bytes))!=-1){if(out.size()+n>100000)throw new Exception("Ответ слишком большой");out.write(bytes,0,n);}
                }
                JSONArray items=new JSONObject(out.toString("UTF-8")).getJSONArray("items");
                runOnUiThread(()->{
                    if(items.length()==0){Toast.makeText(this,"Нет навыков на проверке",Toast.LENGTH_SHORT).show();return;}
                    showSkillCandidate(items,0);
                });
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Проверка навыков: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            finally{if(connection!=null)connection.disconnect();}
        });
    }
    private void showSkillCandidate(JSONArray items,int index){
        if(index>=items.length()){Toast.makeText(this,"Проверка завершена",Toast.LENGTH_SHORT).show();return;}
        JSONObject item=items.optJSONObject(index);
        if(item==null){showSkillCandidate(items,index+1);return;}
        JSONArray flags=item.optJSONArray("risk_flags");
        boolean risky=flags!=null && flags.length()>0;
        String details="Источник: "+item.optString("origin")+"\nРиски: "+(risky?flags.toString():"не обнаружены автоматической проверкой")+"\n\n"+item.optString("instructions");
        android.app.AlertDialog.Builder dialog=new android.app.AlertDialog.Builder(this)
            .setTitle("Навык: "+item.optString("name"))
            .setMessage(details)
            .setNeutralButton("Позже",(d,w)->showSkillCandidate(items,index+1))
            .setNegativeButton("Отклонить",(d,w)->decideSkillCandidate(item.optString("id"),false,items,index));
        if(!risky)dialog.setPositiveButton("Одобрить",(d,w)->decideSkillCandidate(item.optString("id"),true,items,index));
        dialog.show();
    }
    private void decideSkillCandidate(String id,boolean approve,JSONArray items,int index){
        pool.execute(()->{
            HttpURLConnection connection=null;
            try{
                connection=(HttpURLConnection)new URL("http://127.0.0.1:8765/api/v42/skills/decide").openConnection();
                connection.setRequestMethod("POST");connection.setDoOutput(true);
                connection.setConnectTimeout(2000);connection.setReadTimeout(3000);
                connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
                byte[] body=new JSONObject().put("id",id).put("approve",approve).toString().getBytes("UTF-8");
                try(java.io.OutputStream stream=connection.getOutputStream()){stream.write(body);}
                if(connection.getResponseCode()!=200)throw new Exception("HTTP "+connection.getResponseCode());
                runOnUiThread(()->showSkillCandidate(items,index+1));
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Не удалось сохранить решение: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            finally{if(connection!=null)connection.disconnect();}
        });
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        nativeStore=new NativeStore(this);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(18),dp(12),dp(18),dp(12));
        TextView brand=text("◈  ИИ ЦЕНТР",19,Color.WHITE);bar.addView(brand,new LinearLayout.LayoutParams(0,dp(40),1));
        headline=text("● ПРОВЕРКА",11,ACCENT);bar.addView(headline);root.addView(bar);
        nav=new LinearLayout(this);nav.setPadding(dp(8),0,dp(8),dp(6));
        String[] names={"Главная","Чат","Поиск","Контроль"};for(int i=0;i<4;i++){final int target=i;Button btn=styled(names[i],i==0);navButtons[i]=btn;btn.setOnClickListener(v->show(target));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(48),1);np.setMargins(dp(4),0,dp(4),0);nav.addView(btn,np);}root.addView(nav);
        home=new LinearLayout(this);home.setGravity(Gravity.CENTER_HORIZONTAL);home.setOrientation(LinearLayout.VERTICAL);home.setPadding(dp(16),dp(8),dp(16),dp(8));
        TextView hello=text("Твой локальный командный центр",17,Color.WHITE);hello.setGravity(Gravity.CENTER);home.addView(hello);
        orb=new Orb();home.addView(orb,new LinearLayout.LayoutParams(-1,0,1));
        summary=text("Проверяю сервисы…",15,Color.LTGRAY);summary.setGravity(Gravity.CENTER);home.addView(summary,new LinearLayout.LayoutParams(-1,dp(140)));
        Button go=styled("Открыть чат  →",true);go.setOnClickListener(v->show(1));home.addView(go,new LinearLayout.LayoutParams(-1,dp(50)));
        Button importSkill=styled("📚 Импорт навыка (.json)",false);
        importSkill.setOnClickListener(v->{
            Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("application/json");pick.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(pick,SKILL_IMPORT_REQUEST);
        });
        home.addView(importSkill,new LinearLayout.LayoutParams(-1,dp(48)));
        Button importModel=styled("🧠 Импорт локальной модели GGUF",false);
        importModel.setOnClickListener(v->{
            Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("*/*");pick.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(pick,MODEL_IMPORT_REQUEST);
        });
        home.addView(importModel,new LinearLayout.LayoutParams(-1,dp(48)));
        Button offlineChat=styled("🧠 Офлайн-чат (экспериментальный)",false);
        offlineChat.setOnClickListener(v->showOfflineChat());
        home.addView(offlineChat,new LinearLayout.LayoutParams(-1,dp(48)));
        Button reviewSkills=styled("🔎 Проверить новые навыки",false);
        reviewSkills.setOnClickListener(v->reviewSkillCandidates());
        home.addView(reviewSkills,new LinearLayout.LayoutParams(-1,dp(48)));
        Button nativeNotes=styled("📝 Локальные заметки",false);
        nativeNotes.setOnClickListener(v->showNativeNotes());
        home.addView(nativeNotes,new LinearLayout.LayoutParams(-1,dp(48)));
        Button nativeTasks=styled("⏰ Локальные напоминания",false);
        nativeTasks.setOnClickListener(v->showNativeTasks());
        home.addView(nativeTasks,new LinearLayout.LayoutParams(-1,dp(48)));
        Button hybrid=styled("🔗 Android + Termux + Google Диск",false);
        hybrid.setOnClickListener(v->showHybridServices());
        Button backup=styled("💾 Резервная копия Android → Termux",false);
        backup.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Резервная копия").setMessage("Отправить заметки и активные задачи в локальную базу Termux? На Google Диск они автоматически не загружаются.").setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->backupNativeData()).show());
        home.addView(backup,new LinearLayout.LayoutParams(-1,dp(48)));
        home.addView(hybrid,new LinearLayout.LayoutParams(-1,dp(48)));
        root.addView(home,new LinearLayout.LayoutParams(-1,0,1));
        web=new WebView(this);web.setBackgroundColor(BG);WebSettings ws=web.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);ws.setAllowFileAccess(false);ws.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){android.net.Uri u=r.getUrl();if("http".equals(u.getScheme())&&"127.0.0.1".equals(u.getHost())&&(u.getPort()==8765||u.getPort()==8767))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;}});
        voiceControls=new LinearLayout(this);
        voiceControls.setPadding(dp(12),dp(4),dp(12),dp(4));
        Button dictate=styled("🎙 Диктовать",false);
        dictate.setOnClickListener(v->startVoiceInput());
        voiceControls.addView(dictate,new LinearLayout.LayoutParams(0,dp(44),1));
        Button speak=styled("🔊 Прочитать ответ",false);
        speak.setOnClickListener(v->readLastAnswer());
        LinearLayout.LayoutParams speechParams=new LinearLayout.LayoutParams(0,dp(44),1);
        speechParams.setMargins(dp(8),0,0,0);
        voiceControls.addView(speak,speechParams);
        Button share=styled("↗ Поделиться",false);
        share.setOnClickListener(v->shareLastAnswer());
        LinearLayout.LayoutParams shareParams=new LinearLayout.LayoutParams(0,dp(44),1);
        shareParams.setMargins(dp(8),0,0,0);
        voiceControls.addView(share,shareParams);
        root.addView(voiceControls);
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        researchWeb=new WebView(this);researchWeb.setBackgroundColor(BG);
        WebSettings rs=researchWeb.getSettings();rs.setJavaScriptEnabled(true);rs.setDomStorageEnabled(true);rs.setAllowFileAccess(false);rs.setAllowContentAccess(false);
        researchWeb.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){android.net.Uri u=r.getUrl();if("http".equals(u.getScheme())&&"127.0.0.1".equals(u.getHost())&&u.getPort()==8765)return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;}});
        researchWeb.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{
            try{
                Uri uri=Uri.parse(url);
                if(!"http".equals(uri.getScheme()) || !"127.0.0.1".equals(uri.getHost()) || uri.getPort()!=8765 || !"/api/v36/office/download".equals(uri.getPath())){
                    Toast.makeText(this,"Загрузка с неизвестного адреса запрещена",Toast.LENGTH_LONG).show();return;
                }
                String token=uri.getQueryParameter("token");
                if(token==null || !token.matches("[A-Za-z0-9_-]{20,64}"))return;
                String name=(mimeType!=null && mimeType.contains("spreadsheet"))?"ai_center_report.xlsx":"ai_center_report.docx";
                DownloadManager.Request request=new DownloadManager.Request(uri);
                request.setTitle(name);
                request.setMimeType(mimeType);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,name);
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                Toast.makeText(this,"Загрузка в папку Download",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Ошибка загрузки: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        });
        root.addView(researchWeb,new LinearLayout.LayoutParams(-1,0,1));
        ScrollView scroll=new ScrollView(this);dashboard=new LinearLayout(this);dashboard.setPadding(dp(20),dp(12),dp(20),dp(20));dashboard.setOrientation(LinearLayout.VERTICAL);
        TextView heading=text("Состояние системы",23,Color.WHITE);dashboard.addView(heading);report=text("Проверяю…",15,Color.LTGRAY);report.setPadding(0,dp(15),0,dp(20));dashboard.addView(report);
        Button update=styled("↻  Обновить состояние",false);update.setOnClickListener(v->refresh());dashboard.addView(update);scroll.addView(dashboard);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));dashboard.setTag(scroll);
        loading=new LinearLayout(this);loading.setGravity(Gravity.CENTER);loading.setOrientation(LinearLayout.VERTICAL);TextView wait=text("Запускаю локальный сервер…",17,Color.WHITE);loading.addView(wait);
        Button retry=styled("Повторить запуск",true);retry.setOnClickListener(v->startServices());loading.addView(retry);root.addView(loading,new LinearLayout.LayoutParams(-1,0,1));
        speech=new TextToSpeech(this,status->{
            if(status==TextToSpeech.SUCCESS){
                speechReady=true;
                speech.setLanguage(new Locale("ru","RU"));
            }
        });
        setContentView(root);show(0);createNotificationChannel();requestNotificationPermission();ReminderReceiver.schedule(this);startServices();handler.post(refreshLoop);handler.postDelayed(reminderLoop,15000);
    }
    private void showHybridServices(){
        new AlertDialog.Builder(this).setTitle("Службы ИИ Центра")
            .setMessage("Заметки, напоминания и история офлайн-чата хранятся в Android. Исследования, экспорт документов, индекс знаний и Google Диск пока работают через Termux. Синхронизация Диска запускается только по твоей команде.")
            .setNeutralButton("Проверить",(d,w)->hybridRequest(false))
            .setPositiveButton("Синхронизировать Диск",(d,w)->new AlertDialog.Builder(this)
                .setTitle("Google Диск")
                .setMessage("Скачать выбранные файлы AI_MEMORY_HQ через настроенный rclone? Локальные заметки Android не удаляются.")
                .setNegativeButton("Отмена",null)
                .setPositiveButton("Запустить",(d2,w2)->hybridRequest(true)).show())
            .setNegativeButton("Закрыть",null).show();
    }
    private void backupNativeData(){
        pool.execute(()->{
            HttpURLConnection c=null;String message;
            try{
                JSONObject data=new JSONObject().put("schema",1).put("notes",nativeStore.latestNotes(100)).put("tasks",nativeStore.pendingTasks(100));
                byte[] bytes=data.toString().getBytes("UTF-8");
                c=(HttpURLConnection)new URL("http://127.0.0.1:8765/api/v68/native/backup").openConnection();
                c.setConnectTimeout(4000);c.setReadTimeout(15000);c.setRequestMethod("POST");c.setDoOutput(true);
                c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                c.setRequestProperty("X-AI-Center-Action","confirmed-native-backup");
                c.setFixedLengthStreamingMode(bytes.length);
                try(java.io.OutputStream output=c.getOutputStream()){output.write(bytes);}
                int code=c.getResponseCode();
                message="HTTP "+code+" — "+(code==200?"Копия сохранена в Termux":"Не удалось сохранить копию");
            }catch(Exception ex){message="Резервное копирование не выполнено: "+ex.getMessage();}
            finally{if(c!=null)c.disconnect();}
            final String result=message;
            runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Резервная копия").setMessage(result).setPositiveButton("OK",null).show());
        });
    }
    private void hybridRequest(boolean sync){
        pool.execute(()->{
            HttpURLConnection c=null;
            String output;
            try{
                String endpoint=sync?"/api/v67/hybrid/drive/sync":"/api/v67/hybrid/status";
                c=(HttpURLConnection)new URL("http://127.0.0.1:8765"+endpoint).openConnection();
                c.setConnectTimeout(4000);c.setReadTimeout(sync?250000:10000);
                if(sync){c.setRequestMethod("POST");c.setRequestProperty("X-AI-Center-Action","confirmed-drive-sync");c.setFixedLengthStreamingMode(0);}
                int code=c.getResponseCode();
                InputStream stream=code<400?c.getInputStream():c.getErrorStream();
                ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] b=new byte[2048];int n;
                while(stream!=null&&(n=stream.read(b))!=-1){if(buf.size()+n>12000)break;buf.write(b,0,n);}
                output="HTTP "+code+"\n"+buf.toString("UTF-8");
            }catch(Exception ex){output="Termux-сервер недоступен: "+ex.getMessage();}
            finally{if(c!=null)c.disconnect();}
            final String message=output;
            runOnUiThread(()->new AlertDialog.Builder(this).setTitle(sync?"Синхронизация Google Диска":"Состояние служб")
                .setMessage(message).setPositiveButton("OK",null).show());
        });
    }
    private void showNativeNotes(){
        try{
            JSONArray notes=nativeStore.latestNotes(20);
            StringBuilder body=new StringBuilder();
            for(int i=0;i<notes.length();i++)body.append("• ").append(notes.getJSONObject(i).getString("body")).append("\n\n");
            new AlertDialog.Builder(this).setTitle("Локальная память")
                .setMessage(body.length()==0?"Заметок пока нет":body.toString())
                .setPositiveButton("Добавить",(d,w)->{
                    EditText input=new EditText(this);input.setHint("Текст заметки");
                    new AlertDialog.Builder(this).setTitle("Новая заметка").setView(input)
                        .setPositiveButton("Сохранить",(dd,ww)->{
                            try{nativeStore.addNote(input.getText().toString());Toast.makeText(this,"Сохранено локально",Toast.LENGTH_SHORT).show();}
                            catch(Exception e){Toast.makeText(this,"Ошибка: "+e.getMessage(),Toast.LENGTH_LONG).show();}
                        }).setNegativeButton("Отмена",null).show();
                }).setNegativeButton("Закрыть",null).show();
        }catch(Exception e){Toast.makeText(this,"Ошибка памяти: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void showNativeTasks(){
        try{
            JSONArray tasks=nativeStore.pendingTasks(50);
            String[] names=new String[tasks.length()];
            for(int i=0;i<tasks.length();i++){
                JSONObject t=tasks.getJSONObject(i);
                names[i]=t.getString("title")+" — "+new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new java.util.Date(t.getLong("due_ms")));
            }
            new AlertDialog.Builder(this).setTitle("Локальные напоминания")
                .setItems(names,(d,which)->{
                    try{long id=tasks.getJSONObject(which).getLong("id");
                        new AlertDialog.Builder(this).setTitle(names[which]).setMessage("Отметить выполненным?")
                            .setPositiveButton("Выполнено",(dd,w)->{nativeStore.completeTask(id);Toast.makeText(this,"Готово",Toast.LENGTH_SHORT).show();})
                            .setNegativeButton("Отмена",null).show();
                    }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
                })
                .setPositiveButton("Добавить",(d,w)->createNativeTask())
                .setNegativeButton("Закрыть",null).show();
        }catch(Exception e){Toast.makeText(this,"Ошибка задач: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void createNativeTask(){
        LinearLayout fields=new LinearLayout(this);fields.setOrientation(LinearLayout.VERTICAL);
        EditText title=new EditText(this);title.setHint("Что напомнить?");fields.addView(title);
        EditText minutes=new EditText(this);minutes.setHint("Через сколько минут? (от 1)");
        minutes.setInputType(InputType.TYPE_CLASS_NUMBER);fields.addView(minutes);
        new AlertDialog.Builder(this).setTitle("Новое напоминание").setView(fields)
            .setPositiveButton("Создать",(d,w)->{
                try{
                    long delay=Long.parseLong(minutes.getText().toString().trim());
                    if(delay<1||delay>5256000L)throw new IllegalArgumentException("Укажите от 1 до 5256000 минут");
                    long due=Math.addExact(System.currentTimeMillis(),Math.multiplyExact(delay,60000L));
                    nativeStore.addTask(title.getText().toString(),due);
                    ReminderReceiver.schedule(this);
                    Toast.makeText(this,"Напоминание сохранено на телефоне",Toast.LENGTH_SHORT).show();
                }catch(Exception e){Toast.makeText(this,"Ошибка: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            }).setNegativeButton("Отмена",null).show();
    }
    private void show(int selected){voiceControls.setVisibility(selected==1?View.VISIBLE:View.GONE);page=selected;styleNav();home.setVisibility(selected==0?View.VISIBLE:View.GONE);web.setVisibility(selected==1?View.VISIBLE:View.GONE);researchWeb.setVisibility(selected==2?View.VISIBLE:View.GONE);((View)dashboard.getTag()).setVisibility(selected==3?View.VISIBLE:View.GONE);loading.setVisibility(View.GONE);if(selected==1&&!chatLoaded){chatLoaded=true;web.loadUrl(CHAT);}if(selected==2&&!researchLoaded){researchLoaded=true;researchWeb.loadUrl(RESEARCH);}if(selected==3)refresh();}
    private void startVoiceInput(){
        try{
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ru-RU");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Говорите");
            startActivityForResult(i,VOICE_REQUEST);
        }catch(Exception e){
            Toast.makeText(this,"На устройстве нет доступного распознавания речи",Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=VOICE_REQUEST||resultCode!=RESULT_OK||data==null)return;
        ArrayList<String> phrases=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if(phrases==null||phrases.isEmpty())return;
        String recognized=phrases.get(0);
        show(1);
        web.evaluateJavascript("document.getElementById('cmd').value="+JSONObject.quote(recognized)+";document.getElementById('cmd').focus();",null);
    }
    private void readLastAnswer(){
        if(!speechReady){Toast.makeText(this,"Озвучивание пока недоступно",Toast.LENGTH_SHORT).show();return;}
        web.evaluateJavascript("(function(){var a=document.querySelectorAll('#chatlog .assistant,#chatlog [data-role=assistant]');return a.length?a[a.length-1].innerText:''})()",result->{
            try{
                Object decoded=new org.json.JSONTokener(result).nextValue();
                String response=decoded==null?"":decoded.toString();
                if(response.trim().isEmpty()){Toast.makeText(this,"Сначала получи ответ в чате",Toast.LENGTH_SHORT).show();return;}
                speech.speak(response,TextToSpeech.QUEUE_FLUSH,null,"ai_center_reply");
            }catch(Exception e){Toast.makeText(this,"Не удалось прочитать ответ",Toast.LENGTH_SHORT).show();}
        });
    }
    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel channel=new NotificationChannel(ALERT_CHANNEL,"Напоминания ИИ Центра",NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Наступившие напоминания из локальной базы");
            NotificationManager manager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            if(manager!=null)manager.createNotificationChannel(channel);
        }
    }
    private void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},72);
        }
    }
    private void pollReminders(){
        pool.execute(()->{
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(REMINDERS).openConnection();
                c.setConnectTimeout(1200);c.setReadTimeout(2500);
                if(c.getResponseCode()!=200)return;
                ByteArrayOutputStream data=new ByteArrayOutputStream();
                try(InputStream in=c.getInputStream()){
                    byte[] buf=new byte[4096];int n;
                    while((n=in.read(buf))!=-1){
                        if(data.size()+n>65536)return;
                        data.write(buf,0,n);
                    }
                }
                JSONArray items=new JSONObject(data.toString("UTF-8")).optJSONArray("items");
                if(items==null)return;
                SharedPreferences prefs=getSharedPreferences("reminder_notifications",MODE_PRIVATE);
                for(int i=0;i<items.length();i++){
                    JSONObject item=items.optJSONObject(i);
                    if(item==null||!item.optBoolean("due",false)||!"pending".equals(item.optString("status")))continue;
                    int id=item.optInt("id",-1);if(id<0||prefs.getBoolean("shown_"+id,false))continue;
                    String title=item.optString("title","Напоминание");
                    if(title.length()>160)title=title.substring(0,160);
                    final int alertId=id;final String alertTitle=title;
                    handler.post(()->showReminder(alertId,alertTitle));
                }
            }catch(Exception ignored){}finally{if(c!=null)c.disconnect();}
        });
    }
    private void showReminder(int id,String title){
        if(!alive)return;
        SharedPreferences prefs=getSharedPreferences("reminder_notifications",MODE_PRIVATE);
        if(prefs.getBoolean("shown_"+id,false))return;
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager manager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(manager==null)return;
        Intent open=new Intent(this,MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent action=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification note=new Notification.Builder(this,ALERT_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("ИИ Центр · Напоминание")
                .setContentText(title).setStyle(new Notification.BigTextStyle().bigText(title))
                .setContentIntent(action).setAutoCancel(true).build();
        manager.notify(id,note);
        prefs.edit().putBoolean("shown_"+id,true).apply();
    }
    private void shareLastAnswer(){
        web.evaluateJavascript("(function(){var a=document.querySelectorAll('#chatlog .assistant,#chatlog [data-role=assistant]');return a.length?a[a.length-1].innerText:''})()",result->{
            try{
                Object decoded=new org.json.JSONTokener(result).nextValue();
                String answer=decoded==null?"":decoded.toString().trim();
                if(answer.isEmpty()){Toast.makeText(this,"Сначала получи ответ в чате",Toast.LENGTH_SHORT).show();return;}
                Intent send=new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,answer);
                startActivity(Intent.createChooser(send,"Поделиться ответом"));
            }catch(Exception e){Toast.makeText(this,"Не удалось подготовить ответ",Toast.LENGTH_SHORT).show();}
        });
    }
    private boolean ping(String url){HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(1200);c.setReadTimeout(1500);return c.getResponseCode()==200;}catch(Exception e){return false;}finally{if(c!=null)c.disconnect();}}
    private void startServices(){pool.execute(()->{boolean a=ping(CHAT),b=ping(MONITOR);if(!a||!b)handler.post(this::launchTermux);else handler.post(this::refresh);});}
    private void launchTermux(){try{if(Build.VERSION.SDK_INT>=23&&checkSelfPermission("com.termux.permission.RUN_COMMAND")!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"com.termux.permission.RUN_COMMAND"},71);return;}
        Intent i=new Intent("com.termux.RUN_COMMAND");i.setClassName("com.termux","com.termux.app.RunCommandService");i.putExtra("com.termux.RUN_COMMAND_PATH","/data/data/com.termux/files/usr/bin/bash");i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",new String[]{"/data/data/com.termux/files/home/AI_CENTER/bin/launch_from_android.sh"});i.putExtra("com.termux.RUN_COMMAND_WORKDIR","/data/data/com.termux/files/home");i.putExtra("com.termux.RUN_COMMAND_BACKGROUND",true);startService(i);polls=0;handler.postDelayed(this::poll,2000);
    }catch(Exception e){headline.setText("● НУЖЕН TERMUX");summary.setText("Не удалось запустить службы: "+e.getClass().getSimpleName());}}
    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] grants){super.onRequestPermissionsResult(req,perms,grants);if(req==71&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)launchTermux();}
    private void poll(){if(!alive)return;pool.execute(()->{boolean ok=ping(CHAT)&&ping(MONITOR);handler.post(()->{if(!alive)return;if(ok){refresh();if(page==1)web.reload();}else if(++polls<30)handler.postDelayed(this::poll,2000);else{headline.setText("● СЛУЖБЫ НЕ ГОТОВЫ");summary.setText("Проверь журнал Termux: ~/AI_CENTER/logs/status_server.log");}});});}
    private void refresh(){pool.execute(()->{String out;String shortText;boolean good=false;try{HttpURLConnection c=(HttpURLConnection)new URL(MONITOR).openConnection();c.setConnectTimeout(1800);c.setReadTimeout(5000);if(c.getResponseCode()!=200)throw new Exception("HTTP "+c.getResponseCode());ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1&&bytes.size()<250000)bytes.write(buf,0,n);}c.disconnect();JSONObject j=new JSONObject(bytes.toString("UTF-8"));boolean chat=j.optBoolean("web_ok"),qwen=j.optBoolean("qwen_ok"),cron=j.optBoolean("cron_running"),net=j.optBoolean("internet_ok"),drive=j.optBoolean("drive_ok");good=chat;
        StringBuilder sb=new StringBuilder();sb.append("Сервер чата: ").append(dot(chat)).append("\n\nQwen: ").append(dot(qwen)).append("\n\nПланировщик: ").append(dot(cron)).append("\n\nИнтернет: ").append(dot(net)).append("\n\nGoogle Drive: ").append(dot(drive)).append("\n").append(j.optString("drive_detail",""));sb.append("\n\nБаза памяти: ").append(j.optString("database_status","неизвестно"));sb.append("\n\nПроверено: ").append(j.optString("checked_at","—"));sb.append("\n\nЗАДАЧИ И ВРЕМЯ ДО ЗАПУСКА\n");JSONArray jobs=j.optJSONArray("jobs");if(jobs!=null){for(int i=0;i<jobs.length();i++){JSONObject task=jobs.optJSONObject(i);if(task==null)continue;sb.append("\n◷ ").append(task.optString("name","Задача")).append("\n   Запуск: ").append(task.optString("next_run","—")).append("\n   Через: ").append(task.optString("countdown","—")).append("\n   Итог: ").append(task.optString("last_result","нет данных")).append("\n");}}out=sb.toString();shortText="Чат "+dot(chat)+"    Qwen "+dot(qwen)+"\nИнтернет "+dot(net)+"    Drive "+dot(drive)+"\nЗадач: "+(jobs==null?0:jobs.length());
    }catch(Exception ex){out="Мониторинг недоступен (127.0.0.1:8766).\n\nОткрой Termux и проверь status_server.log.\n"+ex.getClass().getSimpleName();shortText="Мониторинг пока не отвечает";}
    final String a=out,b=shortText;final boolean up=good;handler.post(()->{if(!alive)return;report.setText(a);summary.setText(b);headline.setText(up?"● СЕРВЕР В СЕТИ":"● ПРОВЕРКА СЛУЖБ");orb.setHealthy(up);});});}
    private String dot(boolean value){return value?"🟢 работает":"🟡 не подтверждено";}
    @Override public void onBackPressed(){if(page!=0){show(0);return;}super.onBackPressed();}
    @Override public void onDestroy(){alive=false;handler.removeCallbacksAndMessages(null);pool.shutdownNow();if(speech!=null){speech.stop();speech.shutdown();}web.destroy();researchWeb.destroy();super.onDestroy();}
    private class Orb extends View {private final Paint p=new Paint(3);private float phase=0;private boolean healthy=false;Orb(){super(MainActivity.this);}void setHealthy(boolean v){healthy=v;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float x=getWidth()/2f,y=getHeight()/2f;float radius=Math.min(getWidth(),getHeight())*.31f;phase+=.026f;float wobble=(float)Math.sin(phase)*radius*.035f;int core=healthy?Color.rgb(68,219,240):Color.rgb(65,154,224);p.setShader(new RadialGradient(x+radius*.1f*(float)Math.sin(phase*.7),y-radius*.25f,radius*1.13f,new int[]{Color.rgb(194,249,255),core,Color.rgb(13,46,91),BG},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,radius+wobble,p);p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.argb(110,80,205,255));c.drawCircle(x,y,radius*1.12f+wobble,p);p.setColor(Color.argb(45,80,205,255));c.drawCircle(x,y,radius*1.24f-wobble,p);p.setStyle(Paint.Style.FILL);if(alive)postInvalidateDelayed(33);}
    }
}
