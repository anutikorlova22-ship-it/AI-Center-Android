package ru.aicenter.mobile;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import org.json.JSONArray;
import org.json.JSONObject;

/** Android-owned storage: no Python, Termux or external server required. */
public final class NativeStore extends SQLiteOpenHelper {
    private static final int VERSION=2;
    private static final int MAX_TEXT=20000;
    public NativeStore(Context context){super(context,"ai_center_native.db",null,VERSION);}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT NOT NULL, created_ms INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, due_ms INTEGER NOT NULL, done INTEGER NOT NULL DEFAULT 0, notified INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX tasks_due ON tasks(done,notified,due_ms)");
        db.execSQL("CREATE TABLE chat_messages(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, body TEXT NOT NULL, created_ms INTEGER NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){
        // Never drop user data. Add explicit incremental migrations for future schema changes.
        if(oldVersion < 2 && newVersion >= 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS chat_messages(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, body TEXT NOT NULL, created_ms INTEGER NOT NULL)");
            oldVersion=2;
        }
        if(oldVersion!=newVersion)throw new IllegalStateException("Migration required: "+oldVersion+" -> "+newVersion);
    }
    public long addNote(String body){
        if(body==null||body.trim().isEmpty()||body.length()>MAX_TEXT)throw new IllegalArgumentException("Invalid note");
        ContentValues v=new ContentValues();v.put("body",body.trim());v.put("created_ms",System.currentTimeMillis());
        return getWritableDatabase().insertOrThrow("notes",null,v);
    }
    public JSONArray latestNotes(int limit)throws Exception{
        JSONArray result=new JSONArray();int bounded=Math.max(1,Math.min(limit,100));
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,body,created_ms FROM notes ORDER BY id DESC LIMIT "+bounded,null)){
            while(c.moveToNext())result.put(new JSONObject().put("id",c.getLong(0)).put("body",c.getString(1)).put("created_ms",c.getLong(2)));
        }
        return result;
    }
    public long addTask(String title,long dueMs){
        if(title==null||title.trim().isEmpty()||title.length()>500||dueMs<0)throw new IllegalArgumentException("Invalid task");
        ContentValues v=new ContentValues();v.put("title",title.trim());v.put("due_ms",dueMs);v.put("done",0);v.put("notified",0);
        return getWritableDatabase().insertOrThrow("tasks",null,v);
    }
    public JSONArray pendingTasks(int limit)throws Exception{
        JSONArray result=new JSONArray();int bounded=Math.max(1,Math.min(limit,100));
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,title,due_ms FROM tasks WHERE done=0 ORDER BY due_ms,id LIMIT "+bounded,null)){
            while(c.moveToNext())result.put(new JSONObject().put("id",c.getLong(0)).put("title",c.getString(1)).put("due_ms",c.getLong(2)));
        }
        return result;
    }
    public JSONArray dueTasks(long nowMs)throws Exception{
        JSONArray result=new JSONArray();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,title,due_ms FROM tasks WHERE done=0 AND notified=0 AND due_ms<=? ORDER BY due_ms,id LIMIT 100",new String[]{Long.toString(nowMs)})){
            while(c.moveToNext())result.put(new JSONObject().put("id",c.getLong(0)).put("title",c.getString(1)).put("due_ms",c.getLong(2)));
        }
        return result;
    }
    public boolean markNotified(long id){ContentValues v=new ContentValues();v.put("notified",1);return getWritableDatabase().update("tasks",v,"id=? AND notified=0",new String[]{Long.toString(id)})==1;}
    public boolean completeTask(long id){ContentValues v=new ContentValues();v.put("done",1);return getWritableDatabase().update("tasks",v,"id=?",new String[]{Long.toString(id)})==1;}
    /** Stores only completed exchanges, not errors or model failures. */
    public void saveExchange(String question, String answer){
        if(question==null||answer==null||question.trim().isEmpty()||answer.trim().isEmpty()
            ||question.length()>10000||answer.length()>20000)throw new IllegalArgumentException("Invalid exchange");
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try{
            ContentValues user=new ContentValues();user.put("role","user");user.put("body",question.trim());user.put("created_ms",System.currentTimeMillis());
            db.insertOrThrow("chat_messages",null,user);
            ContentValues assistant=new ContentValues();assistant.put("role","assistant");assistant.put("body",answer.trim());assistant.put("created_ms",System.currentTimeMillis());
            db.insertOrThrow("chat_messages",null,assistant);
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public JSONArray recentChat(int limit)throws Exception{
        int bounded=Math.max(1,Math.min(limit,40));
        JSONArray result=new JSONArray();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT role,body,created_ms FROM (SELECT id,role,body,created_ms FROM chat_messages ORDER BY id DESC LIMIT "+bounded+") ORDER BY id",null)){
            while(c.moveToNext())result.put(new JSONObject().put("role",c.getString(0)).put("body",c.getString(1)).put("created_ms",c.getLong(2)));
        }
        return result;
    }
}
