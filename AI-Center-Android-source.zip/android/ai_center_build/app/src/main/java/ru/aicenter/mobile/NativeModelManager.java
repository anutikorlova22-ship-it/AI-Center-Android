package ru.aicenter.mobile;

import android.content.Context;
import android.net.Uri;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** Manages GGUF files in app-private storage. Does not execute a model. */
public final class NativeModelManager {
    private static final long MAX_BYTES = 4L * 1024 * 1024 * 1024;
    private NativeModelManager() {}
    public static File modelFile(Context ctx) { return new File(ctx.getFilesDir(), "models/qwen.gguf"); }
    public static boolean validHeader(byte[] header) {
        return header != null && header.length >= 8 && header[0]=='G' && header[1]=='G'
            && header[2]=='U' && header[3]=='F' && (header[4] & 255) >= 2
            && header[5] == 0 && header[6] == 0 && header[7] == 0;
    }
    public static boolean isInstalled(Context ctx) {
        File file = modelFile(ctx);
        if (!file.isFile() || file.length() < 1024 || file.length() > MAX_BYTES) return false;
        try (InputStream in = new FileInputStream(file)) {
            byte[] head = new byte[8];
            return in.read(head) == 8 && validHeader(head);
        } catch (IOException e) { return false; }
    }
    public static long importModel(Context ctx, Uri uri) throws IOException {
        File dest = modelFile(ctx);
        File dir = dest.getParentFile();
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create model directory");
        File tmp = new File(dir, "qwen.gguf.partial");
        long total = 0;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new IOException("Cannot open GGUF file");
            byte[] buf = new byte[65536]; int n;
            byte[] header = new byte[8]; int headerSize = 0;
            while ((n = in.read(buf)) != -1) {
                if (total + n > MAX_BYTES) throw new IOException("GGUF too large");
                for (int i=0; i<n && headerSize<8; i++) header[headerSize++] = buf[i];
                out.write(buf, 0, n); total += n;
            }
            if (total < 1024 || !validHeader(header)) throw new IOException("Invalid GGUF header or size");
        } catch (IOException | RuntimeException ex) { tmp.delete(); throw ex; }
        if (dest.exists() && !dest.delete()) { tmp.delete(); throw new IOException("Cannot replace model"); }
        if (!tmp.renameTo(dest)) { tmp.delete(); throw new IOException("Cannot finalize model"); }
        return total;
    }
}
