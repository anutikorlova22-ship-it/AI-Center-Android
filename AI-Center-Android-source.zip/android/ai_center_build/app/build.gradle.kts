plugins { id("com.android.application") }
android {
    namespace = "ru.aicenter.mobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.aicenter.mobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "3.0-rc1"
    }
    // Enable only with -PaicenterWithLlama=true AND reviewed vendor/llama.cpp sources.
    val withLlama = providers.gradleProperty("aicenterWithLlama").orNull == "true"
    defaultConfig {
        externalNativeBuild {
            cmake { arguments += listOf("-DAICENTER_WITH_LLAMA=${if (withLlama) "ON" else "OFF"}") }
        }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
    ndkVersion = "27.2.12479018"
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
