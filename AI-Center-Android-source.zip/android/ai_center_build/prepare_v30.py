from pathlib import Path
p=Path('app/src/main/java/ru/aicenter/mobile/MainActivity.java')
s=p.read_text()
s=s.replace('private static final String CHAT="http://127.0.0.1:8765/", MONITOR="http://127.0.0.1:8766/status";', 'private static final String CHAT="http://127.0.0.1:8765/", MONITOR="http://127.0.0.1:8766/status", RESEARCH="http://127.0.0.1:8767/";')
s=s.replace('private Button[] navButtons=new Button[3];','private Button[] navButtons=new Button[4];')
s=s.replace('private WebView web;', 'private WebView web, researchWeb;')
s=s.replace('private boolean alive=true, chatLoaded=false;', 'private boolean alive=true, chatLoaded=false, researchLoaded=false;')
s=s.replace('String[] names={"Главная","Чат","Контроль"};for(int i=0;i<3;i++)', 'String[] names={"Главная","Чат","Поиск","Контроль"};for(int i=0;i<4;i++)')
s=s.replace('&&u.getPort()==8765)return false;', '&&(u.getPort()==8765||u.getPort()==8767))return false;')
needle='root.addView(web,new LinearLayout.LayoutParams(-1,0,1));'
insert='''root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        researchWeb=new WebView(this);researchWeb.setBackgroundColor(BG);
        WebSettings rs=researchWeb.getSettings();rs.setJavaScriptEnabled(true);rs.setDomStorageEnabled(true);rs.setAllowFileAccess(false);rs.setAllowContentAccess(false);
        researchWeb.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){android.net.Uri u=r.getUrl();if("http".equals(u.getScheme())&&"127.0.0.1".equals(u.getHost())&&u.getPort()==8767)return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;}});
        root.addView(researchWeb,new LinearLayout.LayoutParams(-1,0,1));'''
assert needle in s;s=s.replace(needle,insert)
s=s.replace('web.setVisibility(selected==1?View.VISIBLE:View.GONE);((View)dashboard.getTag()).setVisibility(selected==2?View.VISIBLE:View.GONE);','web.setVisibility(selected==1?View.VISIBLE:View.GONE);researchWeb.setVisibility(selected==2?View.VISIBLE:View.GONE);((View)dashboard.getTag()).setVisibility(selected==3?View.VISIBLE:View.GONE);')
s=s.replace('if(selected==2)refresh();','if(selected==2&&!researchLoaded){researchLoaded=true;researchWeb.loadUrl(RESEARCH);}if(selected==3)refresh();')
s=s.replace('web.destroy();super.onDestroy();','web.destroy();researchWeb.destroy();super.onDestroy();')
# Launcher for research is a separate explicit command. Do not attempt Termux background run before backend is deployed.
p.write_text(s)
b=Path('app/build.gradle.kts');x=b.read_text().replace('versionCode = 4','versionCode = 5').replace('versionName = "2.3"','versionName = "3.0-rc1"');b.write_text(x)
