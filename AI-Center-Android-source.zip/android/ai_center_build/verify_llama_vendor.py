#!/usr/bin/env python3
"""Strict offline audit of a vendored llama.cpp source tree.

The manifest is a review record, not a cryptographic signature of provenance.
Never fetch or execute vendor code here.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path, PurePosixPath


def verify(root: Path, manifest: Path) -> dict:
    root = root.resolve(strict=True)
    data = json.loads(manifest.read_text(encoding="utf-8"))
    expected = data.get("files")
    if not isinstance(expected, dict) or not expected:
        raise ValueError("manifest requires nonempty files object")
    errors = []
    if not re.fullmatch(r"[0-9a-f]{40}", str(data.get("upstream_commit", ""))):
        errors.append("missing or invalid upstream commit")
    verified_names = set()
    for name, digest in expected.items():
        if not isinstance(name, str) or not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            errors.append(f"invalid manifest entry: {name}")
            continue
        parts = PurePosixPath(name).parts
        if (not parts or name.startswith("/") or "\\" in name or
                any(part in (".", "..", ".git") for part in parts) or
                PurePosixPath(name).as_posix() != name):
            errors.append(f"unsafe manifest path: {name}")
            continue
        target = root.joinpath(*parts)
        if target.is_symlink() or not target.resolve().is_relative_to(root) or not target.is_file():
            errors.append(f"missing/unsafe path: {name}")
            continue
        with target.open("rb") as stream:
            actual = hashlib.file_digest(stream, "sha256").hexdigest()
        if actual != digest:
            errors.append(f"checksum mismatch: {name}")
        verified_names.add(name)
    # Checking only listed files is insufficient: an injected CMake file can be
    # compiled without appearing in the manifest.
    for path in root.rglob("*"):
        rel = path.relative_to(root).as_posix()
        if path.is_symlink():
            errors.append(f"symlink forbidden: {rel}")
        elif path.is_file() and rel not in verified_names:
            errors.append(f"untracked vendor file: {rel}")
    return {"verified": not errors, "checked_files": len(verified_names),
            "errors": errors, "upstream_commit": data.get("upstream_commit", "unknown")}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("vendor_dir", type=Path)
    p.add_argument("manifest", type=Path)
    args = p.parse_args()
    result = verify(args.vendor_dir, args.manifest)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["verified"] else 1)


if __name__ == "__main__":
    main()
