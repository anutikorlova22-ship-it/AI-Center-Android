#!/usr/bin/env python3
"""Fail-closed release gate for the Termux-free Android build.

No downloads, installs, or code execution. Reports prerequisites only.
"""
import argparse
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def assess(root=ROOT, ndk=None, sdk=None):
    root = Path(root)
    cpp = root / 'app/src/main/cpp'
    vendor = cpp / 'vendor/llama.cpp'
    ndk_path = Path(ndk) if ndk else None
    sdk_path = Path(sdk) if sdk else None
    checks = {
        'android_project': (root / 'app/build.gradle.kts').is_file(),
        'jni_source': (cpp / 'native_inference.cpp').is_file(),
        'cmake_project': (cpp / 'CMakeLists.txt').is_file(),
        'llama_sources': (vendor / 'CMakeLists.txt').is_file() and (vendor / 'include/llama.h').is_file(),
        'android_ndk': bool(ndk_path and (ndk_path / 'build/cmake/android.toolchain.cmake').is_file()),
        'android_sdk': bool(sdk_path and (sdk_path / 'platforms/android-35/android.jar').is_file()),
        'gradle_wrapper': (root / 'gradlew').is_file() and (root / 'gradle/wrapper/gradle-wrapper.jar').is_file(),
    }
    blockers = [name for name, ok in checks.items() if not ok]
    return {'checks': checks, 'blockers': blockers,
            'ready_to_attempt_native_build': not blockers,
            'native_build_verified': False, 'apk_tested_on_device': False,
            'termux_free_verified': False,
            'note': 'Passing prerequisites is not proof of successful build or inference.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ndk', default=os.environ.get('ANDROID_NDK'))
    parser.add_argument('--sdk', default=os.environ.get('ANDROID_SDK_ROOT') or os.environ.get('ANDROID_HOME'))
    parser.add_argument('--require-ready', action='store_true')
    args = parser.parse_args()
    result = assess(ndk=args.ndk, sdk=args.sdk)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if args.require_ready and not result['ready_to_attempt_native_build'] else 0

if __name__ == '__main__':
    raise SystemExit(main())
