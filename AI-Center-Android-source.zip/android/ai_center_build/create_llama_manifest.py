#!/usr/bin/env python3
"""Create an auditable SHA-256 manifest for an already-reviewed local llama.cpp tree.

Does not download, execute, or trust third-party code. The operator must supply
an exact upstream commit and review licensing before accepting the manifest.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path


def create_manifest(vendor: Path, commit: str) -> dict:
    root = vendor.resolve(strict=True)
    if not re.fullmatch(r"[0-9a-f]{40}", commit):
        raise ValueError("commit must be a full 40-character lowercase Git SHA")
    if not (root / "CMakeLists.txt").is_file() or not (root / "include" / "llama.h").is_file():
        raise ValueError("expected llama.cpp CMakeLists.txt and include/llama.h")
    files = {}
    for path in sorted(root.rglob("*")):
        if ".git" in path.relative_to(root).parts:
            continue
        if path.is_symlink():
            raise ValueError(f"symlink forbidden: {path.relative_to(root)}")
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        with path.open("rb") as stream:
            files[rel] = hashlib.file_digest(stream, "sha256").hexdigest()
    if len(files) < 2:
        raise ValueError("vendor tree incomplete")
    return {"upstream_repository": "https://github.com/ggml-org/llama.cpp",
            "upstream_commit": commit, "files": files}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("vendor_dir", type=Path)
    p.add_argument("commit", help="full reviewed upstream git commit")
    p.add_argument("output", type=Path)
    a = p.parse_args()
    manifest = create_manifest(a.vendor_dir, a.commit)
    a.output.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Recorded {len(manifest['files'])} files from {a.commit}")


if __name__ == "__main__":
    main()
