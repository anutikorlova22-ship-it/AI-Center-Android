#!/data/data/com.termux/files/usr/bin/python
"""Read-only status endpoint for AI Center; never executes commands from requests."""
import datetime as dt, json, os, re, sqlite3, subprocess, urllib.request, shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
HOME=Path.home(); BASE=HOME/'AI_CENTER'
def run(args,timeout=5):
    try:return subprocess.run(args,capture_output=True,text=True,timeout=timeout)
    except Exception:return None
def ok(url):
    try:
        with urllib.request.urlopen(url,timeout=2) as r:return 200<=r.status<400
    except Exception:return False
def process(name):
    r=run(['pgrep','-x',name]);return bool(r and r.returncode==0)
def matches(field,val,lo,hi):
    for part in field.split(','):
        try:
            step=1
            if '/' in part:part,st=part.split('/',1);step=int(st)
            if step<1:continue
            if part=='*':a,b=lo,hi
            elif '-' in part:a,b=map(int,part.split('-',1))
            else:a=b=int(part)
            if a<=val<=b and (val-a)%step==0:return True
            if val==0 and hi==7 and b==7 and a<=7 and (7-a)%step==0:return True
        except Exception:pass
    return False
def next_time(parts,now):
    if len(parts)!=5:return None
    start=now.replace(second=0,microsecond=0)+dt.timedelta(minutes=1)
    for i in range(60*24*32):
        x=start+dt.timedelta(minutes=i)
        if not all(matches(parts[k],v,lo,hi) for k,v,lo,hi in [(0,x.minute,0,59),(1,x.hour,0,23),(3,x.month,1,12)]):continue
        dom=matches(parts[2],x.day,1,31);dow=matches(parts[4],(x.weekday()+1)%7,0,7)
        if (dom or dow if parts[2]!='*' and parts[4]!='*' else dom and dow):return x
    return None
def label(command):
    s=command.lower()
    labels=[('daily_cycle.py','Ежедневный цикл знаний'),('ai_learning_v2.py','Обучение ИИ V2'),('ai_learning_cycle.py','Обучение ИИ'),('sync_ai_memory.sh','Синхронизация памяти'),('receive_ai_memory.sh','Получение памяти'),('archive_approved_memory.py','Архивация утверждённой памяти'),('build_memory_context.py','Сборка контекста памяти'),('memory_updates.py','Обновление памяти'),('ai_memory_hq.py','Сканирование памяти'),('ai_cleanup.sh','Очистка служебных файлов'),('bridge.py','Мост ИИ Центра'),('sqlite3','Резервная копия SQLite'),('find ','Очистка старых копий')]
    for key,name in labels:
        if key in s:return name
    # Cron Auto wraps scripts in run_task.sh; extract the command after the wrapper.
    for key,name in labels:
        if key in s.replace('\\"','"'):return name
    return 'Системная задача'
def db_check():
    candidates=[HOME/'storage/shared/AI_MEMORY_HQ/database/memory.db',BASE/'database/memory.db',BASE/'memory.db']
    for path in candidates:
        if path.is_file():
            try:
                # SQLite read-only; do not create or alter a database.
                uri='file:'+str(path)+'?mode=ro'
                with sqlite3.connect(uri,uri=True,timeout=2) as c: result=c.execute('PRAGMA quick_check').fetchone()[0]
                return ('🟢 целостна' if result=='ok' else '🔴 ошибка целостности')+' · '+str(path)
            except Exception:return '🔴 ошибка чтения · '+str(path)
    return '🟡 не найдена в известных каталогах'
def status():
    now=dt.datetime.now().astimezone();r=run(['crontab','-l'],4);lines=r.stdout.splitlines() if r and r.returncode==0 else []
    jobs=[]
    for line in lines:
        line=line.strip()
        if not line or line.startswith('#') or '=' in line.split()[0]:continue
        parts=line.split(maxsplit=5)
        if len(parts)!=6:continue
        when=next_time(parts[:5],now)
        if not when:continue
        seconds=max(0,int((when-now).total_seconds()))
        jobs.append({'name':label(parts[5]),'next_run':when.strftime('%Y-%m-%d %H:%M'),'countdown':f'{seconds//3600}ч {(seconds%3600)//60}м','last_result':'не подтверждён','command':parts[5][:200]})
    jobs.sort(key=lambda x:x['next_run'])
    internet=ok('https://www.google.com/generate_204');drive=False;detail='rclone не настроен'
    if shutil.which('rclone'):
        r=run(['rclone','listremotes'],5)
        remotes=r.stdout.splitlines() if r and r.returncode==0 else []
        remote=next((x for x in remotes if x.rstrip(':').lower() in ('gdrive','drive','google_drive')),None)
        if remote:
            r=run(['rclone','lsf',remote,'--max-depth','1'],10)
            drive=bool(r and r.returncode==0);detail='Доступ к Google Drive подтверждён' if drive else 'Не удалось проверить доступ'
    return {'internet_ok':internet,'drive_ok':drive,'drive_detail':detail,'checked_at':now.strftime('%Y-%m-%d %H:%M:%S'),'web_ok':ok('http://127.0.0.1:8765/'),'qwen_ok':ok('http://127.0.0.1:8081/health'),'cron_running':process('crond'),'database_status':db_check(),'jobs':jobs}
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path!='/status':self.send_error(404);return
        try:data=json.dumps(status(),ensure_ascii=False).encode()
        except Exception as e:self.send_error(500,'Status error');return
        self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def log_message(self,*args):pass
if __name__=='__main__':ThreadingHTTPServer(('127.0.0.1',8766),Handler).serve_forever()
