#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Gradle is missing. Open this project in Android Studio or install Gradle 8.10.2.' >&2; exit 2
fi
if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]]; then
  echo 'ANDROID_HOME/ANDROID_SDK_ROOT not set. Install Android SDK 35 and NDK 27.2.12479018.' >&2; exit 2
fi
printf '%s\n' 'Building TEST APK (llama.cpp disabled; Termux may still be needed for the main chat).'
gradle --no-daemon assembleDebug
APK='app/build/outputs/apk/debug/app-debug.apk'
[[ -f "$APK" ]] || { echo 'APK not produced' >&2; exit 3; }
echo "Built: $PWD/$APK"
if [[ "${1:-}" == '--install' ]]; then
  command -v adb >/dev/null || { echo 'adb not installed' >&2; exit 4; }
  adb devices
  read -r -p 'Install this TEST APK on connected Android device? [yes/NO] ' answer
  [[ "$answer" == 'yes' ]] || { echo 'Installation cancelled'; exit 0; }
  adb install -r "$APK"
fi
