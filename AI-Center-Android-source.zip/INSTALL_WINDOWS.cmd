@echo off
cd /d "%~dp0android\ai_center_build"
call build_and_install_windows.bat %*
exit /b %ERRORLEVEL%
