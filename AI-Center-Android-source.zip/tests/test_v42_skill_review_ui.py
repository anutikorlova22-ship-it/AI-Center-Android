import pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class SkillReviewIntegrationTests(unittest.TestCase):
    def test_api_routes_present(self):
        server=(ROOT/'server/mobile/server.py').read_text(encoding='utf-8')
        self.assertIn("u.path=='/api/v42/skills/pending'",server)
        self.assertIn("self.path=='/api/v42/skills/decide'",server)
        self.assertIn('acknowledge_risk=False',server)
        self.assertIn("type(data.get('approve')) is not bool",server)
    def test_android_review_ui_present(self):
        java=(ROOT/'android/ai_center_build/app/src/main/java/ru/aicenter/mobile/MainActivity.java').read_text(encoding='utf-8')
        self.assertIn('reviewSkillCandidates()',java)
        self.assertIn('/api/v42/skills/pending',java)
        self.assertIn('/api/v42/skills/decide',java)
        self.assertIn('if(!risky)dialog.setPositiveButton',java)
