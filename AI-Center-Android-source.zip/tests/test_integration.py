"""Dependency-free smoke checks for the Android/Termux integration."""
from pathlib import Path
import ast, json, re, unittest, zipfile
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'android/ai_center_build'
SERVER=ROOT/'server'
class Integration(unittest.TestCase):
 def test_all_python_parses(self):
  for path in ROOT.rglob('*.py'):
   with self.subTest(path=str(path.relative_to(ROOT))):
    ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
 def test_android_endpoints_match(self):
  java=(APP/'app/src/main/java/ru/aicenter/mobile/MainActivity.java').read_text()
  self.assertIn('127.0.0.1:8765',java)
  self.assertIn('127.0.0.1:8766/status',java)
  self.assertIn('127.0.0.1:8765/v30.html',java)
  self.assertIn("PORT=8765",(SERVER/'mobile/server.py').read_text())
  self.assertIn('PORT=8767',(APP/'termux/research/install_research.py').read_text())
 def test_no_release_claim(self):
  gradle=(APP/'app/build.gradle.kts').read_text()
  self.assertIn('versionName = "3.0-rc1"',gradle)
 def test_network_security_local(self):
  xml=(APP/'app/src/main/res/xml/network_security_config.xml').read_text()
  self.assertIn('127.0.0.1',xml)
 def test_research_has_limits(self):
  source=(APP/'termux/research/install_research.py').read_text()
  for item in ['safe_public_url','ThreadingHTTPServer','Content-Length','mode=ro','max_tokens']:
   self.assertIn(item,source)
if __name__=='__main__':unittest.main()
