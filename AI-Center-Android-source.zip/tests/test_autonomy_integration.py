import pathlib, sys, tempfile, unittest, sqlite3
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server/mobile'))
import feature_discovery

class AutonomyTests(unittest.TestCase):
 def test_discovery_no_network_and_no_code_execution(self):
  with tempfile.TemporaryDirectory() as d:
   db=pathlib.Path(d)/'features.db'
   def fake(_):
    return [('Offline voice assistant for Android','https://example.org/release','speech local android'),('bad','file:///tmp/evil','local android')]
   result=feature_discovery.collect(db,{'test':'https://example.org/rss'},fake)
   self.assertEqual(result['new_suggestions'],1)
   self.assertEqual(result['code_changes'],0)
   self.assertEqual(feature_discovery.collect(db,{'test':'https://example.org/rss'},fake)['new_suggestions'],0)
   item=feature_discovery.suggestions(db)[0]
   self.assertTrue(feature_discovery.decide(item['id'],'approved_for_review',db))
   self.assertFalse(feature_discovery.decide(item['id'],'rejected',db))
   with self.assertRaises(ValueError):feature_discovery.decide(item['id'],'install',db)
 def test_wired_to_daily_and_server(self):
  self.assertIn('run_discovery.py',(ROOT/'server/bin/daily_cycle.py').read_text())
  src=(ROOT/'server/mobile/server.py').read_text()
  self.assertIn('/api/v30/features/suggestions',src)
  self.assertIn('/api/v30/features/review',src)
