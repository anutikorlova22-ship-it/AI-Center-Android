import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server/mobile'))
from v30_tools import search_imports

class TestImports(unittest.TestCase):
    def test_scoped_search(self):
        with tempfile.TemporaryDirectory() as t:
            base=Path(t); (base/'imports').mkdir()
            (base/'imports'/'notes.md').write_text('Вера готовит новую песню')
            (base/'secret.txt').write_text('Вера пароль')
            r=search_imports(base,'Вера')
            self.assertEqual(len(r['items']),1)
            self.assertEqual(r['items'][0]['name'],'notes.md')
            self.assertEqual(r['scope'],'imports')
    def test_no_folder(self):
        with tempfile.TemporaryDirectory() as t:
            self.assertEqual(search_imports(t,'документы')['items'],[])
    def test_no_symlink_escape(self):
        with tempfile.TemporaryDirectory() as t:
            base=Path(t);(base/'imports').mkdir()
            (base/'secret.txt').write_text('пароль секрет')
            (base/'imports'/'link.txt').symlink_to(base/'secret.txt')
            self.assertEqual(search_imports(base,'секрет')['items'],[])

if __name__=='__main__':unittest.main()
