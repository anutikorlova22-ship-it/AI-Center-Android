import importlib.util, pathlib, sqlite3, tempfile, unittest
P=pathlib.Path(__file__).resolve().parents[1]/'server/bin/daily_brief.py'
spec=importlib.util.spec_from_file_location('daily_brief',P);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class DailyBriefTests(unittest.TestCase):
 def test_empty(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t);r=mod.build(p/'n.db',p/'f.db',p/'out.json');self.assertEqual(r['items'],[]);self.assertFalse(r['verified']);self.assertTrue((p/'out.json').is_file())
 def test_dedup(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)
   with sqlite3.connect(p/'n.db') as c:
    c.execute('CREATE TABLE findings(topic,title,url,first_seen,reviewed)');c.execute('INSERT INTO findings VALUES (?,?,?,?,?)',('AI','news','https://example.org/1','2026-10-01',0))
   with sqlite3.connect(p/'f.db') as c:
    c.execute('CREATE TABLE candidates(category,title,url,score,seen_at,status)');c.execute('INSERT INTO candidates VALUES (?,?,?,?,?,?)',('AI','feature','https://example.org/1',70,'2026-10-02','proposed'))
   r=mod.build(p/'n.db',p/'f.db',p/'out.json');self.assertEqual(len(r['items']),1)
