import importlib.util
import tempfile
import unittest
from pathlib import Path

MODULE = Path(__file__).resolve().parents[1] / 'android/ai_center_build/release_gate.py'
spec = importlib.util.spec_from_file_location('release_gate', MODULE)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


class ReleaseGateTests(unittest.TestCase):
    def test_missing_dependencies_fail_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            report = gate.assess(tmp)
            self.assertFalse(report['ready_to_attempt_native_build'])
            self.assertFalse(report['termux_free_verified'])
            self.assertIn('llama_sources', report['blockers'])

    def test_all_prerequisites_still_not_proof_of_inference(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for path in ['app/build.gradle.kts', 'app/src/main/cpp/native_inference.cpp',
                         'app/src/main/cpp/CMakeLists.txt', 'app/src/main/cpp/vendor/llama.cpp/CMakeLists.txt',
                         'app/src/main/cpp/vendor/llama.cpp/include/llama.h',
                         'gradlew', 'gradle/wrapper/gradle-wrapper.jar']:
                p = root / path
                p.parent.mkdir(parents=True, exist_ok=True)
                p.touch()
            ndk, sdk = root / 'ndk', root / 'sdk'
            for p in [ndk / 'build/cmake/android.toolchain.cmake', sdk / 'platforms/android-35/android.jar']:
                p.parent.mkdir(parents=True, exist_ok=True)
                p.touch()
            report = gate.assess(root, ndk, sdk)
            self.assertTrue(report['ready_to_attempt_native_build'])
            self.assertFalse(report['native_build_verified'])
            self.assertFalse(report['apk_tested_on_device'])

    def test_partial_vendor_not_accepted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            p = root / 'app/src/main/cpp/vendor/llama.cpp/CMakeLists.txt'
            p.parent.mkdir(parents=True)
            p.touch()
            self.assertFalse(gate.assess(root)['checks']['llama_sources'])
