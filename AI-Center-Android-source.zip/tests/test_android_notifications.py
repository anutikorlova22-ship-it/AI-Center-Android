from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
JAVA=(ROOT/'android/ai_center_build/app/src/main/java/ru/aicenter/mobile/MainActivity.java').read_text()
MANIFEST=(ROOT/'android/ai_center_build/app/src/main/AndroidManifest.xml').read_text()
class NotificationTests(unittest.TestCase):
    def test_permission_and_channel(self):
        self.assertIn('android.permission.POST_NOTIFICATIONS',MANIFEST)
        self.assertIn('createNotificationChannel()',JAVA)
        self.assertIn('requestNotificationPermission()',JAVA)
    def test_due_only_and_dedup(self):
        self.assertIn('item.optBoolean("due",false)',JAVA)
        self.assertIn('"pending".equals(item.optString("status"))',JAVA)
        self.assertIn('prefs.getBoolean("shown_"+id,false)',JAVA)
    def test_localhost_and_bounds(self):
        self.assertIn('127.0.0.1:8765/api/v30/reminders',JAVA)
        self.assertIn('data.size()+n>65536',JAVA)
    def test_share_sheet(self):
        self.assertIn('Intent.ACTION_SEND',JAVA)
        self.assertIn('Intent.createChooser(send',JAVA)
