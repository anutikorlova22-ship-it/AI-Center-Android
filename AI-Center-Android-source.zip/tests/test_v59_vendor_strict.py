import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'android/ai_center_build/verify_llama_vendor.py'
spec = importlib.util.spec_from_file_location('vendor_verify_v59', SCRIPT)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class StrictVendorTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'vendor'
        self.root.mkdir()
        (self.root / 'CMakeLists.txt').write_text('project(llama)')
        self.manifest = Path(self.tmp.name) / 'manifest.json'
        self.files = {'CMakeLists.txt': hashlib.sha256(b'project(llama)').hexdigest()}
        self.write_manifest()

    def write_manifest(self):
        self.manifest.write_text(json.dumps({'upstream_commit':'a'*40, 'files':self.files}))

    def test_valid(self):
        self.assertTrue(mod.verify(self.root,self.manifest)['verified'])

    def test_extra_file_blocked(self):
        (self.root/'malicious.cmake').write_text('execute_process(COMMAND echo bad)')
        self.assertFalse(mod.verify(self.root,self.manifest)['verified'])

    def test_symlink_blocked(self):
        (self.root/'link').symlink_to(self.root/'CMakeLists.txt')
        self.assertFalse(mod.verify(self.root,self.manifest)['verified'])

    def test_parent_traversal_blocked(self):
        self.files['../outside'] = '0'*64
        self.write_manifest()
        self.assertFalse(mod.verify(self.root,self.manifest)['verified'])

    def test_bad_commit_blocked(self):
        self.manifest.write_text(json.dumps({'upstream_commit':'unknown','files':self.files}))
        self.assertFalse(mod.verify(self.root,self.manifest)['verified'])

    def test_changed_file_blocked(self):
        (self.root/'CMakeLists.txt').write_text('changed')
        self.assertFalse(mod.verify(self.root,self.manifest)['verified'])

if __name__ == '__main__': unittest.main()
