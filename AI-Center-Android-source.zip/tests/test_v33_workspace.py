import importlib.util,pathlib,sqlite3,tempfile,unittest
P=pathlib.Path(__file__).resolve().parents[1]/'server/mobile/v33_workspace.py'
spec=importlib.util.spec_from_file_location('v33_workspace',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class TestWorkspace(unittest.TestCase):
 def test_empty_export(self):
  with tempfile.TemporaryDirectory() as d:
   for fmt in ('markdown','json','csv'):
    body,typ,name=m.export_history(pathlib.Path(d),fmt)
    self.assertTrue(body)
 def test_chat_csv_escaping(self):
  with tempfile.TemporaryDirectory() as d:
   base=pathlib.Path(d);(base/'knowledge').mkdir()
   with sqlite3.connect(base/'knowledge/chat_history.db') as c:
    c.execute('CREATE TABLE messages (id INTEGER PRIMARY KEY,role TEXT,body TEXT,created_at TEXT)')
    c.execute('INSERT INTO messages(role,body,created_at) VALUES (?,?,?)',('user','a,b\nhello','now'))
   body,_,_=m.export_history(base,'csv')
   self.assertIn('"a,b\nhello"',body)
 def test_feedback_does_not_modify_canon(self):
  with tempfile.TemporaryDirectory() as d:
   base=pathlib.Path(d)
   result=m.add_feedback(base,'Исправь описание проекта')
   self.assertFalse(result['canon_modified'])
   self.assertEqual(m.feedback_inbox(base)['items'][0]['status'],'pending')
   self.assertFalse((base/'knowledge/knowledge.db').exists())
 def test_invalid(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ValueError):m.add_feedback(pathlib.Path(d),'x')
   with self.assertRaises(ValueError):m.export_history(pathlib.Path(d),'exe')
