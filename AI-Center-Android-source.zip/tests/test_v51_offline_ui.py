import pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
JAVA=(ROOT/'android/ai_center_build/app/src/main/java/ru/aicenter/mobile/MainActivity.java').read_text()
class OfflineUiTests(unittest.TestCase):
    def test_ui_entry(self): self.assertIn('offlineChat.setOnClickListener(v->showOfflineChat())', JAVA)
    def test_local_model(self): self.assertIn('NativeModelManager.modelFile(this).getAbsolutePath()', JAVA)
    def test_background_inference(self): self.assertIn('pool.execute(()->{', JAVA); self.assertIn('NativeInference.generate(', JAVA)
    def test_fail_closed(self): self.assertIn('Нативный движок недоступен', JAVA)
    def test_share(self): self.assertIn('Intent.createChooser(send,"Поделиться ответом")', JAVA)
if __name__=='__main__': unittest.main()
