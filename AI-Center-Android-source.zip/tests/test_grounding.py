import pathlib,sys,tempfile,unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]/'server/mobile'
sys.path.insert(0,str(ROOT))
import grounded_context
class FakeProactive:
 @staticmethod
 def inbox(limit=70):return [{'title':'Изменение правил музыкальной дистрибуции','topic':'Музыка','url':'https://example.org/notice'}]
class FakeTools:
 @staticmethod
 def search_imports(base,q):return {'items':[{'source':'notes.md','snippet':'Информация из документа'}]}
class FakeExtra:
 @staticmethod
 def live_search(q,limit=4):return {'items':[{'title':'Проверка новых правил','url':'https://example.com/info'}],'live':True}
class Tests(unittest.TestCase):
 def test_local_first_and_no_web_for_general_question(self):
  with tempfile.TemporaryDirectory() as d:
   c,r,s=grounded_context.build_context('Расскажи о правилах дистрибуции',d,FakeProactive,FakeTools,FakeExtra)
   self.assertEqual(s['documents'],1);self.assertFalse(s['web']);self.assertIn('notes.md',c)
 def test_explicit_web_search_with_source(self):
  with tempfile.TemporaryDirectory() as d:
   c,r,s=grounded_context.build_context('Найди в интернете правила дистрибуции',d,FakeProactive,FakeTools,FakeExtra)
   self.assertTrue(s['web']);self.assertTrue(any(x.get('url')=='https://example.com/info' for x in r))
 def test_no_automatic_web_for_private_request(self):
  self.assertFalse(grounded_context.wants_live_search('Покажи мои документы'))
 def test_invalid_url_filtered(self):
  class Bad:
   @staticmethod
   def live_search(q,limit=4):return {'items':[{'title':'bad','url':'file:///etc/passwd'}],'live':True}
  with tempfile.TemporaryDirectory() as d:
   _,r,_=grounded_context.build_context('Найди в интернете новости',d,FakeProactive,FakeTools,Bad)
   self.assertFalse(any(x.get('url','').startswith('file:') for x in r))
