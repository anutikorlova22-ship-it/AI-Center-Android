from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "android/ai_center_build/app/src/main/cpp/native_inference.cpp"
class NativeOutputTests(unittest.TestCase):
    def test_output_has_size_cap(self):
        s = SOURCE.read_text()
        self.assertIn("MAX_OUTPUT_BYTES", s)
        self.assertIn("output.size() > MAX_OUTPUT_BYTES", s)
        self.assertIn("Generated response exceeds 1 MiB", s)
if __name__ == "__main__": unittest.main()
