import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
CPP = ROOT / 'android/ai_center_build/app/src/main/cpp'

class LlamaIntegrationContract(unittest.TestCase):
    def test_default_off(self):
        cmake = (CPP / 'CMakeLists.txt').read_text()
        self.assertIn('option(AICENTER_WITH_LLAMA', cmake)
        self.assertIn('llama.cpp" OFF)', cmake)
    def test_missing_sources_fail_build(self):
        cmake = (CPP / 'CMakeLists.txt').read_text()
        self.assertIn('message(FATAL_ERROR', cmake)
        self.assertIn('add_subdirectory', cmake)
    def test_no_false_claim_of_generation(self):
        code = (CPP / 'native_inference.cpp').read_text()
        self.assertIn('UnsupportedOperationException', code)
    def test_docs_state_limitations(self):
        self.assertIn('not a working embedded Qwen runtime', (CPP / 'README_NATIVE.md').read_text())
