import sys,tempfile,unittest,pathlib,datetime as dt
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'server/mobile'))
import v30_extra
class Extra(unittest.TestCase):
 def test_reminders(self):
  with tempfile.TemporaryDirectory() as d:
   due=(dt.datetime.now(dt.timezone.utc)+dt.timedelta(hours=1)).isoformat()
   item=v30_extra.add_reminder(d,'Важное',due)
   self.assertFalse(v30_extra.list_reminders(d)[0]['due'])
   self.assertTrue(v30_extra.dismiss_reminder(d,item['id'])['ok'])
   self.assertEqual(v30_extra.list_reminders(d)[0]['status'],'done')
 def test_invalid_date(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ValueError):v30_extra.add_reminder(d,'x','2026-10-12')
 def test_search_parse(self):
  p=v30_extra._Results();p.feed('<a class="result__a" href="https://example.com/x">Hello</a>')
  self.assertEqual(p.items[0]['title'],'Hello')
 def test_caps(self):
  with tempfile.TemporaryDirectory() as d:self.assertEqual(v30_extra.capabilities(d)['image_generation'],'not_included_requires_model_or_provider')
if __name__=='__main__':unittest.main()
