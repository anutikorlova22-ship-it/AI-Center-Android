import unittest, tempfile, pathlib, sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'server'/'mobile'))
import approved_skills
class ApprovedSkillsTests(unittest.TestCase):
 def test_add_and_prompt(self):
  with tempfile.TemporaryDirectory() as t:
   self.assertEqual(approved_skills.add(t,{'name':'Writer','instructions':'Пиши ясными короткими абзацами.'}),1)
   self.assertIn('Writer',approved_skills.prompt(t))
   self.assertEqual(approved_skills.add(t,{'name':'writer','instructions':'Пиши понятным русским языком.'}),1)
 def test_reject_code_and_bad_data(self):
  with tempfile.TemporaryDirectory() as t:
   for bad in ({'name':'X','instructions':'A'*30},{'name':'ok','instructions':'A'*30,'command':'rm -rf /'}, {'name':'ok','instructions':3}):
    with self.assertRaises(ValueError):approved_skills.add(t,bad)
 def test_empty(self):
  with tempfile.TemporaryDirectory() as t:self.assertEqual(approved_skills.prompt(t),'')
if __name__=='__main__':unittest.main()
