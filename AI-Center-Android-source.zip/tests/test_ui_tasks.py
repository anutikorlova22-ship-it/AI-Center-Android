import unittest
from pathlib import Path
class UITasksTest(unittest.TestCase):
    def test_tasks_and_due_alert(self):
        html=(Path(__file__).resolve().parents[1]/'server/mobile/v30.html').read_text()
        for token in ('/api/v30/tasks', '/api/v30/tasks/done', 'async function checkDue()', 'setInterval(checkDue,30000)', 'async function addTask()'):
            self.assertIn(token,html)
    def test_html_escaping(self):
        html=(Path(__file__).resolve().parents[1]/'server/mobile/v30.html').read_text()
        self.assertIn('esc(i.title)',html)
        self.assertIn('esc(i.details)',html)
