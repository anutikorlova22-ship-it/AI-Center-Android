import importlib.util, pathlib, unittest, zipfile, io
from xml.etree import ElementTree as ET
P=pathlib.Path(__file__).resolve().parents[1]/'server/mobile/v35_office.py'
spec=importlib.util.spec_from_file_location('v35_office',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class OfficeTests(unittest.TestCase):
 def test_docx(self):
  data,typ=m.docx('Тест','Первая строка\nВторая строка')
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   ET.fromstring(z.read('word/document.xml'))
   self.assertIn('Вторая строка',z.read('word/document.xml').decode())
 def test_xlsx(self):
  data,typ=m.xlsx('Тест','Строка 1\nСтрока 2')
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
   self.assertIn('Строка 2',z.read('xl/worksheets/sheet1.xml').decode())
 def test_xml_escape(self):
  for f in (m.docx,m.xlsx):
   data,_=f('A&B','<script>')
   with zipfile.ZipFile(io.BytesIO(data)) as z:
    self.assertNotIn(b'<script>',b''.join(z.read(n) for n in z.namelist()))
 def test_rejects_empty(self):
  with self.assertRaises(ValueError):m.docx('','body')
 def test_rejects_oversized(self):
  with self.assertRaises(ValueError):m.xlsx('title','x'*24001)
