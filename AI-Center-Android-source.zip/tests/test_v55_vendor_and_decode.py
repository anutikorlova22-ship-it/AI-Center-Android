import hashlib
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "android/ai_center_build/verify_llama_vendor.py"
spec = importlib.util.spec_from_file_location("verify_llama_vendor", SCRIPT)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class VendorVerificationTests(unittest.TestCase):
    def test_good_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "vendor"
            root.mkdir()
            (root / "llama.h").write_bytes(b"verified")
            manifest = Path(d) / "manifest.json"
            manifest.write_text(json.dumps({"upstream_commit":"a"*40, "files":{"llama.h":hashlib.sha256(b"verified").hexdigest()}}))
            self.assertTrue(mod.verify(root, manifest)["verified"])

    def test_tampered_file(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "llama.h").write_bytes(b"tampered")
            manifest = root / "manifest.json"
            manifest.write_text(json.dumps({"files":{"llama.h":hashlib.sha256(b"verified").hexdigest()}}))
            self.assertFalse(mod.verify(root, manifest)["verified"])

    def test_path_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            manifest = root / "manifest.json"
            manifest.write_text(json.dumps({"files":{"../outside": "0"*64}}))
            self.assertFalse(mod.verify(root, manifest)["verified"])

    def test_generated_token_uses_explicit_position(self):
        cpp = (ROOT / "android/ai_center_build/app/src/main/cpp/native_inference.cpp").read_text()
        self.assertIn("batch.pos[0] = n_prompt + i", cpp)
        self.assertIn("llama_batch_free(batch);", cpp)
        self.assertNotIn("llama_batch_get_one(&token, 1)", cpp)
