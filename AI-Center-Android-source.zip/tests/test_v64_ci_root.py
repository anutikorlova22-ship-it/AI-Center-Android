"""Ensure the complete source ZIP can be used as GitHub repository root."""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class RootWorkflowTests(unittest.TestCase):
    def test_workflow_in_repository_root(self):
        wf = ROOT / '.github/workflows/android-native-build.yml'
        self.assertTrue(wf.is_file())
        txt = wf.read_text(encoding='utf-8')
        self.assertIn('working-directory: android/ai_center_build', txt)
        self.assertIn('android/ai_center_build/app/build/outputs/apk/debug/app-debug.apk', txt)
        self.assertIn('-PaicenterWithLlama=true', txt)
        self.assertIn('workflow_dispatch:', txt)
        self.assertNotIn('  push:', txt)

    def test_native_project_exists(self):
        project = ROOT / 'android/ai_center_build'
        self.assertTrue((project / 'app/src/main/cpp/native_inference.cpp').is_file())
        self.assertTrue((project / 'app/build.gradle.kts').is_file())

if __name__ == '__main__':
    unittest.main()
