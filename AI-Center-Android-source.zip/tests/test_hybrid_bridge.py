import importlib.util
import pathlib
import tempfile
import unittest
from unittest import mock

P=pathlib.Path(__file__).resolve().parents[1]/'server'/'mobile'/'hybrid_bridge.py'
spec=importlib.util.spec_from_file_location('hybrid_bridge',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class HybridBridgeTests(unittest.TestCase):
    def test_inventory_without_drive(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.object(m.shutil,'which',return_value=None):
            x=m.inventory(d)
            self.assertFalse(x['drive_remote_configured'])
            self.assertIn('google_drive_rclone',x['features']['termux_server'])
    def test_sync_missing_script(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertFalse(m.sync_drive(d)['ok'])
    def test_sync_no_rclone(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'bin'/'sync_memory.py';p.parent.mkdir();p.write_text('')
            with mock.patch.object(m.shutil,'which',return_value=None):
                self.assertEqual(m.sync_drive(d)['error'],'rclone not installed')
    def test_fixed_command(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'bin'/'sync_memory.py';p.parent.mkdir();p.write_text('')
            with mock.patch.object(m.shutil,'which',return_value='/bin/rclone'), mock.patch.object(m.subprocess,'run') as run:
                run.return_value.returncode=0;run.return_value.stdout='ok';run.return_value.stderr=''
                self.assertTrue(m.sync_drive(d)['ok'])
                args=run.call_args.args[0]
                self.assertEqual(args[-2:],['--remote','gdrive:AI_MEMORY_HQ'])
    def test_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            base=pathlib.Path(d);(base/'bin').mkdir();(base/'bin'/'sync_memory.py').symlink_to('/etc/hosts')
            self.assertFalse(m.sync_drive(base)['ok'])

if __name__=='__main__':unittest.main()
