from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
ANDROID=ROOT/'android/ai_center_build/app/src/main'
RECEIVER=(ANDROID/'java/ru/aicenter/mobile/ReminderReceiver.java').read_text()
MAIN=(ANDROID/'java/ru/aicenter/mobile/MainActivity.java').read_text()
MANIFEST=(ANDROID/'AndroidManifest.xml').read_text()
class BackgroundReminderTests(unittest.TestCase):
    def test_registered_private_receiver(self):
        self.assertIn('android:name=".ReminderReceiver" android:exported="false"',MANIFEST)
    def test_scheduled_from_activity(self):
        self.assertIn('ReminderReceiver.schedule(this)',MAIN)
        self.assertIn('AlarmManager.ELAPSED_REALTIME_WAKEUP',RECEIVER)
        self.assertIn('setInexactRepeating',RECEIVER)
    def test_network_off_main_thread(self):
        self.assertIn('goAsync()',RECEIVER)
        self.assertIn('result.finish()',RECEIVER)
        self.assertIn('new Thread(',RECEIVER)
    def test_notification_guards(self):
        for token in ['POST_NOTIFICATIONS','127.0.0.1:8765/api/v30/reminders','data.size()+n>65536','output.size()+n>65536','shown_','"pending".equals','manager.notify(id,note)']:
            if token=='data.size()+n>65536':continue
            self.assertIn(token,RECEIVER)
