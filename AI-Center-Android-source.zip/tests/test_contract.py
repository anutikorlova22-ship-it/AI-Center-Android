"""Non-destructive source contract checks; run with python -m unittest discover -s tests."""
import pathlib, re, unittest, ast
ROOT=pathlib.Path(__file__).resolve().parents[1]
SERVER=ROOT/'server/mobile/server.py'
ANDROID=ROOT/'android/ai_center_build/app/src/main/java/ru/aicenter/mobile/MainActivity.java'
class Contract(unittest.TestCase):
 def test_server_syntax(self): ast.parse(SERVER.read_text(encoding='utf-8'))
 def test_chat_route(self):
  s=SERVER.read_text(encoding='utf-8')
  self.assertIn("self.path=='/api/chat'",s)
  self.assertIn("'reply':reply",s)
  self.assertIn("'mode':answer_mode",s)
 def test_existing_api(self):
  s=SERVER.read_text(encoding='utf-8')
  for p in ('/api/status','/api/search','/api/tasks','/api/knowledge','/api/chat/history'):
   with self.subTest(path=p):self.assertIn(p,s)
 def test_android_client(self):
  self.assertTrue(ANDROID.exists())
  s=ANDROID.read_text(encoding='utf-8')
  self.assertIn('127.0.0.1',s)
 def test_no_model_in_bundle(self):
  self.assertFalse(list(ROOT.rglob('*.gguf')))
if __name__=='__main__':unittest.main()
