import pathlib
import unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]
JAVA = ROOT / 'android/ai_center_build/app/src/main/java/ru/aicenter/mobile'
class ModelImportTests(unittest.TestCase):
    def test_model_header_and_atomic_import(self):
        s = (JAVA / 'NativeModelManager.java').read_text()
        for value in ['validHeader', 'MAX_BYTES', 'qwen.gguf.partial', 'renameTo(dest)', 'getFilesDir()', 'openInputStream(uri)']:
            self.assertIn(value, s)
    def test_ui_entry_and_result(self):
        s = (JAVA / 'MainActivity.java').read_text()
        for value in ['MODEL_IMPORT_REQUEST', 'NativeModelManager.importModel', 'ACTION_OPEN_DOCUMENT', 'Для офлайн-ответов необходима сборка с llama.cpp']:
            self.assertIn(value, s)
if __name__ == '__main__': unittest.main()
