import pathlib, sqlite3, sys, tempfile, unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'server'/'mobile'))
import v30_tools
class ToolsTests(unittest.TestCase):
 def test_tasks(self):
  with tempfile.TemporaryDirectory() as d:
   item=v30_tools.add_task(d,'Проверить релиз','Сверить источники')
   self.assertEqual(v30_tools.list_tasks(d)[0]['status'],'pending')
   self.assertTrue(v30_tools.finish_task(d,item['id'])['ok'])
   self.assertEqual(v30_tools.list_tasks(d)[0]['status'],'done')
   self.assertFalse(v30_tools.finish_task(d,item['id'])['ok'])
 def test_invalid(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ValueError):v30_tools.add_task(d,'')
   with self.assertRaises(ValueError):v30_tools.finish_task(d,'bad')
 def test_cache_missing(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(v30_tools.search_sources(d,'Qwen')['status'],'rss_cache_missing')
 def test_cache_source(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'knowledge_agent'/'research.sqlite3';p.parent.mkdir()
   with sqlite3.connect(p) as c:
    c.execute('CREATE TABLE articles (title TEXT,url TEXT,source TEXT,published TEXT,summary TEXT,category TEXT,fetched_at TEXT)')
    c.execute('INSERT INTO articles VALUES (?,?,?,?,?,?,?)',('Qwen mobile','https://example.org/a','example.org','2026','Offline Qwen on Android','AI','2026'))
   r=v30_tools.search_sources(d,'Qwen')
   self.assertEqual(len(r['items']),1)
   self.assertFalse(r['live'])
if __name__=='__main__':unittest.main()
