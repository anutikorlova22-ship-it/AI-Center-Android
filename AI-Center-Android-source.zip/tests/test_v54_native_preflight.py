import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "android/ai_center_build"))
from check_native_prerequisites import inspect


class NativePreflightTests(unittest.TestCase):
    def test_missing_vendor_fails_closed(self):
        report = inspect(ROOT / "android/ai_center_build")
        self.assertFalse(report["ready_for_llama_build"])
        self.assertTrue(report["checks"]["jni_bridge"])

    def test_complete_mock_vendor_passes(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)
            for f in ("app/build.gradle.kts", "app/src/main/cpp/native_inference.cpp",
                      "app/src/main/cpp/CMakeLists.txt", "app/src/main/cpp/vendor/llama.cpp/CMakeLists.txt",
                      "app/src/main/cpp/vendor/llama.cpp/include/llama.h"):
                q = p / f
                q.parent.mkdir(parents=True, exist_ok=True)
                q.touch()
            self.assertTrue(inspect(p)["ready_for_llama_build"])

    def test_cmake_has_android_safe_flags(self):
        cmake = (ROOT / "android/ai_center_build/app/src/main/cpp/CMakeLists.txt").read_text()
        for flag in ("GGML_NATIVE OFF", "GGML_OPENMP OFF", "GGML_LLAMAFILE OFF", "LLAMA_OPENSSL OFF"):
            self.assertIn(flag, cmake)

    def test_token_piece_retry_present(self):
        cpp = (ROOT / "android/ai_center_build/app/src/main/cpp/native_inference.cpp").read_text()
        self.assertIn("std::vector<char> piece(needed)", cpp)
