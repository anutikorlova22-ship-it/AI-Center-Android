from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
CPP = ROOT / 'android/ai_center_build/app/src/main/cpp/native_inference.cpp'

class NativeGenerationContractTests(unittest.TestCase):
    def test_sampled_tokens_accepted_by_sampler(self):
        self.assertIn('llama_sampler_accept(sg.sampler, token)', CPP.read_text())

    def test_final_token_not_decoded(self):
        self.assertIn('if (i + 1 == max_tokens) break;', CPP.read_text())

    def test_generation_decode_failure_reported(self):
        self.assertIn('"Generation decode failed"', CPP.read_text())

    def test_sampler_allocation_checked(self):
        self.assertIn('if (!sg.sampler)', CPP.read_text())
