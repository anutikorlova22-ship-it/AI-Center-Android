import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
JAVA = ROOT / 'android/ai_center_build/app/src/main/java/ru/aicenter/mobile'

class OfflineContextTests(unittest.TestCase):
    def test_native_chat_uses_local_prompt(self):
        main = (JAVA / 'MainActivity.java').read_text()
        self.assertIn('OfflinePrompt.compose(this,nativeStore,prompt)', main)
        self.assertIn('NativeInference.generate(', main)
    def test_context_is_bounded_and_local(self):
        source = (JAVA / 'OfflinePrompt.java').read_text()
        for term in ['SkillLibrary.list(context)', 'store.latestNotes(5)', 'count < 3', '600', '250', '3000']:
            self.assertIn(term, source)
        for forbidden in ['http://', 'https://', 'Runtime.getRuntime()', 'ProcessBuilder']:
            self.assertNotIn(forbidden, source)

if __name__ == '__main__': unittest.main()
