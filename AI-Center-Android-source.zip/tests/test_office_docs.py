import importlib.util
import pathlib
import tempfile
import unittest
import zipfile

FILE=pathlib.Path(__file__).resolve().parents[1]/'server/mobile/v30_tools.py'
spec=importlib.util.spec_from_file_location('v30_tools',FILE)
tools=importlib.util.module_from_spec(spec)
spec.loader.exec_module(tools)

class OfficeSearchTest(unittest.TestCase):
    def test_docx_search(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=pathlib.Path(temp)/'imports'
            folder.mkdir()
            xml='<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Уникальный проект Вероника</w:t></w:r></w:p></w:body></w:document>'
            with zipfile.ZipFile(folder/'profile.docx','w') as z:
                z.writestr('word/document.xml',xml)
            found=tools.search_imports(temp,'Вероника')
            self.assertEqual(found['items'][0]['name'],'profile.docx')
    def test_pdf_without_converter_safe(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=pathlib.Path(temp)/'imports';folder.mkdir()
            (folder/'bad.pdf').write_bytes(b'not a pdf')
            self.assertEqual(tools.search_imports(temp,'Вероника')['items'],[])
    def test_bad_docx_safe(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=pathlib.Path(temp)/'imports';folder.mkdir()
            (folder/'bad.docx').write_bytes(b'bad')
            self.assertEqual(tools.search_imports(temp,'Вероника')['items'],[])
if __name__=='__main__':unittest.main()
