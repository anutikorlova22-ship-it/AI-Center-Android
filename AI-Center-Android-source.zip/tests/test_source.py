import ast, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class ProjectChecks(unittest.TestCase):
 def test_all_python_compiles(self):
  for p in ROOT.rglob('*.py'):
   with self.subTest(path=str(p)):ast.parse(p.read_text(encoding='utf-8'))
 def test_no_unintentional_server_rewrite(self):
  s=(ROOT/'INSTALL_SERVER_V30.py').read_text()
  self.assertNotIn('server.py.write_text',s)
  self.assertNotIn('server.py.unlink',s)
 def test_android_research_entry(self):
  s=(ROOT/'android/ai_center_build/app/src/main/java/ru/aicenter/mobile/MainActivity.java').read_text()
  self.assertIn('127.0.0.1:8765/v30.html',s)
  self.assertIn('researchWeb',s)
 def test_research_only_loopback(self):
  s=(ROOT/'android/ai_center_build/termux/research/install_research.py').read_text()
  self.assertIn("HOST='127.0.0.1'",s)
  self.assertIn('safe_public_url',s)
if __name__=='__main__':unittest.main()
