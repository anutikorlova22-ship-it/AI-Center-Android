import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
JAVA = ROOT / 'android/ai_center_build/app/src/main/java/ru/aicenter/mobile/MainActivity.java'

class VoiceContract(unittest.TestCase):
    def test_voice_input(self):
        src = JAVA.read_text(encoding='utf-8')
        self.assertIn('RecognizerIntent.ACTION_RECOGNIZE_SPEECH', src)
        self.assertIn('JSONObject.quote(recognized)', src)
        self.assertIn('startActivityForResult(i,VOICE_REQUEST)', src)
    def test_tts_lifecycle(self):
        src = JAVA.read_text(encoding='utf-8')
        self.assertIn('new TextToSpeech(this', src)
        self.assertIn('speech.speak(response', src)
        self.assertIn('speech.shutdown()', src)
    def test_voice_only_on_chat(self):
        src = JAVA.read_text(encoding='utf-8')
        self.assertIn('voiceControls.setVisibility(selected==1?', src)
