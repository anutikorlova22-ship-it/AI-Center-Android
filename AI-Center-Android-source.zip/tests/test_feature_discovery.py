import pathlib,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server/mobile'))
import feature_discovery as fd

class FeatureDiscoveryTests(unittest.TestCase):
 def test_relevance(self):
  score,topics=fd.rank('Offline voice recognition on Android','New local model')
  self.assertGreaterEqual(score,45)
  self.assertIn('voice',topics)
 def test_irrelevant(self):
  self.assertEqual(fd.rank('Banana prices','fruit market')[0],0)
 def test_dedupe(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=pathlib.Path(tmp)/'test.db'
   def fake(_):return [('Offline AI on Android','https://example.com/feature','local voice')]
   self.assertEqual(fd.collect(path,{'Test':'https://hnrss.org/newest'},fake)['new_suggestions'],1)
   self.assertEqual(fd.collect(path,{'Test':'https://hnrss.org/newest'},fake)['new_suggestions'],0)
   self.assertEqual(len(fd.suggestions(path)),1)
 def test_review_does_not_install(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=pathlib.Path(tmp)/'test.db'
   fd.collect(path,{'Test':'https://hnrss.org/newest'},lambda _: [('Offline AI','https://example.com/feature','Android')])
   candidate=fd.suggestions(path)[0]
   self.assertTrue(fd.decide(candidate['id'],'approved_for_review',path))
   self.assertEqual(fd.suggestions(path)[0]['status'],'approved_for_review')
   with self.assertRaises(ValueError):fd.decide(candidate['id'],'installed',path)
 def test_reject_http(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=pathlib.Path(tmp)/'test.db'
   result=fd.collect(path,{'Test':'https://hnrss.org/newest'},lambda _: [('Offline AI','http://example.com','Android')])
   self.assertEqual(result['new_suggestions'],0)
