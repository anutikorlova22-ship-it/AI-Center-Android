"""Regression checks for native Android CI release gates."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
WF = ROOT / '.github/workflows/android-native-build.yml'

class NativeCiQualityTests(unittest.TestCase):
    def test_ci_runs_python_regressions_before_native_build(self):
        data = WF.read_text(encoding='utf-8')
        self.assertIn('python3 -m unittest discover -s tests', data)
        self.assertLess(data.index('python3 -m unittest discover -s tests'), data.index('Compile Android APK'))

    def test_build_fails_closed_when_source_revision_is_invalid(self):
        data = WF.read_text(encoding='utf-8')
        self.assertIn('^[a-fA-F0-9]{40}$', data)
        self.assertIn('git checkout --detach "$LLAMA_REF"', data)
        self.assertIn('if-no-files-found: error', data)

    def test_sdk_and_native_build_are_explicit(self):
        data = WF.read_text(encoding='utf-8')
        self.assertIn('ndk;27.2.12479018', data)
        self.assertIn('-PaicenterWithLlama=true', data)
        self.assertIn('gradle --no-daemon', data)

if __name__ == '__main__':
    unittest.main()
