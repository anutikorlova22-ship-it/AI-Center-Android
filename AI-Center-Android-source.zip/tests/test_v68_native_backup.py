import sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'/'mobile'))
import native_backup

class NativeBackupTest(unittest.TestCase):
 def test_save_and_repeat(self):
  with tempfile.TemporaryDirectory() as td:
   data={'schema':1,'notes':[{'id':1,'body':'привет','created_ms':100}], 'tasks':[{'id':2,'title':'проверить','due_ms':200}]}
   self.assertEqual(native_backup.save(td,data)['items'],2)
   self.assertEqual(native_backup.save(td,data)['items'],2)
   import sqlite3
   with sqlite3.connect(Path(td)/'knowledge'/'android_backup.db') as db:
    self.assertEqual(db.execute('select count(*) from android_snapshot').fetchone()[0],2)
 def test_bad_input(self):
  with tempfile.TemporaryDirectory() as td:
   for data in ({'schema':2,'notes':[],'tasks':[]},{'schema':1,'notes':[{'id':1,'body':'x','created_ms':-1}],'tasks':[]},{'schema':1,'notes':[],'tasks':'bad'}):
    with self.assertRaises(ValueError):native_backup.save(td,data)
 def test_no_code_execution(self):
  with tempfile.TemporaryDirectory() as td:
   data={'schema':1,'notes':[{'id':3,'body':'$(touch /tmp/never_execute)','created_ms':1}],'tasks':[]}
   self.assertTrue(native_backup.save(td,data)['ok'])
