import unittest
from pathlib import Path

BASE = Path(__file__).resolve().parents[1] / 'android/ai_center_build/app/src/main/java/ru/aicenter/mobile'

class NativeChatMigrationTests(unittest.TestCase):
    def test_database_version_and_incremental_migration(self):
        src=(BASE/'NativeStore.java').read_text()
        self.assertIn('VERSION=2',src)
        self.assertIn('oldVersion < 2',src)
        self.assertIn('CREATE TABLE IF NOT EXISTS chat_messages',src)
        self.assertNotIn('DROP TABLE',src)
    def test_exchange_is_transactional(self):
        src=(BASE/'NativeStore.java').read_text()
        self.assertIn('db.beginTransaction()',src)
        self.assertIn('db.setTransactionSuccessful()',src)
        self.assertIn('db.endTransaction()',src)
    def test_context_uses_bounded_history(self):
        src=(BASE/'OfflinePrompt.java').read_text()
        self.assertIn('store.recentChat(6)',src)
        self.assertIn('truncate(item.optString("body"),400)',src)
    def test_history_saved_after_success(self):
        src=(BASE/'MainActivity.java').read_text()
        self.assertIn('nativeStore.saveExchange(prompt,answer)',src)
        self.assertIn('if(answer==null || answer.trim().isEmpty())',src)

if __name__=='__main__':unittest.main()
