from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]

class ChatToOffice(unittest.TestCase):
    def test_ui_has_import_button(self):
        page=(ROOT/'server/mobile/v30.html').read_text(encoding='utf-8')
        self.assertIn('onclick="fillLastAnswer()"',page)
        self.assertIn("fetch('/api/chat/history'",page)
        self.assertIn("x.role==='assistant'",page)
        self.assertIn("el('officeText').value=last.body",page)
        self.assertIn('last.body.length>25000',page)
    def test_server_history_and_export(self):
        server=(ROOT/'server/mobile/server.py').read_text(encoding='utf-8')
        self.assertIn("u.path=='/api/chat/history'",server)
        self.assertIn("self.path=='/api/v36/office/create'",server)
