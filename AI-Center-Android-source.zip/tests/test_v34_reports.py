import importlib.util,pathlib,unittest,json
P=pathlib.Path(__file__).resolve().parents[1]/'server/mobile/v34_reports.py'
spec=importlib.util.spec_from_file_location('v34_reports',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ReportTests(unittest.TestCase):
 def test_html_escapes_user_content(self):
  body,typ=m.generate('<script>alert(1)</script>','<img src=x onerror=alert(1)>')
  self.assertNotIn('<script>',body)
  self.assertNotIn('<img',body)
  self.assertIn('&lt;img',body)
 def test_markdown(self):
  body,typ=m.generate('Тест','Содержание','markdown')
  self.assertIn('# Тест',body)
 def test_json(self):
  body,typ=m.generate('Тест','Текст','json')
  self.assertFalse(json.loads(body)['verified'])
 def test_rejects_large_text(self):
  with self.assertRaises(ValueError):m.generate('Тест','x'*24001)
 def test_rejects_invalid_format(self):
  with self.assertRaises(ValueError):m.generate('Тест','Текст','exe')
