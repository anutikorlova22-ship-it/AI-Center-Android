import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'android/ai_center_build/create_llama_manifest.py'
spec = importlib.util.spec_from_file_location('create_llama_manifest', SCRIPT)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class ManifestTests(unittest.TestCase):
    def make_tree(self, root):
        (root/'include').mkdir()
        (root/'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.22)')
        (root/'include'/'llama.h').write_text('header')

    def test_manifest_has_real_hashes(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); self.make_tree(root)
            result = mod.create_manifest(root, 'a'*40)
            self.assertEqual(len(result['files']), 2)
            self.assertEqual(len(result['files']['include/llama.h']), 64)

    def test_reject_unpinned_revision(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); self.make_tree(root)
            with self.assertRaises(ValueError): mod.create_manifest(root, 'master')

    def test_reject_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); self.make_tree(root)
            (root/'alias').symlink_to(root/'include'/'llama.h')
            with self.assertRaises(ValueError): mod.create_manifest(root, 'b'*40)

    def test_reject_incomplete_tree(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): mod.create_manifest(Path(d), 'c'*40)
