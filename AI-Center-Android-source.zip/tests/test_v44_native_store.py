import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
JAVA=ROOT/'android/ai_center_build/app/src/main/java/ru/aicenter/mobile/NativeStore.java'

class NativeStoreContract(unittest.TestCase):
    def test_source_present(self):
        self.assertTrue(JAVA.is_file())
    def test_sqlite_and_data_retention(self):
        s=JAVA.read_text(encoding='utf-8')
        for needle in ('SQLiteOpenHelper','CREATE TABLE notes','CREATE TABLE tasks','dueTasks','markNotified','completeTask','latestNotes'):
            self.assertIn(needle,s)
        self.assertNotIn('DROP TABLE',s)
    def test_no_termux_or_network_dependency(self):
        s=JAVA.read_text(encoding='utf-8')
        for forbidden in ('Runtime.getRuntime','ProcessBuilder','HttpURLConnection','127.0.0.1','termux'):
            self.assertNotIn(forbidden,s)

if __name__=='__main__':unittest.main()
