import pathlib, tempfile, unittest
from proactive_agent import collect, inbox, lesson, diagnostics, fetch_feed
class TestProactive(unittest.TestCase):
 def test_collection_deduplicates(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'test.db'
   f=lambda _: [('Title','https://example.com/item','Summary')]
   self.assertEqual(collect(p,{'Test':['https://hnrss.org/test']},f)['new_items'],1)
   self.assertEqual(collect(p,{'Test':['https://hnrss.org/test']},f)['new_items'],0)
   self.assertEqual(len(inbox(p)),1)
 def test_lessons_need_review(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'test.db'
   self.assertEqual(lesson(p,'fix','document'),'pending_review')
   self.assertEqual(diagnostics(p)['lessons_awaiting_review'],1)
 def test_feed_allowlist(self):
  with self.assertRaises(ValueError):fetch_feed('http://localhost/private')
 def test_diagnostics_no_self_modification(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertFalse(diagnostics(pathlib.Path(d)/'test.db')['self_modification'])
if __name__=='__main__':unittest.main()
