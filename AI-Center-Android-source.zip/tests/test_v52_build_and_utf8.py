import pathlib, unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]
class BuildConfigTests(unittest.TestCase):
    def test_gradle_opt_in(self):
        s=(ROOT/'android/ai_center_build/app/build.gradle.kts').read_text()
        self.assertIn('aicenterWithLlama',s)
        self.assertIn('AICENTER_WITH_LLAMA',s)
    def test_utf8_safe_jni(self):
        s=(ROOT/'android/ai_center_build/app/src/main/cpp/native_inference.cpp').read_text()
        self.assertIn('NewByteArray',s)
        self.assertIn('UTF-8',s)
        self.assertNotIn('NewStringUTF(output.c_str())',s)
    def test_bounded_context(self):
        s=(ROOT/'android/ai_center_build/app/src/main/cpp/native_inference.cpp').read_text()
        self.assertIn('> 4096',s)
if __name__=='__main__': unittest.main()
