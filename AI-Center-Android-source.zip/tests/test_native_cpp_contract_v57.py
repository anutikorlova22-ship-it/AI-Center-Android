"""Compile both JNI branches against a minimal API-shaped header.
This is NOT a build against real llama.cpp or Android NDK.
"""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
CPP = ROOT / 'android/ai_center_build/app/src/main/cpp/native_inference.cpp'
HEADER = r'''
#pragma once
#include <cstdint>
struct llama_model {};
struct llama_context {};
struct llama_vocab {};
struct llama_sampler {};
using llama_token = int32_t;
struct llama_model_params { int n_gpu_layers; };
struct llama_context_params { uint32_t n_ctx; uint32_t n_batch; int n_threads; int n_threads_batch; };
struct llama_sampler_chain_params {};
struct llama_batch { int n_tokens; llama_token* token; int32_t* pos; int32_t* n_seq_id; int32_t** seq_id; int8_t* logits; };
void llama_backend_init();
llama_model_params llama_model_default_params();
llama_model* llama_model_load_from_file(const char*, llama_model_params);
void llama_model_free(llama_model*);
const llama_vocab* llama_model_get_vocab(const llama_model*);
int32_t llama_tokenize(const llama_vocab*, const char*, int32_t, llama_token*, int32_t, bool, bool);
llama_context_params llama_context_default_params();
llama_context* llama_init_from_model(llama_model*, llama_context_params);
void llama_free(llama_context*);
llama_sampler_chain_params llama_sampler_chain_default_params();
llama_sampler* llama_sampler_chain_init(llama_sampler_chain_params);
void llama_sampler_free(llama_sampler*);
llama_sampler* llama_sampler_init_greedy();
void llama_sampler_chain_add(llama_sampler*, llama_sampler*);
llama_batch llama_batch_init(int32_t, int32_t, int32_t);
void llama_batch_free(llama_batch);
int32_t llama_decode(llama_context*, llama_batch);
llama_token llama_sampler_sample(llama_sampler*, llama_context*, int32_t);
bool llama_vocab_is_eog(const llama_vocab*, llama_token);
void llama_sampler_accept(llama_sampler*, llama_token);
int32_t llama_token_to_piece(const llama_vocab*, llama_token, char*, int32_t, int32_t, bool);
'''

@unittest.skipUnless(shutil.which('c++'), 'C++ compiler not available')
class NativeCppContractTests(unittest.TestCase):
    def compile(self, enabled):
        jni = next(iter(Path('/usr/lib/jvm').glob('*/include/jni.h')), None)
        if jni is None:
            self.skipTest('JDK JNI headers not available')
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, 'llama.h').write_text(HEADER)
            cmd = ['c++', '-std=c++17', '-fsyntax-only', '-Wall', '-Wextra', '-Werror',
                   '-I', str(jni.parent), '-I', str(jni.parent / 'linux'), '-I', tmp]
            if enabled:
                cmd += ['-DAICENTER_WITH_LLAMA=1']
            cmd += [str(CPP)]
            result = subprocess.run(cmd, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_jni_without_llama(self):
        self.compile(False)

    def test_jni_with_llama_api_contract_stub(self):
        self.compile(True)

if __name__ == '__main__':
    unittest.main()
