import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'server/bin/daily_cycle_v31.py'
spec = importlib.util.spec_from_file_location('daily_cycle_v31', SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class DailyCycleTests(unittest.TestCase):
    def test_missing_scripts_do_not_run(self):
        with tempfile.TemporaryDirectory() as d:
            result = module.run_cycle(d, runner=lambda *a, **kw: self.fail('unexpected run'))
            self.assertEqual(result['successful'], 0)
            self.assertEqual(result['skipped'], len(module.STEPS))
            self.assertEqual(result['auto_installed_features'], 0)
            self.assertTrue((Path(d) / 'knowledge_agent/daily_status.json').exists())

    def test_bundled_scripts_and_failed_exit(self):
        with tempfile.TemporaryDirectory() as d:
            bindir = Path(d) / 'bin'
            bindir.mkdir()
            for _, filename, _ in module.STEPS:
                (bindir / filename).write_text('pass\n')
            calls = []
            def runner(cmd, **kwargs):
                calls.append((cmd, kwargs))
                return subprocess.CompletedProcess(cmd, 1 if len(calls) == 2 else 0, 'test', 'failed')
            result = module.run_cycle(d, runner=runner)
            self.assertEqual(result['failed'], 1)
            self.assertEqual(result['successful'], len(module.STEPS)-1)
            self.assertEqual(len(calls), len(module.STEPS))
            self.assertTrue(all('timeout' in kw for _, kw in calls))

    def test_symlink_script_is_not_run(self):
        with tempfile.TemporaryDirectory() as d:
            bindir = Path(d) / 'bin'
            bindir.mkdir()
            (bindir / module.STEPS[0][1]).symlink_to('/etc/passwd')
            result = module.run_cycle(d, runner=lambda *a, **kw: self.fail('unsafe execution'))
            self.assertEqual(result['skipped'], len(module.STEPS))
