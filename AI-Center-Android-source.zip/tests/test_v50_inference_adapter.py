import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
CPP = ROOT / 'android/ai_center_build/app/src/main/cpp/native_inference.cpp'

class NativeAdapterTests(unittest.TestCase):
    def test_opt_in_build_guard(self):
        source = CPP.read_text()
        self.assertIn('#ifdef AICENTER_WITH_LLAMA', source)
        self.assertIn('#ifndef AICENTER_WITH_LLAMA', source)
        self.assertIn('UnsupportedOperationException', source)

    def test_actual_decode_and_sampling(self):
        source = CPP.read_text()
        for name in ('llama_model_load_from_file', 'llama_tokenize', 'llama_decode',
                     'llama_sampler_sample', 'llama_token_to_piece'):
            self.assertIn(name, source)

    def test_limits_and_cpu_mode(self):
        source = CPP.read_text()
        self.assertIn('max_tokens > 2048', source)
        self.assertIn('prompt.size() > 65536', source)
        self.assertIn('mp.n_gpu_layers = 0', source)

if __name__ == '__main__': unittest.main()
