from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
WF = ROOT / 'android/ai_center_build/.github/workflows/build-native-offline.yml'

class NativeWorkflowTests(unittest.TestCase):
    def test_native_is_explicitly_enabled(self):
        s = WF.read_text()
        self.assertIn('-PaicenterWithLlama=true', s)
        self.assertIn('assembleDebug', s)
    def test_pinned_revision_required(self):
        s = WF.read_text()
        self.assertIn('llama_ref:', s)
        self.assertIn('40}', s)
        self.assertIn('git checkout --detach', s)
    def test_no_auto_push_build(self):
        s = WF.read_text()
        self.assertIn('workflow_dispatch:', s)
        self.assertNotIn('  push:', s)
    def test_sdk_ndk_and_no_install(self):
        s = WF.read_text()
        self.assertIn('ndk;27.2.12479018', s)
        self.assertIn('android-35', s)
        self.assertNotIn('adb install', s)

if __name__ == '__main__': unittest.main()
