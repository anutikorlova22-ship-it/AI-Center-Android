import pathlib
import unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
JAVA=ROOT/'android/ai_center_build/app/src/main/java/ru/aicenter/mobile'
class NativeSkillTests(unittest.TestCase):
    def test_library_data_only(self):
        s=(JAVA/'SkillLibrary.java').read_text()
        for x in ['MAX_INPUT=65536','MAX_SKILLS=100','user_import','SharedPreferences','input.has("code")','input.has("command")']:
            self.assertIn(x,s)
        self.assertNotIn('Runtime.getRuntime()',s)
    def test_import_requires_review(self):
        s=(JAVA/'MainActivity.java').read_text()
        for x in ['ACTION_OPEN_DOCUMENT','SKILL_IMPORT_REQUEST','AlertDialog.Builder','setNegativeButton("Отмена"','setPositiveButton("Сохранить"']:
            self.assertIn(x,s)
    def test_termux_still_needed(self):
        manifest=(ROOT/'android/ai_center_build/app/src/main/AndroidManifest.xml').read_text()
        self.assertIn('com.termux.permission.RUN_COMMAND',manifest)
if __name__=='__main__':unittest.main()
