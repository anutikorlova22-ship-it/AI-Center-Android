import pathlib, unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]
APP = ROOT / "android/ai_center_build/app"
class NativeBridgeTests(unittest.TestCase):
    def test_cmake_wired(self):
        gradle = (APP / "build.gradle.kts").read_text()
        self.assertIn('externalNativeBuild', gradle)
        self.assertIn('src/main/cpp/CMakeLists.txt', gradle)
    def test_java_bridge(self):
        java = (APP / "src/main/java/ru/aicenter/mobile/NativeInference.java").read_text()
        self.assertIn('System.loadLibrary("aicenter_native")', java)
        self.assertIn('maxTokens > 2048', java)
    def test_native_fails_closed(self):
        cpp = (APP / "src/main/cpp/native_inference.cpp").read_text()
        self.assertIn('UnsupportedOperationException', cpp)
        self.assertIn('llama.cpp is not linked', cpp)
if __name__ == '__main__': unittest.main()
