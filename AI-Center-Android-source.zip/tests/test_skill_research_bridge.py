import sqlite3
import tempfile
import unittest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))
from mobile.skill_research_bridge import research_leads, draft_skill, submit_draft
from mobile.skill_candidates import pending

class SkillResearchBridgeTests(unittest.TestCase):
    def test_research_leads_are_never_skills(self):
        with tempfile.TemporaryDirectory() as temp:
            db = Path(temp)/'features.db'
            con = sqlite3.connect(db)
            con.execute('CREATE TABLE candidates (title TEXT,url TEXT,category TEXT,score INTEGER,rationale TEXT,status TEXT,seen_at TEXT)')
            con.executemany('INSERT INTO candidates VALUES(?,?,?,?,?,?,?)', [
                ('Good', 'https://example.org/post', 'Android', 75, 'offline', 'proposed', '2026'),
                ('Bad', 'javascript:alert(1)', 'Android', 99, 'bad', 'proposed', '2026'),
                ('Done', 'https://example.org/old', 'AI', 80, 'old', 'rejected', '2026')])
            con.commit(); con.close()
            leads = research_leads(db)
            self.assertEqual(len(leads), 1)
            self.assertFalse(leads[0]['can_activate'])
    def test_missing_database(self):
        with tempfile.TemporaryDirectory() as temp:
            self.assertEqual(research_leads(Path(temp)/'missing.db'), [])
    def test_draft_requires_https_and_approval(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                draft_skill('Name', 'Helpful instruction', 'file:///etc/passwd')
            draft = draft_skill('Name', 'Helpful instruction', 'https://example.org')
            self.assertTrue(draft['requires_manual_review'])
            ident = submit_draft(temp, 'Name', 'Helpful instruction', 'https://example.org')
            self.assertEqual(pending(temp)[0]['id'], ident)
            self.assertEqual(pending(temp)[0]['status'], 'pending')

if __name__ == '__main__': unittest.main()
