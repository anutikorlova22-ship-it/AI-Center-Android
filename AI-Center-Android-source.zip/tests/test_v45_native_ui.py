import pathlib,unittest
P=pathlib.Path(__file__).resolve().parents[1]/"android/ai_center_build/app/src/main/java/ru/aicenter/mobile"
class NativeUiContract(unittest.TestCase):
    def test_native_ui(self):
        s=(P/"MainActivity.java").read_text()
        for name in ("showNativeNotes()","showNativeTasks()","createNativeTask()","nativeStore.addNote","nativeStore.addTask","nativeStore.completeTask"):
            self.assertIn(name,s)
    def test_native_background_no_network(self):
        s=(P/"ReminderReceiver.java").read_text()
        self.assertIn("checkNative(app);check(app);",s)
        self.assertIn("store.dueTasks(System.currentTimeMillis())",s)
        self.assertIn("store.markNotified(id)",s)
    def test_native_tasks_list(self):
        self.assertIn("pendingTasks(int limit)",(P/"NativeStore.java").read_text())
