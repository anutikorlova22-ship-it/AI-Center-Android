# V44 — native Android data foundation

`NativeStore.java` adds Android SQLite persistence for notes and reminders without Python or Termux. This is a **foundation**, not a working migration: the existing WebView/chat still calls `127.0.0.1:8765`, and the model still requires its old runtime. The new store is not yet wired to the chat or notification receiver.

Next: expose native storage through a narrowly scoped JavaScript bridge (or native screens), port scheduler/notifications, integrate Android-compatible llama.cpp JNI for GGUF model inference, then remove localhost/Termux only after tests on real devices. An Android build has not been executed in this environment.

Do not automatically run downloaded AI skills, packages or scripts. Treat online material as untrusted until reviewed and approved.
