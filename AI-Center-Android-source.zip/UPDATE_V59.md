# AI Center 5.9 — strict llama.cpp vendor integrity gate

The offline verifier now rejects untracked files, symlinks, unsafe manifest paths,
missing/invalid full upstream commit identifiers, and modified file hashes.
The manifest must live **outside** the vendor tree and be generated from a
reviewed, pinned upstream revision. This is an integrity check, not proof of
upstream authenticity. Do not enable `AICENTER_WITH_LLAMA` without review.

`python -m unittest discover -s tests -p 'test_*.py' -q`

No Android SDK/NDK or upstream llama.cpp sources are bundled in this archive.
No APK or actual Android model inference was built or tested.
