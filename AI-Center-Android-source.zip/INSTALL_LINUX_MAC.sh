#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/android/ai_center_build"
exec bash ./build_and_install_linux_mac.sh "${@}"
