# AI Center 5.5 — offline llama.cpp source verification and token positioning

- Fixed generated-token decoding to supply an explicit KV-cache position, sequence id, and logits flag, with batch cleanup on success/failure.
- Added `android/ai_center_build/verify_llama_vendor.py` to check locally supplied llama.cpp files against a user-reviewed SHA-256 manifest. This verifier does **not** download or run third-party code.
- This archive intentionally does not contain llama.cpp or model weights. A real Android NDK build and on-device inference are still unverified. Termux remains necessary for the existing server chat.
- Do not remove Termux or deploy until the new native path is built and tested.

Example manifest: `{"upstream_commit":"<full reviewed git commit>","files":{"include/llama.h":"<sha256 hex>"}}`.
