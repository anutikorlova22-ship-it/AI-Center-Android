# AI Center 5.2 — Android inference build hardening

- `-PaicenterWithLlama=true` now passes `AICENTER_WITH_LLAMA=ON` to CMake. This requires **reviewed llama.cpp source code** in `app/src/main/cpp/vendor/llama.cpp`.
- Default is OFF; a stub must never claim successful inference.
- JNI output is converted from standard UTF-8 through a Java String constructor; avoids NewStringUTF misuse on multilingual generated output.
- Native context is capped at 4096 tokens for a conservative phone baseline.

**Not yet verified:** Android NDK compilation against an actual llama.cpp checkout, APK generation, device inference, model memory use, or independence from Termux for the main chat. No binaries or external code are bundled. The offline chat is experimental and will not run without a compiled inference backend.
