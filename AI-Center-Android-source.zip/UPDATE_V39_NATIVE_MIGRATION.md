# V39 — native migration, phase 1

## Implemented
- Android Storage Access Framework JSON file picker on home screen.
- SkillLibrary.java: import data-only instruction cards, size limits, preview and explicit approval, local SharedPreferences storage, duplicate-name replacement, maximum 100 cards.
- Import does not execute code, download dependencies, or silently modify the assistant prompt.

Example skill file:
```json
{"name":"Редактор постов","instructions":"Предлагай три варианта поста. Указывай факты отдельно от предположений. Не публикуй ничего без подтверждения."}
```

## NOT implemented / migration remaining
- The app still relies on Termux-hosted Python HTTP services at 127.0.0.1:8765 and llama.cpp at 8081. Termux must NOT be removed from an existing installation yet.
- Native model runtime: integrate and benchmark Android-compatible llama.cpp library with NDK/JNI, memory limits, model import, device ABI support.
- Port SQLite persistence, task scheduling, file export, and source-grounded search from Python server into Kotlin/Java or an embedded runtime.
- Remove RUN_COMMAND permission, package query, Termux launch scripts and HTTP loopback assumptions only after native parity tests.
- Background jobs should use Android JobScheduler/WorkManager and account for battery restrictions.
- Skill discovery: candidate catalog from trusted sources, user review, explicit opt-in, origin/license metadata, prompt-injection checks. Do not auto-execute scripts or fetch/install binaries.
- Imported skills are stored as a library only; injecting them into Qwen prompt requires a separate, user-selectable integration with length limits and instruction hierarchy.
- Build and on-device validation have not been performed.
