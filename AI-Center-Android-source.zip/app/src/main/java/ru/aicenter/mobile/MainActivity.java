package ru.aicenter.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final String SERVER = "http://127.0.0.1:8765/";
    private WebView web;
    private LinearLayout errorView;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,19,38));
        getWindow().setNavigationBarColor(Color.rgb(8,19,38));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8,19,38));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,19,38));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("127.0.0.1".equals(u.getHost()) && u.getPort() == 8765 && "http".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch (Exception ignored) { }
                return true;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) { web.setVisibility(View.GONE); errorView.setVisibility(View.VISIBLE); }
            }
            @Override public void onPageFinished(WebView view,String url) {
                // Hide offline notice only if the local server page actually loads.
            }
        });
        errorView = new LinearLayout(this);
        errorView.setOrientation(LinearLayout.VERTICAL);
        errorView.setPadding(36,80,36,24);
        TextView title = new TextView(this);
        title.setText("ИИ Центр\n\nЛокальный сервер не запущен");
        title.setTextColor(Color.WHITE); title.setTextSize(23);
        errorView.addView(title);
        TextView instructions = new TextView(this);
        instructions.setText("Открой Termux или ярлык ИИ Центра, запусти локальный сервер и нажми «Повторить».\n\nКоманда: bash ~/AI_CENTER/bin/start_ai_center.sh");
        instructions.setTextColor(Color.LTGRAY); instructions.setTextSize(16);
        errorView.addView(instructions);
        Button termux = new Button(this); termux.setText("Открыть Termux");
        termux.setOnClickListener(v -> {
            try { Intent i = getPackageManager().getLaunchIntentForPackage("com.termux"); if (i != null) startActivity(i); }
            catch (Exception ignored) { }
        });
        errorView.addView(termux);
        Button retry = new Button(this); retry.setText("Повторить подключение");
        retry.setOnClickListener(v -> { errorView.setVisibility(View.GONE); web.setVisibility(View.VISIBLE); web.loadUrl(SERVER); });
        errorView.addView(retry);
        errorView.setVisibility(View.GONE);
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(errorView,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        web.loadUrl(SERVER);
    }
    @Override public void onBackPressed() {
        if (web.getVisibility()==View.VISIBLE && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
