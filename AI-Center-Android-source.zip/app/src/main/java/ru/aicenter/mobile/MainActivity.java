package ru.aicenter.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String SERVER = "http://127.0.0.1:8765/";
    private static final int REQ_TERMUX = 71;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private WebView web;
    private LinearLayout waiting;
    private TextView status;
    private LinearLayout dashboard;
    private TextView dashboardText;
    private boolean showingDashboard = false;
    private boolean active = true;
    private int attempts = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,19,38));
        getWindow().setNavigationBarColor(Color.rgb(8,19,38));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8,19,38));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,19,38));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("127.0.0.1".equals(u.getHost()) && u.getPort() == 8765 && "http".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    web.setVisibility(View.GONE);
                    waiting.setVisibility(View.VISIBLE);
                    status.setText("Не удалось загрузить панель. Попробуй повторить подключение.");
                }
            }
        });
        waiting = new LinearLayout(this);
        waiting.setOrientation(LinearLayout.VERTICAL);
        waiting.setPadding(40, 90, 40, 30);
        TextView title = new TextView(this);
        title.setText("ИИ Центр");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        waiting.addView(title);
        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(16);
        status.setPadding(0, 25, 0, 25);
        waiting.addView(status);
        Button retry = new Button(this);
        retry.setText("Запустить / повторить");
        retry.setOnClickListener(v -> begin());
        waiting.addView(retry);
        Button termux = new Button(this);
        termux.setText("Открыть Termux");
        termux.setOnClickListener(v -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.termux");
            if (i != null) startActivity(i);
        });
        waiting.addView(termux);
        LinearLayout nav = new LinearLayout(this);
        Button chatButton = new Button(this);
        chatButton.setText("Чат");
        chatButton.setOnClickListener(v -> { showingDashboard = false; dashboard.setVisibility(View.GONE); if (healthAsyncNeeded()) begin(); else { waiting.setVisibility(View.GONE); web.setVisibility(View.VISIBLE); } });
        Button monitorButton = new Button(this);
        monitorButton.setText("Задачи и состояние");
        monitorButton.setOnClickListener(v -> showDashboard());
        nav.addView(chatButton, new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(monitorButton, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(nav);
        dashboard = new LinearLayout(this);
        dashboard.setOrientation(LinearLayout.VERTICAL);
        dashboard.setPadding(25, 25, 25, 25);
        dashboardText = new TextView(this);
        dashboardText.setTextColor(Color.WHITE);
        dashboardText.setTextSize(15);
        dashboard.addView(dashboardText);
        Button refresh = new Button(this);
        refresh.setText("Обновить состояние");
        refresh.setOnClickListener(v -> refreshDashboard());
        dashboard.addView(refresh);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(dashboard);
        dashboard.setTag(scroll);
        scroll.setVisibility(View.GONE);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(waiting, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        begin();
    }

    private boolean healthAsyncNeeded() { return web.getUrl() == null; }

    private void showDashboard() {
        showingDashboard = true;
        web.setVisibility(View.GONE);
        waiting.setVisibility(View.GONE);
        ((View)dashboard.getTag()).setVisibility(View.VISIBLE);
        refreshDashboard();
    }

    private void refreshDashboard() {
        dashboardText.setText("Проверяю сервер и задания…");
        executor.execute(() -> {
            String result;
            try {
                HttpURLConnection c = (HttpURLConnection)new URL("http://127.0.0.1:8766/status").openConnection();
                c.setConnectTimeout(1800); c.setReadTimeout(3500);
                if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
                try (InputStream in = c.getInputStream(); ByteArrayOutputStream b = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[4096]; int n;
                    while ((n = in.read(buf)) > 0 && b.size() < 200000) b.write(buf, 0, n);
                    JSONObject data = new JSONObject(b.toString("UTF-8"));
                    StringBuilder text = new StringBuilder("ЦЕНТР УПРАВЛЕНИЯ\n\n");
                    text.append("Панель: ").append(data.optBoolean("web_ok") ? "🟢 работает" : "🔴 недоступна").append("\n");
                    text.append("Qwen: ").append(data.optBoolean("qwen_ok") ? "🟢 отвечает" : "🔴 не отвечает").append("\n");
                    text.append("Cron: ").append(data.optBoolean("cron_running") ? "🟢 запущен" : "🔴 остановлен").append("\n");
                    text.append("База: ").append(data.optString("database_status", "неизвестно")).append("\n");
                    text.append("Обновлено: ").append(data.optString("checked_at", "—")).append("\n\nЗАДАНИЯ CRON\n");
                    JSONArray jobs = data.optJSONArray("jobs");
                    if (jobs != null) for (int i = 0; i < jobs.length(); i++) {
                        JSONObject job = jobs.getJSONObject(i);
                        text.append("\n🟡 ").append(job.optString("name", "Задание"))
                            .append("\n  Следующий запуск: ").append(job.optString("next_run", "не определён"))
                            .append("\n  Через: ").append(job.optString("countdown", "—"))
                            .append("\n  Результат: ").append(job.optString("last_result", "нет подтверждения"))
                            .append("\n");
                    }
                    result = text.toString();
                } finally { c.disconnect(); }
            } catch (Exception ex) { result = "Мониторинг пока недоступен.\nУстанови компонент termux/install.sh из V2.3 и открой приложение повторно.\n\n" + ex.getClass().getSimpleName(); }
            String finalResult = result;
            ui.post(() -> { if (active && showingDashboard) dashboardText.setText(finalResult); });
        });
    }

    private void begin() {
        attempts = 0;
        ((View)dashboard.getTag()).setVisibility(View.GONE);
        web.setVisibility(View.GONE);
        waiting.setVisibility(View.VISIBLE);
        status.setText("Проверяю локальный сервер...");
        executor.execute(() -> {
            boolean ready = health();
            ui.post(() -> {
                if (!active) return;
                if (ready) showChat();
                else requestLaunchPermission();
            });
        });
    }

    private void requestLaunchPermission() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("com.termux.permission.RUN_COMMAND") != PackageManager.PERMISSION_GRANTED) {
            status.setText("Разреши запуск команд Termux для автоматического старта сервера.");
            requestPermissions(new String[]{"com.termux.permission.RUN_COMMAND"}, REQ_TERMUX);
        } else launchTermux();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_TERMUX) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchTermux();
            else status.setText("Разрешение Termux не предоставлено. Разреши его в настройках Android и нажми «Повторить».");
        }
    }

    private void launchTermux() {
        status.setText("Запускаю сервер через Termux. Подожди до 60 секунд...");
        try {
            Intent intent = new Intent("com.termux.RUN_COMMAND");
            intent.setClassName("com.termux", "com.termux.app.RunCommandService");
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"/data/data/com.termux/files/home/AI_CENTER/bin/launch_from_android.sh"});
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            startService(intent);
            poll();
        } catch (Exception ex) {
            status.setText("Termux не разрешил запуск: " + ex.getClass().getSimpleName() + ". Проверь allow-external-apps=true и разрешение RUN_COMMAND.");
        }
    }

    private void poll() {
        if (!active) return;
        executor.execute(() -> {
            boolean ready = health();
            ui.post(() -> {
                if (!active) return;
                if (ready) showChat();
                else if (++attempts < 30) ui.postDelayed(this::poll, 2000);
                else status.setText("Сервер не ответил за 60 секунд. Проверь Termux и ~/AI_CENTER/logs/android_autostart.log, затем нажми «Повторить».");
            });
        });
    }

    private boolean health() {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(SERVER).openConnection();
            conn.setConnectTimeout(1500);
            conn.setReadTimeout(1500);
            return conn.getResponseCode() >= 200 && conn.getResponseCode() < 400;
        } catch (Exception ignored) { return false; }
        finally { if (conn != null) conn.disconnect(); }
    }

    private void showChat() {
        if (showingDashboard) return;
        waiting.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
        web.loadUrl(SERVER);
    }

    @Override public void onBackPressed() {
        if (web.getVisibility() == View.VISIBLE && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        active = false;
        executor.shutdownNow();
        web.destroy();
        super.onDestroy();
    }
}
