package ru.aicenter.mobile;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String CHAT="http://127.0.0.1:8765/", MONITOR="http://127.0.0.1:8766/status";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService pool=Executors.newSingleThreadExecutor();
    private final int BG=Color.rgb(8,19,38), ACCENT=Color.rgb(71,191,245);
    private LinearLayout root, nav, home, dashboard, loading;
    private Button[] navButtons=new Button[3];
    private WebView web;
    private TextView headline, report, summary;
    private Orb orb;
    private boolean alive=true, chatLoaded=false;
    private int page=0, polls=0;
    private final Runnable refreshLoop=new Runnable(){ public void run(){ if(!alive)return; refresh(); handler.postDelayed(this,15000); }};
    int dp(int x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable pill(int fill,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(14));d.setStroke(dp(1),stroke);return d;}
    private Button styled(String label,boolean active){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(active?BG:Color.rgb(203,232,250));b.setBackground(pill(active?ACCENT:Color.rgb(17,46,77),active?ACCENT:Color.rgb(38,105,148)));b.setElevation(0);return b;}
    private void styleNav(){for(int i=0;i<navButtons.length;i++){boolean active=i==page;navButtons[i].setBackground(pill(active?ACCENT:Color.rgb(17,46,77),active?ACCENT:Color.rgb(38,105,148)));navButtons[i].setTextColor(active?BG:Color.rgb(203,232,250));}}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(18),dp(12),dp(18),dp(12));
        TextView brand=text("◈  ИИ ЦЕНТР",19,Color.WHITE);bar.addView(brand,new LinearLayout.LayoutParams(0,dp(40),1));
        headline=text("● ПРОВЕРКА",11,ACCENT);bar.addView(headline);root.addView(bar);
        nav=new LinearLayout(this);nav.setPadding(dp(8),0,dp(8),dp(6));
        String[] names={"Главная","Чат","Контроль"};for(int i=0;i<3;i++){final int target=i;Button btn=styled(names[i],i==0);navButtons[i]=btn;btn.setOnClickListener(v->show(target));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(48),1);np.setMargins(dp(4),0,dp(4),0);nav.addView(btn,np);}root.addView(nav);
        home=new LinearLayout(this);home.setGravity(Gravity.CENTER_HORIZONTAL);home.setOrientation(LinearLayout.VERTICAL);home.setPadding(dp(16),dp(8),dp(16),dp(8));
        TextView hello=text("Твой локальный командный центр",17,Color.WHITE);hello.setGravity(Gravity.CENTER);home.addView(hello);
        orb=new Orb();home.addView(orb,new LinearLayout.LayoutParams(-1,0,1));
        summary=text("Проверяю сервисы…",15,Color.LTGRAY);summary.setGravity(Gravity.CENTER);home.addView(summary,new LinearLayout.LayoutParams(-1,dp(140)));
        Button go=styled("Открыть чат  →",true);go.setOnClickListener(v->show(1));home.addView(go,new LinearLayout.LayoutParams(-1,dp(50)));
        root.addView(home,new LinearLayout.LayoutParams(-1,0,1));
        web=new WebView(this);web.setBackgroundColor(BG);WebSettings ws=web.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);ws.setAllowFileAccess(false);ws.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){android.net.Uri u=r.getUrl();if("http".equals(u.getScheme())&&"127.0.0.1".equals(u.getHost())&&u.getPort()==8765)return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;}});
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        ScrollView scroll=new ScrollView(this);dashboard=new LinearLayout(this);dashboard.setPadding(dp(20),dp(12),dp(20),dp(20));dashboard.setOrientation(LinearLayout.VERTICAL);
        TextView heading=text("Состояние системы",23,Color.WHITE);dashboard.addView(heading);report=text("Проверяю…",15,Color.LTGRAY);report.setPadding(0,dp(15),0,dp(20));dashboard.addView(report);
        Button update=styled("↻  Обновить состояние",false);update.setOnClickListener(v->refresh());dashboard.addView(update);scroll.addView(dashboard);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));dashboard.setTag(scroll);
        loading=new LinearLayout(this);loading.setGravity(Gravity.CENTER);loading.setOrientation(LinearLayout.VERTICAL);TextView wait=text("Запускаю локальный сервер…",17,Color.WHITE);loading.addView(wait);
        Button retry=styled("Повторить запуск",true);retry.setOnClickListener(v->startServices());loading.addView(retry);root.addView(loading,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);show(0);startServices();handler.post(refreshLoop);
    }
    private void show(int selected){page=selected;styleNav();home.setVisibility(selected==0?View.VISIBLE:View.GONE);web.setVisibility(selected==1?View.VISIBLE:View.GONE);((View)dashboard.getTag()).setVisibility(selected==2?View.VISIBLE:View.GONE);loading.setVisibility(View.GONE);if(selected==1&&!chatLoaded){chatLoaded=true;web.loadUrl(CHAT);}if(selected==2)refresh();}
    private boolean ping(String url){HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(1200);c.setReadTimeout(1500);return c.getResponseCode()==200;}catch(Exception e){return false;}finally{if(c!=null)c.disconnect();}}
    private void startServices(){pool.execute(()->{boolean a=ping(CHAT),b=ping(MONITOR);if(!a||!b)handler.post(this::launchTermux);else handler.post(this::refresh);});}
    private void launchTermux(){try{if(Build.VERSION.SDK_INT>=23&&checkSelfPermission("com.termux.permission.RUN_COMMAND")!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"com.termux.permission.RUN_COMMAND"},71);return;}
        Intent i=new Intent("com.termux.RUN_COMMAND");i.setClassName("com.termux","com.termux.app.RunCommandService");i.putExtra("com.termux.RUN_COMMAND_PATH","/data/data/com.termux/files/usr/bin/bash");i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",new String[]{"/data/data/com.termux/files/home/AI_CENTER/bin/launch_from_android.sh"});i.putExtra("com.termux.RUN_COMMAND_WORKDIR","/data/data/com.termux/files/home");i.putExtra("com.termux.RUN_COMMAND_BACKGROUND",true);startService(i);polls=0;handler.postDelayed(this::poll,2000);
    }catch(Exception e){headline.setText("● НУЖЕН TERMUX");summary.setText("Не удалось запустить службы: "+e.getClass().getSimpleName());}}
    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] grants){super.onRequestPermissionsResult(req,perms,grants);if(req==71&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)launchTermux();}
    private void poll(){if(!alive)return;pool.execute(()->{boolean ok=ping(CHAT)&&ping(MONITOR);handler.post(()->{if(!alive)return;if(ok){refresh();if(page==1)web.reload();}else if(++polls<30)handler.postDelayed(this::poll,2000);else{headline.setText("● СЛУЖБЫ НЕ ГОТОВЫ");summary.setText("Проверь журнал Termux: ~/AI_CENTER/logs/status_server.log");}});});}
    private void refresh(){pool.execute(()->{String out;String shortText;boolean good=false;try{HttpURLConnection c=(HttpURLConnection)new URL(MONITOR).openConnection();c.setConnectTimeout(1800);c.setReadTimeout(5000);if(c.getResponseCode()!=200)throw new Exception("HTTP "+c.getResponseCode());ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1&&bytes.size()<250000)bytes.write(buf,0,n);}c.disconnect();JSONObject j=new JSONObject(bytes.toString("UTF-8"));boolean chat=j.optBoolean("web_ok"),qwen=j.optBoolean("qwen_ok"),cron=j.optBoolean("cron_running"),net=j.optBoolean("internet_ok"),drive=j.optBoolean("drive_ok");good=chat;
        StringBuilder sb=new StringBuilder();sb.append("Сервер чата: ").append(dot(chat)).append("\n\nQwen: ").append(dot(qwen)).append("\n\nПланировщик: ").append(dot(cron)).append("\n\nИнтернет: ").append(dot(net)).append("\n\nGoogle Drive: ").append(dot(drive)).append("\n").append(j.optString("drive_detail",""));sb.append("\n\nБаза памяти: ").append(j.optString("database_status","неизвестно"));sb.append("\n\nПроверено: ").append(j.optString("checked_at","—"));sb.append("\n\nЗАДАЧИ И ВРЕМЯ ДО ЗАПУСКА\n");JSONArray jobs=j.optJSONArray("jobs");if(jobs!=null){for(int i=0;i<jobs.length();i++){JSONObject task=jobs.optJSONObject(i);if(task==null)continue;sb.append("\n◷ ").append(task.optString("name","Задача")).append("\n   Запуск: ").append(task.optString("next_run","—")).append("\n   Через: ").append(task.optString("countdown","—")).append("\n   Итог: ").append(task.optString("last_result","нет данных")).append("\n");}}out=sb.toString();shortText="Чат "+dot(chat)+"    Qwen "+dot(qwen)+"\nИнтернет "+dot(net)+"    Drive "+dot(drive)+"\nЗадач: "+(jobs==null?0:jobs.length());
    }catch(Exception ex){out="Мониторинг недоступен (127.0.0.1:8766).\n\nОткрой Termux и проверь status_server.log.\n"+ex.getClass().getSimpleName();shortText="Мониторинг пока не отвечает";}
    final String a=out,b=shortText;final boolean up=good;handler.post(()->{if(!alive)return;report.setText(a);summary.setText(b);headline.setText(up?"● СЕРВЕР В СЕТИ":"● ПРОВЕРКА СЛУЖБ");orb.setHealthy(up);});});}
    private String dot(boolean value){return value?"🟢 работает":"🟡 не подтверждено";}
    @Override public void onBackPressed(){if(page!=0){show(0);return;}super.onBackPressed();}
    @Override public void onDestroy(){alive=false;handler.removeCallbacksAndMessages(null);pool.shutdownNow();web.destroy();super.onDestroy();}
    private class Orb extends View {private final Paint p=new Paint(3);private float phase=0;private boolean healthy=false;Orb(){super(MainActivity.this);}void setHealthy(boolean v){healthy=v;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float x=getWidth()/2f,y=getHeight()/2f;float radius=Math.min(getWidth(),getHeight())*.31f;phase+=.026f;float wobble=(float)Math.sin(phase)*radius*.035f;int core=healthy?Color.rgb(68,219,240):Color.rgb(65,154,224);p.setShader(new RadialGradient(x+radius*.1f*(float)Math.sin(phase*.7),y-radius*.25f,radius*1.13f,new int[]{Color.rgb(194,249,255),core,Color.rgb(13,46,91),BG},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,radius+wobble,p);p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.argb(110,80,205,255));c.drawCircle(x,y,radius*1.12f+wobble,p);p.setColor(Color.argb(45,80,205,255));c.drawCircle(x,y,radius*1.24f-wobble,p);p.setStyle(Paint.Style.FILL);if(alive)postInvalidateDelayed(33);}
    }
}
