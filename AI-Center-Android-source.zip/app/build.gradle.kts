plugins { id("com.android.application") }
android {
    namespace = "ru.aicenter.mobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.aicenter.mobile"
        minSdk = 26
        targetSdk = 32
        versionCode = 2
        versionName = "2.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
