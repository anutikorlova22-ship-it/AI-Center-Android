plugins { id("com.android.application") }
android {
    namespace = "ru.aicenter.mobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.aicenter.mobile"
        minSdk = 26
        targetSdk = 32
        versionCode = 4
        versionName = "2.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
