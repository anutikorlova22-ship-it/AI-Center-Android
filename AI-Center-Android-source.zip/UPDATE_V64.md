# ИИ Центр 6.4 — исправление расположения GitHub Actions

Добавлен workflow `.github/workflows/android-native-build.yml` в **корень полного архива исходников**. Ранее workflow располагался только внутри `android/ai_center_build/.github/workflows/` и не запускался при публикации всего архива как корня репозитория GitHub.

Новый workflow использует `working-directory: android/ai_center_build`, устанавливает SDK/NDK и собирает `assembleDebug` с `-PaicenterWithLlama=true`. Для запуска нужен проверенный 40-символьный SHA коммита llama.cpp. Сборка запускается только вручную. Архив не содержит ни llama.cpp, ни GGUF-модель, ни собранный APK.

**Статус:** структурная проверка workflow и тесты Python выполнены локально. GitHub Actions не запускался, реальная сборка Android и работа Qwen на телефоне не подтверждены.
