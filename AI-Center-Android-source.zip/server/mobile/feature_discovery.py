#!/usr/bin/env python3
"""Research-based feature suggestions; no untrusted code execution or automatic installation."""
import argparse
import datetime as dt
import hashlib
import json
import pathlib
import sqlite3
from urllib.parse import urlparse

from proactive_agent import fetch_feed

DB=pathlib.Path.home()/'AI_CENTER/knowledge/feature_discovery.db'
FEEDS={
    'Android': 'https://news.google.com/rss/search?q=Android+offline+AI+features&hl=en-US&gl=US&ceid=US:en',
    'Локальные ИИ': 'https://hnrss.org/newest?q=llama.cpp',
    'ИИ инструменты': 'https://hnrss.org/newest?q=on-device+AI',
}
INTERESTS={
    'offline': ('offline','on-device','local','android','termux','llama','qwen'),
    'voice': ('voice','speech','tts','whisper','audio'),
    'documents': ('document','pdf','retrieval','rag','search'),
    'automation': ('automation','agent','schedule','reminder','workflow'),
    'media': ('image','video','music','audio','generation'),
    'privacy': ('privacy','security','encrypted','permission'),
}

def connect(path=DB):
    path.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(path)
    con.execute('CREATE TABLE IF NOT EXISTS candidates (id TEXT PRIMARY KEY, category TEXT NOT NULL, title TEXT NOT NULL, url TEXT NOT NULL, summary TEXT NOT NULL, score INTEGER NOT NULL, rationale TEXT NOT NULL, status TEXT NOT NULL DEFAULT "proposed", seen_at TEXT NOT NULL)')
    return con

def rank(title,summary):
    content=(title+' '+summary).lower()
    matches=[name for name,terms in INTERESTS.items() if any(term in content for term in terms)]
    score=min(100,15+15*len(matches)) if matches else 0
    return score, ', '.join(matches)

def collect(path=DB,feeds=FEEDS,fetcher=fetch_feed):
    added=0; errors=[];now=dt.datetime.now(dt.timezone.utc).isoformat()
    with connect(path) as con:
        for category,url in feeds.items():
            try:
                for title,link,summary in fetcher(url):
                    parsed=urlparse(link)
                    if parsed.scheme!='https' or not parsed.hostname:continue
                    score,rationale=rank(title,summary)
                    if score<30:continue
                    uid=hashlib.sha256(link.encode('utf-8')).hexdigest()
                    cur=con.execute('INSERT OR IGNORE INTO candidates(id,category,title,url,summary,score,rationale,seen_at) VALUES(?,?,?,?,?,?,?,?)',(uid,category,title[:300],link[:1500],summary[:1200],score,rationale,now))
                    added+=cur.rowcount
            except Exception as e:
                errors.append({'category':category,'error':str(e)[:160]})
    return {'new_suggestions':added,'errors':errors,'code_changes':0}

def suggestions(path=DB,limit=20):
    with connect(path) as con:
        rows=con.execute('SELECT id,category,title,url,score,rationale,status FROM candidates ORDER BY score DESC,seen_at DESC LIMIT ?', (min(max(limit,1),100),)).fetchall()
    return [dict(zip(('id','category','title','url','score','rationale','status'),r)) for r in rows]

def decide(identifier,status,path=DB):
    if status not in ('approved_for_review','rejected'):raise ValueError('Only review decisions are supported')
    with connect(path) as con:
        count=con.execute('UPDATE candidates SET status=? WHERE id=? AND status="proposed"',(status,identifier)).rowcount
    return bool(count)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('action',choices=['collect','suggestions'])
    args=ap.parse_args()
    print(json.dumps(collect() if args.action=='collect' else suggestions(),ensure_ascii=False,indent=2))
