"""Local, escaped, printable research report from a user-provided title and notes."""
import html
import json
from datetime import datetime, timezone

MAX_TITLE=160
MAX_TEXT=24000

def generate(title, text, kind='html'):
    if not isinstance(title,str) or not isinstance(text,str):
        raise ValueError('Title and text must be strings')
    title=title.strip(); text=text.strip()
    if not (1<=len(title)<=MAX_TITLE) or not (1<=len(text)<=MAX_TEXT):
        raise ValueError('Title or text is empty or exceeds size limit')
    if kind not in ('html','markdown','json'):
        raise ValueError('Unsupported format')
    created=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    if kind=='json':
        return json.dumps({'title':title,'body':text,'created_at':created,'verified':False},ensure_ascii=False,indent=2),'application/json; charset=utf-8'
    if kind=='markdown':
        return f'# {title}\n\nДата: {created}\n\n{text}\n','text/markdown; charset=utf-8'
    paragraphs=''.join('<p>'+html.escape(p).replace('\n','<br>')+'</p>' for p in text.split('\n\n') if p.strip())
    page="""<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{title}</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:780px;margin:40px auto;padding:0 24px;color:#172236}}h1{{line-height:1.2}}small{{color:#667}}p{{white-space:normal}}@media print{{body{{margin:0;max-width:none}}}}</style></head><body><h1>{title}</h1><small>Составлено: {created}. Содержание не проверено независимо.</small><hr>{paragraphs}</body></html>""".format(title=html.escape(title),created=created,paragraphs=paragraphs)
    return page,'text/html; charset=utf-8'
