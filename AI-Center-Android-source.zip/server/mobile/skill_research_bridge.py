"""Connect research leads to the skills review workflow without treating web text as instructions.

A web result is only a lead. It cannot be activated as a skill. A human must
write/review a bounded JSON instruction and approve it separately.
"""
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlsplit

MAX_RESULTS = 30

def research_leads(database, limit=20):
    """Return safe-to-display metadata from the existing feature-discovery database."""
    database = Path(database)
    if not database.is_file():
        return []
    limit = max(1, min(int(limit), MAX_RESULTS))
    con = sqlite3.connect(f'file:{database.resolve()}?mode=ro', uri=True)
    try:
        rows = con.execute('SELECT title,url,category,score,rationale FROM candidates '
                           'WHERE status IN ("proposed","approved_for_review") '
                           'ORDER BY score DESC, seen_at DESC LIMIT ?', (limit,)).fetchall()
    finally:
        con.close()
    output = []
    for title, url, category, score, rationale in rows:
        parts = urlsplit(url)
        if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password:
            continue
        output.append({'title': str(title)[:300], 'url': url, 'category': str(category)[:80],
                       'score': int(score), 'rationale': str(rationale)[:200],
                       'state': 'research_only', 'can_activate': False})
    return output

def draft_skill(name, instructions, source_url):
    """Make a local candidate, never a pre-approved skill; source is informational only."""
    parts = urlsplit(source_url)
    if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password:
        raise ValueError('A public HTTPS source is required')
    from mobile.skill_candidates import inspect
    safe, flags = inspect({'name': name, 'instructions': instructions})
    return {'candidate': safe, 'source_url': source_url, 'risk_flags': flags,
            'requires_manual_review': True, 'auto_activate': False}

def submit_draft(base, name, instructions, source_url):
    """Queue a manually authored draft using the existing approval system."""
    from mobile.skill_candidates import suggest
    draft = draft_skill(name, instructions, source_url)
    return suggest(base, draft['candidate'], origin='research_review')
