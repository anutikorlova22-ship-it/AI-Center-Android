"""Read-only capability inventory and explicit Google Drive sync for hybrid Android/Termux.
No arbitrary command execution; localhost-only API is enforced by server bind.
"""
import pathlib
import shutil
import subprocess
import threading

_LOCK = threading.Lock()

FEATURES = {
    'native_android': ['notes', 'reminders', 'offline_chat_history', 'gguf_import', 'approved_skill_storage', 'speech_input', 'text_to_speech'],
    'termux_server': ['existing_chat', 'research', 'web_search', 'document_export', 'skill_discovery', 'google_drive_rclone', 'knowledge_index', 'scheduled_agents'],
    'conditional': ['native_qwen_requires_llama_cpp_build', 'google_drive_requires_rclone_remote', 'online_features_require_network'],
}


def inventory(base):
    base = pathlib.Path(base)
    remote = False
    if shutil.which('rclone'):
        try:
            p = subprocess.run(['rclone', 'listremotes'], capture_output=True, text=True, timeout=8)
            remote = p.returncode == 0 and any(x.rstrip(':').lower() in ('gdrive', 'drive', 'google_drive') for x in p.stdout.splitlines())
        except (OSError, subprocess.TimeoutExpired):
            pass
    return {'features': FEATURES, 'drive_remote_configured': remote,
            'memory_db_exists': (base / 'knowledge' / 'knowledge.db').is_file(),
            'termux_sync_script_exists': (base / 'bin' / 'sync_memory.py').is_file(),
            'drive_sync_running': _LOCK.locked()}


def sync_drive(base, timeout=240):
    """Run existing *fixed* allowlisted sync script only on explicit user request."""
    base = pathlib.Path(base)
    script = base / 'bin' / 'sync_memory.py'
    if not script.is_file() or script.is_symlink():
        return {'ok': False, 'error': 'sync_memory.py missing or unsafe'}
    if not shutil.which('rclone'):
        return {'ok': False, 'error': 'rclone not installed'}
    if not _LOCK.acquire(blocking=False):
        return {'ok': False, 'error': 'sync already running'}
    try:
        try:
            result = subprocess.run(['python', str(script), '--remote', 'gdrive:AI_MEMORY_HQ'],
                                    capture_output=True, text=True, timeout=timeout, cwd=str(base))
            return {'ok': result.returncode == 0, 'exit_code': result.returncode,
                    'output': result.stdout[-1000:], 'error': result.stderr[-500:]}
        except (OSError, subprocess.TimeoutExpired) as e:
            return {'ok': False, 'error': type(e).__name__}
    finally:
        _LOCK.release()
