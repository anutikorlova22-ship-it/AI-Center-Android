"""Offline skill discovery inbox. Candidates are untrusted and never activated automatically."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from . import approved_skills

MAX_CANDIDATES = 200
RISK_PATTERNS = {
    'shell_commands': r'(?i)(?:\brm\s+-rf\b|\bcurl\b.{0,60}\|\s*(?:sh|bash)|\bsubprocess\b|\bos\.system\b)',
    'secret_access': r'(?i)(?:api[_ -]?key|password|token|секрет|парол).{0,90}(?:отправ|send|upload|передай|exfiltrat)',
    'instruction_override': r'(?i)(?:ignore previous instructions|игнорируй предыдущие инструкции|system prompt|developer message)',
}

def _path(base):
    return Path(base) / 'config' / 'skill_candidates.json'

def _load(base):
    path = _path(base)
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, list):
        raise ValueError('Invalid candidate inbox')
    return data

def _save(base, items):
    path = _path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)

def inspect(raw):
    if not isinstance(raw, dict):
        raise ValueError('Candidate must be an object')
    # Validation is structural only; it does not make instructions trustworthy.
    safe = approved_skills.validate(raw)
    flags = [key for key, pattern in RISK_PATTERNS.items() if re.search(pattern, safe['instructions'])]
    return safe, flags

def suggest(base, raw, origin='local_file'):
    if origin not in ('local_file', 'research_review', 'user_submission'):
        raise ValueError('Unsupported origin')
    skill, flags = inspect(raw)
    identifier = hashlib.sha256((skill['name'] + '\n' + skill['instructions']).encode()).hexdigest()[:20]
    items = _load(base)
    if any(item['id'] == identifier for item in items):
        return identifier
    if len(items) >= MAX_CANDIDATES:
        raise ValueError('Candidate inbox full')
    items.append({'id': identifier, 'name': skill['name'], 'instructions': skill['instructions'],
                  'origin': origin, 'risk_flags': flags, 'status': 'pending',
                  'created_utc': datetime.now(timezone.utc).isoformat()})
    _save(base, items)
    return identifier

def pending(base):
    return [dict(item) for item in _load(base) if item.get('status') == 'pending']

def decide(base, identifier, approve=False, acknowledge_risk=False):
    items = _load(base)
    item = next((x for x in items if x.get('id') == identifier), None)
    if item is None or item.get('status') != 'pending':
        raise ValueError('Unknown or already reviewed candidate')
    if approve and item['risk_flags'] and not acknowledge_risk:
        raise ValueError('Explicit risk acknowledgement required')
    if approve:
        approved_skills.add(base, {'name': item['name'], 'instructions': item['instructions']})
    item['status'] = 'approved' if approve else 'rejected'
    _save(base, items)
    return item['status']
