"""Safe local chat export and user-correction inbox. No automatic canon edits."""
import csv, datetime, io, json, pathlib, sqlite3

def _history(base,limit=500):
    db=base/'knowledge'/'chat_history.db'
    if not db.is_file():return []
    with sqlite3.connect(db) as c:
        rows=c.execute('SELECT role,body,created_at FROM messages ORDER BY id DESC LIMIT ?', (min(max(int(limit),1),1000),)).fetchall()
    return [{'role':r,'body':b,'created_at':d} for r,b,d in reversed(rows)]

def export_history(base,format='markdown'):
    rows=_history(base)
    if format=='json':return json.dumps({'items':rows},ensure_ascii=False,indent=2),'application/json; charset=utf-8','chat.json'
    if format=='csv':
        buf=io.StringIO();writer=csv.writer(buf);writer.writerow(['created_at','role','body'])
        for r in rows:writer.writerow([r['created_at'],r['role'],r['body']])
        return buf.getvalue(),'text/csv; charset=utf-8','chat.csv'
    if format!='markdown':raise ValueError('Unsupported format')
    content='# ИИ Центр — история чата\n\n'+'\n\n'.join('### '+str(r['role'])+' — '+str(r['created_at'])+'\n\n'+str(r['body']) for r in rows)
    return content,'text/markdown; charset=utf-8','chat.md'

def add_feedback(base,text,source='user'):
    text=str(text).strip()
    if not 3<=len(text)<=3000:raise ValueError('Correction must contain 3–3000 characters')
    db=base/'knowledge'/'feedback_inbox.db';db.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(db,timeout=15) as c:
        c.execute('CREATE TABLE IF NOT EXISTS feedback (id INTEGER PRIMARY KEY, text TEXT NOT NULL, source TEXT NOT NULL, status TEXT NOT NULL DEFAULT "pending", created_at TEXT NOT NULL)')
        c.execute('INSERT INTO feedback(text,source,created_at) VALUES(?,?,?)',(text,str(source)[:50],datetime.datetime.now(datetime.timezone.utc).isoformat()))
        return {'id':c.execute('SELECT last_insert_rowid()').fetchone()[0],'status':'pending','canon_modified':False}

def feedback_inbox(base):
    db=base/'knowledge'/'feedback_inbox.db'
    if not db.exists():return {'items':[]}
    with sqlite3.connect(db) as c:
        rows=c.execute('SELECT id,text,status,created_at FROM feedback ORDER BY id DESC LIMIT 50').fetchall()
    return {'items':[dict(zip(('id','text','status','created_at'),r)) for r in rows]}
