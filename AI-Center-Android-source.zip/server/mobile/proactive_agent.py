#!/usr/bin/env python3
"""AI Center opt-in, non-destructive proactive research and learning inbox.
No model retraining, self-modifying code, or autonomous publishing.
"""
import argparse, datetime as dt, hashlib, json, pathlib, sqlite3, urllib.request, xml.etree.ElementTree as ET
from urllib.parse import urlparse

BASE = pathlib.Path.home() / 'AI_CENTER'
DB = BASE / 'knowledge' / 'proactive.db'
FEEDS = {
 'AI и технологии': ['https://hnrss.org/newest?q=local+AI', 'https://hnrss.org/newest?q=llama.cpp'],
 'Музыкальная индустрия': ['https://news.google.com/rss/search?q=music+distribution+AI+policy&hl=en-US&gl=US&ceid=US:en'],
 'VeraLazaR и TAYAGE': ['https://news.google.com/rss/search?q=Yandex+Music+VK+Music+artist+distribution&hl=en-US&gl=US&ceid=US:en'],
}

def connect(path=DB):
 path.parent.mkdir(parents=True, exist_ok=True)
 con=sqlite3.connect(path)
 con.execute('PRAGMA journal_mode=WAL')
 con.execute('CREATE TABLE IF NOT EXISTS findings (id TEXT PRIMARY KEY, topic TEXT NOT NULL, title TEXT NOT NULL, url TEXT NOT NULL, summary TEXT NOT NULL, first_seen TEXT NOT NULL, reviewed INTEGER NOT NULL DEFAULT 0)')
 con.execute('CREATE TABLE IF NOT EXISTS lessons (id INTEGER PRIMARY KEY, correction TEXT NOT NULL, evidence TEXT NOT NULL, status TEXT NOT NULL DEFAULT "pending", created_at TEXT NOT NULL)')
 con.execute('CREATE TABLE IF NOT EXISTS health (name TEXT PRIMARY KEY, status TEXT NOT NULL, checked_at TEXT NOT NULL)')
 return con

def fetch_feed(url, timeout=12):
 parsed=urlparse(url)
 if parsed.scheme!='https' or parsed.hostname not in {'hnrss.org','news.google.com'}:
  raise ValueError('Feed host not permitted')
 req=urllib.request.Request(url,headers={'User-Agent':'AI-Center-Research/1.0'})
 with urllib.request.urlopen(req,timeout=timeout) as r:
  raw=r.read(800_000)
 root=ET.fromstring(raw)
 results=[]
 for item in root.findall('.//item')[:30]:
  def value(tag): return (item.findtext(tag) or '').strip()
  title, link, description=value('title'),value('link'),value('description')
  p=urlparse(link)
  if not title or p.scheme not in ('http','https') or not p.hostname:continue
  results.append((title[:300],link[:1500],description[:1200]))
 return results

def collect(path=DB, feeds=FEEDS, fetcher=fetch_feed):
 count=0; errors=[]; now=dt.datetime.now(dt.timezone.utc).isoformat()
 with connect(path) as con:
  for topic,urls in feeds.items():
   for url in urls:
    try:
     for title,link,summary in fetcher(url):
      key=hashlib.sha256(link.encode()).hexdigest()
      cur=con.execute('INSERT OR IGNORE INTO findings(id,topic,title,url,summary,first_seen) VALUES (?,?,?,?,?,?)',(key,topic,title,link,summary,now))
      count+=cur.rowcount
     con.execute('INSERT OR REPLACE INTO health(name,status,checked_at) VALUES(?,?,?)',(url,'ok',now))
    except Exception as exc:
     errors.append({'feed':url,'error':str(exc)[:180]})
     con.execute('INSERT OR REPLACE INTO health(name,status,checked_at) VALUES(?,?,?)',(url,'error',now))
 return {'new_items':count,'errors':errors}

def inbox(path=DB, limit=20):
 with connect(path) as con:
  rows=con.execute('SELECT topic,title,url,first_seen FROM findings WHERE reviewed=0 ORDER BY first_seen DESC LIMIT ?', (min(max(limit,1),100),)).fetchall()
 return [{'topic':r[0],'title':r[1],'url':r[2],'first_seen':r[3]} for r in rows]

def lesson(path, correction, evidence):
 if not correction.strip() or not evidence.strip():raise ValueError('Correction and evidence required')
 with connect(path) as con:
  con.execute('INSERT INTO lessons(correction,evidence,created_at) VALUES (?,?,?)',(correction[:2000],evidence[:2000],dt.datetime.now(dt.timezone.utc).isoformat()))
 return 'pending_review'

def diagnostics(path=DB):
 with connect(path) as con:
  n=con.execute('SELECT COUNT(*) FROM findings WHERE reviewed=0').fetchone()[0]
  lessons=con.execute('SELECT COUNT(*) FROM lessons WHERE status="pending"').fetchone()[0]
  failures=con.execute('SELECT COUNT(*) FROM health WHERE status="error"').fetchone()[0]
 return {'unread_findings':n,'lessons_awaiting_review':lessons,'feed_failures':failures,'self_modification':False}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('command',choices=['collect','inbox','health','lesson']);ap.add_argument('--correction',default='');ap.add_argument('--evidence',default='');ap.add_argument('--db',type=pathlib.Path,default=DB)
 args=ap.parse_args()
 if args.command=='collect':out=collect(args.db)
 elif args.command=='inbox':out=inbox(args.db)
 elif args.command=='health':out=diagnostics(args.db)
 else:out=lesson(args.db,args.correction,args.evidence)
 print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
