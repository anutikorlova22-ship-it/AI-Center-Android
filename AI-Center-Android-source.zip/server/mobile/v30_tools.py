"""V3 tools: local-only task store and source-labelled RSS search. Stdlib only.
No arbitrary commands, no unapproved canon edits, no background execution.
"""
import datetime as dt
import json
import pathlib
import re
import sqlite3

MAX_QUERY=180

def tasks_db(base):
    path=pathlib.Path(base)/'knowledge'/'v30_tasks.sqlite3'
    path.parent.mkdir(parents=True,exist_ok=True)
    conn=sqlite3.connect(path,timeout=10)
    conn.execute('CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, details TEXT NOT NULL DEFAULT "", status TEXT NOT NULL DEFAULT "pending", created_at TEXT NOT NULL)')
    return conn

def add_task(base,title,details=''):
    title=str(title).strip(); details=str(details).strip()
    if not (1<=len(title)<=160) or len(details)>3000: raise ValueError('Некорректная задача')
    with tasks_db(base) as c:
        cur=c.execute('INSERT INTO tasks(title,details,created_at) VALUES (?,?,?)',(title,details,dt.datetime.now(dt.timezone.utc).isoformat()))
        return {'id':cur.lastrowid,'title':title,'status':'pending'}

def list_tasks(base):
    with tasks_db(base) as c:
        rows=c.execute('SELECT id,title,details,status,created_at FROM tasks ORDER BY id DESC LIMIT 100').fetchall()
    return [{'id':r[0],'title':r[1],'details':r[2],'status':r[3],'created_at':r[4]} for r in rows]

def finish_task(base,task_id):
    try: task_id=int(task_id)
    except (TypeError,ValueError): raise ValueError('Некорректный ID')
    with tasks_db(base) as c:
        changed=c.execute('UPDATE tasks SET status="done" WHERE id=? AND status="pending"',(task_id,)).rowcount
    return {'ok':bool(changed)}

def search_sources(base,query):
    """Search *previously collected* RSS summaries. Never claims live web search."""
    query=str(query).strip()[:MAX_QUERY]
    tokens=[x for x in re.findall(r'[\wа-яё]+',query.casefold()) if len(x)>2][:8]
    db=pathlib.Path(base)/'knowledge_agent'/'research.sqlite3'
    if not db.exists():return {'items':[],'status':'rss_cache_missing','live':False}
    try:
        with sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True) as c:
            rows=c.execute('SELECT title,url,source,published,summary,category FROM articles ORDER BY fetched_at DESC LIMIT 1000').fetchall()
    except sqlite3.Error:
        return {'items':[],'status':'rss_cache_unavailable','live':False}
    scored=[]
    for title,url,source,published,summary,category in rows:
        body=(str(title)+' '+str(summary)).casefold()
        rank=sum(3 if t in str(title).casefold() else 1 for t in tokens if t in body)
        if rank:
            scored.append((rank,{'title':title,'url':url,'source':source,'published':published,'summary':summary,'category':category}))
    scored.sort(key=lambda x:x[0],reverse=True)
    return {'items':[x[1] for x in scored[:12]],'status':'cached_rss','live':False}


# Explicit opt-in document workspace. Does not scan the phone or Drive.
DOC_TYPES={'.txt','.md','.markdown','.csv','.json','.log','.docx','.pdf'}
MAX_DOC_BYTES=2_000_000

def extract_document_text(path):
    """Offline extraction, with strict size and zip limits. No network."""
    import zipfile
    import xml.etree.ElementTree as ET
    import shutil
    import subprocess
    suffix=path.suffix.lower()
    if suffix=='.docx':
        with zipfile.ZipFile(path) as archive:
            info=archive.getinfo('word/document.xml')
            if info.file_size>5_000_000: return ''
            root=ET.fromstring(archive.read(info))
        ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
        return '\n'.join(''.join(t.text or '' for t in para.iter(ns+'t')) for para in root.iter(ns+'p'))[:500_000]
    if suffix=='.pdf':
        binary=shutil.which('pdftotext')
        if not binary:return ''
        try:
            result=subprocess.run([binary,'-enc','UTF-8','-nopgbrk',str(path),'-'],capture_output=True,timeout=8,check=False)
            return result.stdout[:500_000].decode('utf-8',errors='replace') if result.returncode==0 else ''
        except (OSError,subprocess.TimeoutExpired):return ''
    return path.read_text(encoding='utf-8',errors='replace')


def search_imports(base,query):
    """Search only user-placed plain-text documents in AI_CENTER/imports."""
    import os
    folder=pathlib.Path(base)/'imports'
    query=str(query).strip()[:180]
    words=[w for w in re.findall(r'[\wа-яё]+',query.casefold()) if len(w)>=3][:8]
    if not words:return {'items':[],'status':'empty_query','scope':'imports','live':False}
    if not folder.is_dir():return {'items':[],'status':'imports_missing','scope':'imports','live':False}
    results=[]
    for p in sorted(folder.rglob('*')):
        if len(results)>=20:break
        try:
            if p.is_symlink() or not p.is_file() or p.suffix.lower() not in DOC_TYPES:continue
            if not p.resolve().is_relative_to(folder.resolve()):continue
            if p.stat().st_size>MAX_DOC_BYTES:continue
            body=extract_document_text(p)
            lowered=body.casefold()
            hits=sum(lowered.count(w) for w in words)
            if not hits:continue
            pos=min((lowered.find(w) for w in words if w in lowered),default=0)
            snippet=body[max(0,pos-120):pos+380]
            results.append({'name':p.name,'source':str(p.relative_to(folder)),'snippet':snippet,'matches':hits})
        except (OSError,UnicodeError,ValueError,KeyError,Exception):continue
    results.sort(key=lambda item:item['matches'],reverse=True)
    return {'items':results,'status':'local_files','scope':'imports','live':False}
