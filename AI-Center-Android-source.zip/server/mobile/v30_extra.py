"""Additional opt-in V3 tools. No shell execution, no external API keys."""
import datetime as dt
import html
from html.parser import HTMLParser
import json
import pathlib
import re
import sqlite3
import urllib.parse
import urllib.request

class _Results(HTMLParser):
    def __init__(self):
        super().__init__(); self.items=[]; self.in_link=False; self.label=[]; self.url=''
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='a' and 'result__a' in a.get('class',''):
            self.in_link=True; self.label=[]; self.url=a.get('href','')
    def handle_data(self,data):
        if self.in_link:self.label.append(data)
    def handle_endtag(self,tag):
        if tag=='a' and self.in_link:
            url=self.url
            if url.startswith('//'):url='https:'+url
            parsed=urllib.parse.urlparse(url)
            if parsed.netloc.endswith('duckduckgo.com'):
                url=urllib.parse.parse_qs(parsed.query).get('uddg',[''])[0]
            if urllib.parse.urlparse(url).scheme in ('http','https'):
                self.items.append({'title':html.unescape(''.join(self.label)).strip()[:180],'url':url})
            self.in_link=False

def live_search(query,limit=6):
    """Public DDG HTML search. Return explicit error if network blocked; no fake results."""
    query=str(query).strip()[:180]
    if len(query)<2:return {'items':[],'live':False,'error':'Пустой запрос'}
    url='https://html.duckduckgo.com/html/?'+urllib.parse.urlencode({'q':query})
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; AICenter/3.0)'})
    try:
        with urllib.request.urlopen(req,timeout=9) as r:
            if r.status!=200:raise OSError('HTTP '+str(r.status))
            raw=r.read(400000).decode('utf-8','replace')
        parser=_Results();parser.feed(raw)
        return {'items':parser.items[:max(1,min(int(limit),10))],'live':True,'source':'DuckDuckGo HTML'}
    except (OSError,ValueError) as e:
        return {'items':[],'live':False,'error':str(e)[:180]}

def _connect(base):
    db=pathlib.Path(base)/'knowledge'/'v30_schedule.sqlite3';db.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(db,timeout=10)
    c.execute('CREATE TABLE IF NOT EXISTS reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, due_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT "pending", created_at TEXT NOT NULL)')
    return c

def add_reminder(base,title,due_at):
    title=str(title).strip();due_at=str(due_at).strip()
    if not 1<=len(title)<=160:raise ValueError('Некорректное название')
    try:
        parsed=dt.datetime.fromisoformat(due_at.replace('Z','+00:00'))
        if parsed.tzinfo is None:raise ValueError()
    except ValueError:raise ValueError('Нужна дата с часовым поясом ISO 8601')
    with _connect(base) as c:
        cur=c.execute('INSERT INTO reminders(title,due_at,created_at) VALUES (?,?,?)',(title,parsed.isoformat(),dt.datetime.now(dt.timezone.utc).isoformat()))
        return {'id':cur.lastrowid,'title':title,'due_at':parsed.isoformat(),'status':'pending'}

def list_reminders(base):
    with _connect(base) as c:
        rows=c.execute('SELECT id,title,due_at,status FROM reminders ORDER BY due_at LIMIT 100').fetchall()
    now=dt.datetime.now(dt.timezone.utc)
    return [{'id':a,'title':b,'due_at':d,'status':s,'due':s=='pending' and dt.datetime.fromisoformat(d)<=now} for a,b,d,s in rows]

def dismiss_reminder(base,item_id):
    with _connect(base) as c:
        count=c.execute('UPDATE reminders SET status="done" WHERE id=? AND status="pending"',(int(item_id),)).rowcount
    return {'ok':bool(count)}

def capabilities(base):
    base=pathlib.Path(base)
    return {'chat':'local_llm_or_extractive','documents':'txt_md_csv_json_log_docx_pdf_if_pdftotext',
            'live_search':'network_dependent','reminders':'stored_and_pollable_not_push',
            'voice':'android_speech_recognition_and_tts_if_available',
            'image_generation':'not_included_requires_model_or_provider',
            'proactive_research':'scheduled_if_termux_cron_enabled',
            'knowledge_db':(base/'knowledge/knowledge.db').exists()}
