"""Idempotent, append-only Android snapshot receiver; no execution or cloud upload."""
import json
import pathlib
import sqlite3

MAX_BYTES = 512_000

def save(base, payload):
    if not isinstance(payload, dict) or payload.get('schema') != 1:
        raise ValueError('unsupported snapshot schema')
    notes, tasks = payload.get('notes'), payload.get('tasks')
    if not isinstance(notes, list) or not isinstance(tasks, list) or len(notes)>100 or len(tasks)>100:
        raise ValueError('invalid snapshot lists')
    rows=[]
    for kind, items in (('note',notes),('task',tasks)):
        for item in items:
            if not isinstance(item,dict) or type(item.get('id')) is not int or not 0 < item['id'] < 2**63:
                raise ValueError('invalid item id')
            field='body' if kind=='note' else 'title'
            content=item.get(field)
            if not isinstance(content,str) or not content.strip() or len(content)>20000:
                raise ValueError('invalid content')
            timestamp=item.get('created_ms' if kind=='note' else 'due_ms')
            if type(timestamp) is not int or timestamp<0:
                raise ValueError('invalid timestamp')
            rows.append((kind,item['id'],content,timestamp))
    target=pathlib.Path(base)/'knowledge'/'android_backup.db'
    target.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(target) as db:
        db.execute('CREATE TABLE IF NOT EXISTS android_snapshot(kind TEXT NOT NULL, android_id INTEGER NOT NULL, content TEXT NOT NULL, timestamp_ms INTEGER NOT NULL, PRIMARY KEY(kind,android_id))')
        db.executemany('INSERT INTO android_snapshot(kind,android_id,content,timestamp_ms) VALUES(?,?,?,?) ON CONFLICT(kind,android_id) DO UPDATE SET content=excluded.content,timestamp_ms=excluded.timestamp_ms',rows)
    return {'ok':True,'items':len(rows),'location':'Termux local backup; not uploaded to Google Drive'}
