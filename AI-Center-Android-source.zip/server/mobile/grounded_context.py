"""Bounded, source-labelled retrieval for the local assistant. No autonomous actions."""
import re
import urllib.parse

def tokens(text):
    stop={'когда','какие','какая','какой','расскажи','найди','новости','сегодня','последние','проверь','про','для','the','what','where'}
    return [w for w in re.findall(r'[\wа-яё]+',text.casefold()) if len(w)>3 and w not in stop][:9]

def wants_live_search(question):
    q=question.casefold()
    return any(x in q for x in ('найди в интернете','поищи в интернете','проверь в интернете','в интернете','последние новости','свежие новости','актуальные новости','новости сегодня','сейчас в сети'))

def build_context(question,base,proactive,tools,extra,allow_web=True):
    """Return (context, references, diagnostics), never invented citations."""
    parts=[];refs=[];status={'documents':0,'findings':0,'web':False,'web_error':None}
    words=tokens(question)
    if words:
        try:
            local=tools.search_imports(base,question)
            for d in local.get('items',[])[:3]:
                title=str(d.get('source',''))[:160]
                snippet=str(d.get('snippet',''))[:500]
                parts.append('Локальный файл: '+title+'\nФрагмент: '+snippet)
                refs.append({'type':'document','title':title})
                status['documents']+=1
        except Exception as e: status['documents_error']=type(e).__name__
        try:
            # The proactive inbox contains only headlines and links, not verified article content.
            for item in proactive.inbox(limit=70):
                hay=(str(item.get('title',''))+' '+str(item.get('topic',''))).casefold()
                if not any(w in hay for w in words):continue
                title=str(item.get('title',''))[:200];url=str(item.get('url',''))[:1000]
                if urllib.parse.urlparse(url).scheme not in ('http','https'):continue
                parts.append('Непроверенный заголовок из RSS: '+title+'\nURL: '+url)
                refs.append({'type':'rss_headline','title':title,'url':url})
                status['findings']+=1
                if status['findings']>=3:break
        except Exception as e:status['findings_error']=type(e).__name__
    if allow_web and wants_live_search(question):
        result=extra.live_search(question,limit=4)
        status['web']=bool(result.get('live'))
        status['web_error']=result.get('error')
        for item in result.get('items',[])[:4]:
            title=str(item.get('title',''))[:180];url=str(item.get('url',''))[:1000]
            parsed=urllib.parse.urlparse(url)
            if parsed.scheme not in ('http','https') or not parsed.hostname:continue
            parts.append('Результат веб-поиска (заголовок, содержание страницы не проверено): '+title+'\nURL: '+url)
            refs.append({'type':'web_search','title':title,'url':url})
    return '\n\n'.join(parts)[:3600],refs,status
