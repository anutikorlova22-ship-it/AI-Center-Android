# ИИ Центр 4.3 — research-to-skill bridge

Added `server/mobile/skill_research_bridge.py` and tests. This reads previously discovered feature links from the SQLite discovery database in **read-only** mode. A discovered web link is **not** an executable skill and cannot be automatically activated. A human-authored instruction can be queued for manual approval through the existing skill inbox; source URL is not fetched or executed by this bridge.

**Termux migration status:** Termux remains necessary in this source release. Native Android llama.cpp/JNI model inference, embedded database migration, scheduler, and boot handling are not implemented or tested. Do not remove Termux from an existing installation.

**Privacy/security:** Only HTTPS research links are displayed; no remote code execution or automatic downloading. This is not a guarantee that source content is safe. Existing approval UI must still be used before a skill becomes active.
