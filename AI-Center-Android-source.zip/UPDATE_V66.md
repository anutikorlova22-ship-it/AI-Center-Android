# AI Center 6.6 — Native offline chat history

- Android SQLite schema upgraded from v1 to v2 with non-destructive migration.
- Local Qwen responses and questions are saved atomically after successful inference.
- Last six chat messages are included as bounded context for future offline questions.
- No Termux is used for these operations.

## Not migrated yet

The old home WebView and research, document, voice, and network services still use the Termux HTTP backend. No real llama.cpp binary, model, or Android APK is included. Termux deployment of llama.cpp does not automatically make the binary available to a separately sandboxed APK; the NDK-built JNI library and model must be packaged/imported and tested.
