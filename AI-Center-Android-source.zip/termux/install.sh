#!/data/data/com.termux/files/usr/bin/bash
set -eu
BASE="$HOME/AI_CENTER"
mkdir -p "$BASE/bin" "$BASE/logs" "$HOME/.termux"
cp "$(dirname "$0")/launch_from_android.sh" "$BASE/bin/launch_from_android.sh"
cp "$(dirname "$0")/status_server.py" "$BASE/bin/status_server.py"
chmod 700 "$BASE/bin/launch_from_android.sh" "$BASE/bin/status_server.py"
PROP="$HOME/.termux/termux.properties"
[ -f "$PROP" ] || touch "$PROP"
if grep -qE '^[[:space:]]*#?[[:space:]]*allow-external-apps[[:space:]]*=' "$PROP"; then
  sed -i 's/^[[:space:]]*#\?[[:space:]]*allow-external-apps[[:space:]]*=.*/allow-external-apps=true/' "$PROP"
else
  printf '\nallow-external-apps=true\n' >> "$PROP"
fi
printf 'Installed launcher. Close and reopen Termux to reload settings.\n'
printf 'If prompted, grant AI Center permission to run Termux commands.\n'
