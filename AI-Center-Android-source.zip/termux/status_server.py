#!/data/data/com.termux/files/usr/bin/python
"""Read-only loopback monitoring for AI Center. No shell execution from HTTP requests."""
import datetime as dt, json, os, re, sqlite3, subprocess, urllib.request, shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
HOME=Path.home(); BASE=HOME/'AI_CENTER'
def ok(url):
    try:
        with urllib.request.urlopen(url,timeout=1.5) as r:return 200<=r.status<400
    except Exception:return False
def process(name):
    try:
        s=subprocess.run(['pgrep','-f',name],capture_output=True,text=True,timeout=3)
        return s.returncode==0
    except Exception:return False
def matches(field,val,lo,hi):
    if field=='*':return True
    for part in field.split(','):
        try:
            step=1
            if '/' in part:part,st=part.split('/',1);step=int(st)
            if step<1:return False
            if part=='*':a,b=lo,hi
            elif '-' in part:a,b=map(int,part.split('-',1))
            else:a=b=int(part)
            if a<=val<=b and (val-a)%step==0:return True
        except Exception:pass
    return False
def next_time(parts,now):
    if len(parts)!=5:return None
    # Standard cron semantics for day-of-month/day-of-week OR when both restricted.
    start=now.replace(second=0,microsecond=0)+dt.timedelta(minutes=1)
    for i in range(0,60*24*32):
        x=start+dt.timedelta(minutes=i)
        if not(matches(parts[0],x.minute,0,59) and matches(parts[1],x.hour,0,23) and matches(parts[3],x.month,1,12)):continue
        dom=matches(parts[2],x.day,1,31);dow=matches(parts[4],(x.weekday()+1)%7,0,7)
        if parts[2]!='*' and parts[4]!='*':day=dom or dow
        else:day=dom and dow
        if day:return x
    return None
def status():
    now=dt.datetime.now().astimezone()
    try: lines=subprocess.run(['crontab','-l'],capture_output=True,text=True,timeout=4).stdout.splitlines()
    except Exception:lines=[]
    jobs=[]
    for line in lines:
        line=line.strip()
        if not line or line.startswith('#') or '=' in line.split()[0]:continue
        chunks=line.split(maxsplit=5)
        if len(chunks)<6:continue
        when=next_time(chunks[:5],now)
        delta=when-now if when else None
        seconds=max(0,int(delta.total_seconds())) if delta else None
        jobs.append({'name':chunks[5][:100], 'next_run':when.strftime('%Y-%m-%d %H:%M') if when else 'не определён', 'countdown':f'{seconds//3600}ч {(seconds%3600)//60}м' if seconds is not None else '—','last_result':'нет подтверждённого результата'})
    db=BASE/'memory.db'
    db_status='🟡 не найдена'
    for candidate in [BASE/'database/memory.db',BASE/'memory.db']:
        if candidate.exists():
            try:
                with sqlite3.connect(f'file:{candidate}?mode=ro',uri=True,timeout=2) as c: result=c.execute('PRAGMA quick_check').fetchone()[0]
                db_status='🟢 целостна' if result=='ok' else '🔴 ошибка целостности'
            except Exception:db_status='🔴 ошибка чтения'
            break
    internet_ok=ok('https://www.google.com/generate_204')
    drive_ok=False
    drive_detail='rclone не установлен или Google Drive не настроен'
    if shutil.which('rclone'):
        try:
            remotes=subprocess.run(['rclone','listremotes'],capture_output=True,text=True,timeout=4).stdout.splitlines()
            remote=next((r for r in remotes if r.rstrip(':').lower() in ('gdrive','drive','google_drive')),None)
            if remote:
                result=subprocess.run(['rclone','lsf',remote,'--max-depth','1'],capture_output=True,text=True,timeout=8)
                drive_ok=result.returncode==0
                drive_detail='Подключение проверено' if drive_ok else 'Ошибка доступа к Drive: '+result.stderr[:140]
            else:drive_detail='Не найден remote gdrive/drive/google_drive'
        except Exception as exc:drive_detail='Ошибка проверки: '+str(exc)[:100]
    return {'internet_ok':internet_ok,'drive_ok':drive_ok,'drive_detail':drive_detail,'checked_at':now.strftime('%Y-%m-%d %H:%M:%S'), 'web_ok':ok('http://127.0.0.1:8765/'),'qwen_ok':ok('http://127.0.0.1:8081/health'),'cron_running':process('[c]rond'),'database_status':db_status,'jobs':jobs}
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path!='/status':self.send_error(404);return
        data=json.dumps(status(),ensure_ascii=False).encode()
        self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def log_message(self,*args):pass
if __name__=='__main__':ThreadingHTTPServer(('127.0.0.1',8766),Handler).serve_forever()
