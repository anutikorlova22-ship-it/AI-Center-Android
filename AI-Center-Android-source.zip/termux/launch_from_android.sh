#!/data/data/com.termux/files/usr/bin/bash
set -u
HOME_DIR="/data/data/com.termux/files/home"
BASE="$HOME_DIR/AI_CENTER"
mkdir -p "$BASE/logs"
LOG="$BASE/logs/android_autostart.log"
# Start the read-only monitoring service if absent.
if ! /data/data/com.termux/files/usr/bin/curl -fsS --max-time 2 http://127.0.0.1:8766/status >/dev/null 2>&1; then
  nohup /data/data/com.termux/files/usr/bin/python "$BASE/bin/status_server.py" >> "$BASE/logs/status_server.log" 2>&1 < /dev/null &
fi
# Never launch a duplicate web server.
if /data/data/com.termux/files/usr/bin/curl -fsS --max-time 2 http://127.0.0.1:8765/ >/dev/null 2>&1; then
  printf '%s Existing server is ready\n' "$(date -Iseconds)" >> "$LOG"
  exit 0
fi
if [ ! -f "$BASE/bin/start_ai_center.sh" ]; then
  printf '%s Missing %s/bin/start_ai_center.sh\n' "$(date -Iseconds)" "$BASE" >> "$LOG"
  exit 1
fi
printf '%s Starting AI Center\n' "$(date -Iseconds)" >> "$LOG"
# Android may terminate background Termux processes depending on battery settings.
nohup /data/data/com.termux/files/usr/bin/bash "$BASE/bin/start_ai_center.sh" >> "$LOG" 2>&1 < /dev/null &
exit 0
